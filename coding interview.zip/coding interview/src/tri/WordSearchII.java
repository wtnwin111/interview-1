/**
 *
 */
package tri;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Given a matrix of lower alphabets and a dictionary. Find all words in the
 * dictionary that can be found in the matrix. A word can start from any
 * position in the matrix and go left/right/up/down to the adjacent position.
 * Given matrix: doaf agai dcan and dictionary: {"dog", "dad", "dgdg", "can",
 * "again"}
 *
 * return {"dog", "dad", "can", "again"}
 *
 * @author K25553
 *
 *         active search:
 *
 *         use trie to strcre the dictionary, bfs search trie tree:
 *         for for matrix x,y search(root, char[x][y], dictionary, resultlist) {
 *         if(root.hasword){ if ( dictionary.contains( root.string))
 *         result.add(root.string);} if (x, y <0 ||>len||root==null ) return;
 *         if (root.hm.containKey(x,y)){ for 4 directions {
 *         store char xy,
 *         set char xy=0 in order to search (new direction) without backtrack
 *         the the node already visited: abc !=abcba
 *         char xy = store xy (back track recover)
 *         }
 *
 *
 *         }
 */
public class WordSearchII {
	/**
	 * @param board
	 *            : A list of lists of character
	 * @param words
	 *            : A list of string
	 * @return: A list of string
	 */

	class TrieNode {
		String s;
		boolean hasString;
		HashMap<Character, TrieNode> subtree;

		public TrieNode() {
			hasString = false;
			subtree = new HashMap<Character, TrieNode>();
			s = "";
		}
	};

	class TrieTree {
		TrieNode root;

		public TrieTree(TrieNode TrieNode) {
			root = TrieNode;
		}

		public void insert(String s) {
			TrieNode now = root;
			for (int i = 0; i < s.length(); i++) {
				if (!now.subtree.containsKey(s.charAt(i))) {
					now.subtree.put(s.charAt(i), new TrieNode());
				}
				now = now.subtree.get(s.charAt(i));
			}
			now.s = s;
			now.hasString = true;
		}

		public boolean find(String s) {
			TrieNode now = root;
			for (int i = 0; i < s.length(); i++) {
				if (!now.subtree.containsKey(s.charAt(i))) {
					return false;
				}
				now = now.subtree.get(s.charAt(i));
			}
			return now.hasString;
		}
	};

	public int[] dx = { 1, 0, -1, 0 };
	public int[] dy = { 0, 1, 0, -1 };

	public void search(char[][] board, int x, int y, TrieNode root,
			ArrayList<String> ans) {

		if (root.hasString == true) {
			if (!ans.contains(root.s)) {
				ans.add(root.s);
			}
		}
		if (x < 0 || x >= board.length || y < 0 || y >= board[0].length
				|| board[x][y] == 0 || root == null) {
			return;
		}
		//
		if (root.subtree.containsKey(board[x][y])) {
			for (int i = 0; i < 4; i++) {
				char now = board[x][y];
				board[x][y] = 0;
				search(board, x + dx[i], y + dy[i], root.subtree.get(now), ans);
				board[x][y] = now;
			}
		}

	}

	public ArrayList<String> wordSearchII(char[][] board,
			ArrayList<String> words) {
		ArrayList<String> ans = new ArrayList<String>();

		TrieTree tree = new TrieTree(new TrieNode());
		for (String word : words) {
			tree.insert(word);
		}

		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board[i].length; j++) {
				search(board, i, j, tree.root, ans);
			}
		}
		return ans;
		// write your code here

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
