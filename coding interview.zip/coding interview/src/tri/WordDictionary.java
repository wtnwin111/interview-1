package tri;

import java.util.HashMap;
import java.util.Map;

public class WordDictionary {
	class TrieNode {
		// Initialize your data structure here.
		public HashMap<Character, TrieNode> children;
		public boolean hasWord;
		// Initialize your data structure here.
		public TrieNode() {
			children= new HashMap<Character, TrieNode>();
			hasWord=false;
		}
	}
	private TrieNode root;
	public WordDictionary(){
		root= new TrieNode();

	}
	// Adds a word into the data structure.
	public void addWord(String word) {
		TrieNode node = root;
		for(int i=0; i<word.length();i++){
			char c = word.charAt(i);
			if(!node.children.containsKey(c)){
				node.children.put(c, new TrieNode());
			}
			node=node.children.get(c);
			System.out.println(node.hasWord);
		}
		node.hasWord=true;
		System.out.println(node.hasWord);
	}

	// Returns if the word is in the data structure. A word could
	// contain the dot character '.' to represent any one letter.
	 // Returns if the word is in the data structure. A word could
    // contain the dot character '.' to represent any one letter.
    public boolean search(String word) {
		return find(word, 0, root);
	}
	private boolean find(String word, int i, TrieNode node ) {
		if(i>word.length()-1){
			return false;
		}
		else
		{
			char c = word.charAt(i);
			if(i== word.length()-1 &&node.children.containsKey(c) ){
			    if( node.children.get(c).hasWord){
			        return true;
			    }else {
			       return false;
			    }
				
			}else if(node.children.containsKey(c)){
				return find(word, i+1, node.children.get(c));
			}
			else if(c=='.'){
				for (Map.Entry<Character, TrieNode> entry: node.children.entrySet()){
					if(i== word.length()-1 && entry.getValue().hasWord){
						return true;
					}
					if(find(word, i+1, entry.getValue())){
						return true;
					}

				}
				return false;
			} 
			return false;
			
		}
	}
}
