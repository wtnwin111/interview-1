/**
 *
 */
package dp.twoPoint;

/**
 * Given n non-negative integers representing an elevation map where the width
 * of each bar is 1, compute how much water it is able to trap after raining.
 * For example,
 * Given [0,1,0,2,1,0,1,3,2,1,2,1], return 6.
 * 
 * @author Tiannan
 *
 */
public class TrappingRainWater {
	public int trapRainWater(int[] a) {
		int l = 0, r = a.length - 1;
		if (a == null || a.length < 3) {
			return 0;
		}
		int lh = a[l], rh = a[r], res = 0;
		// 1_1 res=1 11 res=0 right -left index must greater than 1 (at least 2)
		while (l < r - 1) {
			if (lh < rh) {
				l++;
				if (lh > a[l]) {
					res += lh - a[l];
				} else {
					lh = a[l];
				}
			} else {
				r--;
				if (rh > a[r]) {
					res += rh - a[r];
				} else {
					rh = a[r];
				}
			}
		}
		return res;
	}

	public int trap(int[] A) {
		int sum = 0;
		int max = -1;
		int maxIndex = -1;
		int prev;

		// find the highest bar
		for (int i = 0; i < A.length; i++) {
			if (max < A[i]) {
				max = A[i];
				maxIndex = i;
			}
		}

		// process all bars left to the highest bar
		// update window: the left window to be updated if the current left side
		// higher than the previous side,
		// update difference between current side and previous side, and apply
		// the difference to the distance between current side to the bar
		// remove current high from sum since updated window
		prev = 0;
		for (int i = 0; i < maxIndex; i++) {
			if (A[i] > prev) {
				sum += (A[i] - prev) * (maxIndex - i);
				prev = A[i];
			}
			sum -= A[i];
		}

		// process all bars right to the highest bar
		prev = 0;
		for (int i = A.length - 1; i > maxIndex; i--) {
			if (A[i] > prev) {
				sum += (A[i] - prev) * (i - maxIndex);
				prev = A[i];
			}
			sum -= A[i];
		}

		return sum;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
