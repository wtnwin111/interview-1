/**
 *
 */
package dp.twoPoint;

/**
 * Example
 * In array [9,3,2,4,8], the 3rd largest element is 4.
 *
 * In array [1,2,3,4,5], the 1st largest element is 5, 2nd largest element is 4,
 * 3rd largest element is 3 and etc.
 *
 * @author K25553
 *
 */
public class KthLargestElement { /*
								 * @param k : description of k
								 * 
								 * @param nums : array of nums
								 * 
								 * @return: description of return
								 */
	public int kthLargestElement(int k, int[] nums) {
		if (nums == null || nums.length == 0) {
			return 0;
		}
		if (k <= 0) {
			return 0;
		}
		return findK(nums, nums.length - k + 1, 0, nums.length - 1);
	}

	private int findK(int[] nums, int k, int i, int j) {
		if (i >= j) {
			return nums[i];
		}
		int pos = partition(nums, i, j);

		if (pos + 1 == k) {
			return nums[pos];
		} else if (pos + 1 < k) {
			return findK(nums, k, pos + 1, j);
		} else {
			return findK(nums, k, i, pos - 1);
		}
	}

	public int partition(int[] nums, int l, int r) {
		// ��ʼ������ָ���pivot
		int left = l, right = r;
		int pivot = nums[left];

		// ����partition
		while (left < right) {
			while (left < right && nums[right] >= pivot) {
				right--;
			}
			nums[left] = nums[right];
			while (left < right && nums[left] <= pivot) {
				left++;
			}
			nums[right] = nums[left];
		}

		// ����pivot�㵽��������
		nums[left] = pivot;
		return left;
	}
}
