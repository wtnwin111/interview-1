package dp.twoPoint;

import java.util.Arrays;

/**Given an array with positive and negative integers. Re-range it to interleaving with positive and negative integers.

 Notice

 You are not necessary to keep the original order of positive integers or negative integers.

 Have you met this question in a real interview? Yes
 Example
 Given [-1, -2, -3, 4, 5, 6], after re-range, it will be [-1, 5, -2, 4, -3, 6] or any other reasonable answer.


 * Created by K25553 on 8/30/2016.
 */
public class InterleavingPositiveandNegativeNumbers {
    /**
     * @param a: An integer array.
     * @return: void
     */
    public static void rerange1(int[] a) {
        if(a.length<=2||a==null){
            return;
        }
        int l=0,r=1,p=0, len=a.length;
        while(l<len&&r<len){
            while(l<len&&a[l]<0){l+=2;}
            while(r<len&&a[r]>0){r+=2;}
            if(l<len&&r<len){
                int temp=a[l];
                a[l]=a[r];
                a[r]=temp;
            } else if(l<len){
                int temp=a[l];
                a[l]=a[l+2];
                a[l+2]=temp;
            }else  if(r<len){
                int temp=a[r];
                a[r]=a[r+2];
                a[r+2]=temp;
            }
        }

        if (a[len-1]>0&&a[len-2]>0){
            reverse(a, len-2, 0);
        }
        else if (a[len-3]>0 ^ a[len-1]>0){
            int temp=a[len-3];
            a[len-3]=a[len-1];
            a[len-1]=temp;


            reverse(a, len-2, 0);

        }

    }

    private static void reverse(int[] a, int r, int l) {

        while(l<r){
            int temp=a[r];
            a[r]=a[l];
            a[l]=temp;
            l++;
            r--;
        }
    }

    public static void rerange(int[] a) {
        int a1[] = new int[(a.length+1)/2] ;
        int a2[] = new int[(a.length+1)/2] ;
        int c1=0,c2=0;
        for ( int i : a){
            if (i>0){
                a1[c1]=i;
                c1++;
            }else{
                a2[c2]=i;
                c2++;
            }
        }
        if(c1>c2){
            arrange(a1,a2,c1-1,c2-1,a);
        }
        else{
            arrange(a2,a1,c2-1,c1-1,a);
        }
    }

    private static void arrange(int[] a1, int[] a2, int c1, int c2, int[] a) {
        int i=0;
        while(c1>-1||c2>-1||i<a.length){
            if(i%2==0){
                a[i]=a1[c1];
                c1--;

            }else {
                a[i]=a2[c2];
                c2--;
            }
            i++;
        }
    }

    public static void main(String[]args){
        int [] a =new int []{28,19,10,-30,20,-20,-30,-22,34,-37,20,-28,21,-37,30,-17,20,21,27,-3,-12,23,-37};
        rerange1(a);
        System.out.println(Arrays.toString(a));
    }
}
