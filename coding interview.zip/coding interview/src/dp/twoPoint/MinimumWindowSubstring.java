/**
 *
 */
package dp.twoPoint;

import java.util.HashMap;

/**
 * Given a string source and a string target, find the minimum window in source
 * which will contain all the characters in target.
 *
 *
 * Example
 *
 * source = "ADOBECODEBANC" target = "ABC" Minimum window is "BANC".
 *
 * Note
 *
 * If there is no such window in source that covers all characters in target,
 * return the emtpy string "".
 *
 * If there are multiple such windows, you are guaranteed that there will always
 * be only one unique minimum window in source.
 *
 * Challenge
 *
 * Can you do it in time complexity O(n) ?
 *
 * Clarification
 *
 * Should the characters in minimum window has the same order in target?
 *
 * - Not necessary.
 *
 * @author Tiannan
 *
 */
public class MinimumWindowSubstring {
	// ����һ:
	int initTargetHash(int[] targethash, String Target) {
		int targetnum = 0;
		for (char ch : Target.toCharArray()) {
			targetnum++;
			targethash[ch]++;
		}
		return targetnum;
	}

	boolean valid(int[] sourcehash, int[] targethash) {

		for (int i = 0; i < 256; i++) {
			if (targethash[i] > sourcehash[i]) {
				return false;
			}
		}
		return true;
	}

	public String minWindow(String Source, String Target) {
		// queueing the position that matches the char in T
		int ans = Integer.MAX_VALUE;
		String minStr = "";

		int[] sourcehash = new int[256];
		int[] targethash = new int[256];

		initTargetHash(targethash, Target);
		int slow = 0, fast = 0;
		for (fast = 0; fast < Source.length(); fast++) {
			sourcehash[Source.charAt(fast)]++;
			while (valid(sourcehash, targethash)) {
				if (ans > fast - slow + 1) {
					ans = Math.min(ans, fast - slow + 1);
					minStr = Source.substring(slow, fast + 1);
				}
				sourcehash[Source.charAt(slow)]--;
				slow++;
			}
		}
		return minStr;
	}

	public String minWindow1(String S, String T) {
		if (S == null || S.length() == 0) {
			return S;
		}
		if (T == null || T.length() == 0) {
			return "";
		}

		HashMap<Character, Integer> tCounter = new HashMap<Character, Integer>();
		for (int i = 0; i < T.length(); i++) {
			Character c = T.charAt(i);
			if (tCounter.containsKey(c)) {
				tCounter.put(c, tCounter.get(c) + 1);
			} else {
				tCounter.put(c, 1);
			}
		}

		HashMap<Character, Integer> minWindowCounter = new HashMap<Character, Integer>();
		String minWindow = null;
		int tCount = 0, leftBound = 0;
		for (int i = 0; i < S.length(); i++) {
			Character c = S.charAt(i);
			if (!tCounter.containsKey(c)) {
				continue;
			}

			if (minWindowCounter.containsKey(c)) {
				minWindowCounter.put(c, minWindowCounter.get(c) + 1);
			} else {
				minWindowCounter.put(c, 1);
			}
			if (minWindowCounter.get(c) <= tCounter.get(c)) {
				tCount++;
			}

			if (tCount == T.length()) {
				while (leftBound < S.length()) {
					Character ch = S.charAt(leftBound);
					if (!tCounter.containsKey(ch)) {
						leftBound++;
						continue;
					}

					if (minWindowCounter.get(ch) > tCounter.get(ch)) {
						minWindowCounter.put(ch, minWindowCounter.get(ch) - 1);
						leftBound++;
						continue;
					}

					break;
				}

				if (minWindow == null || i - leftBound + 1 < minWindow.length()) {
					minWindow = S.substring(leftBound, i + 1);
				}
			}
		}

		if (minWindow == null) {
			return "";
		}
		return minWindow;
	}

	public String minWindow2(String source, String target) {
		// global minwindow size
		int slen = source.length();
		int tlen = target.length();
		int min = Integer.MAX_VALUE;
		// 2 pointer
		int slow = 0;
		int fast = 0;
		String ans = "";
		// map
		int[] sourcehash = new int[256];
		int[] targethash = new int[256];
		for (char i : target.toCharArray()) {
			targethash[i]++;
		}
		for (; fast < slen; fast++) {
			sourcehash[source.charAt(fast)]++;
			while (fast - slow + 1 >= tlen && fast - slow + 1 < min
					&& valid(sourcehash, targethash)) {
				ans = source.substring(slow, fast + 1);
				min = fast - slow + 1;
				sourcehash[source.charAt(slow)]--;
				slow++;
			}
		}
		return ans;

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
