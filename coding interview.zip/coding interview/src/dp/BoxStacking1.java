package dp;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;

import dp.BoxStacking.Box;

public class BoxStacking1 {
	public static void main(String[]args){
		Box[] A = new Box[2];
		A[0] = new Box(4,6,7);
		A[1] = new Box(1,2,3);
//		A[2] = new Box(4,5,6);
//		A[3] = new Box(10,12,32);
		int n = A.length;
		System.out.println(maxStackHeight(A, n));
	}
	
	public static int maxStackHeight(Box[] a, int n){
		Box[] rot = new Box[3*n];
		int index=0;
		for (int i=0; i<n;i++){
			rot[index]=a[i];
			index++;
			
			rot[index]=new Box();
			rot[index].h= a[i].w;
			rot[index].d=Math.max(a[i].h, a[i].d);
			rot[index].w=Math.min(a[i].h, a[i].d);
			index++;			
			
			rot[index]=new Box();
			rot[index].h= a[i].d;
			rot[index].d=Math.max(a[i].h, a[i].w);
			rot[index].w=Math.min(a[i].h, a[i].w);
			index++;
			
		}

		n=3*n;
		Arrays.sort(rot,new Comparator<Box>(){
			@Override 
			public int compare(Box o1, Box o2){
				return (o2.d*o2.w) - (o1.d*o1.w);
				
			}
		});
		
		int []msh= new int[n];

		for(int i=0; i<n; i++){
			msh[i] = rot[i].h;
		}
		for(int i=1; i<n; i++){
		  for(int j=0; j<i;j++){
			  if(rot[i].w<rot[j].w&&rot[i].d<rot[j].d){
				  msh[i]= Math.max(msh[i], msh[j]+rot[i].h);
			  }
		  }
		}
		
		int max=0;
		for(int i=0; i<n; i++){
			max=Math.max(max, msh[i]);
		}
		
		return max;
	}
	
	public static class Box{
		int h, w ,d;
		public Box(int h, int w, int d){
			this.h=h;
			this.w=w;
			this.d=d;
		}
		public Box() {
			// TODO Auto-generated constructor stub
		}
		   
		}
}


