/**
 *
 */
package dp.matrix;

import java.util.TreeSet;

/**
 * Given an integer matrix, find a submatrix where the sum of numbers is zero.
 * Your code should return the coordinate of the left-up and right-down number.
 * Example
 * Given matrix
 *
 * [
 * [1 ,5 ,7],
 * [3 ,7 ,-8],
 * [4 ,-8 ,9],
 * ]
 * return [(1,1), (2,2)]
 *
 * @author K25553
 *         analysis: dp[][] to track from 00 to xx matrix sum
 *         init dp[x+1][y+1] dp[0][j]=0, dp[i][0]=0
 *         fun[i+1][j+1]= fun[i+1][j]+fun[i][j+1]+matrix[i+1][j+1]- fun[i][j]
 *
 *         tranverse each hight: within a hight range, traverse a width to
 *         recode each sum, and if the sum repeat 2 times then the difference
 *         matrix result
 *
 *         for 0-x in i
 *         for i+1-x in j // fix range of height
 *         for 0-yin k //fix range of width
 *         diff1 =fun[j][k]-fun[i][k];
 *         diff2 =fun[j][k1]-fun[i][k2];
 *         if (diff1 == diff2) return ik jk2
 *
 *
 */
public class SubmatrixSum {
	/**
	 * @param matrix
	 *            an integer matrix
	 * @return the coordinate of the left-up and right-down number
	 */
	public int maxSumSubmatrix(int[][] matrix, int k) {
		if(matrix==null||matrix.length==0||matrix[0].length==0)
			return 0;

		int m=matrix.length;
		int n=matrix[0].length;

		int result = Integer.MIN_VALUE;

		for(int c1=0; c1<n; c1++){
			int[] each = new int[m];
			for(int c2=c1; c2>=0; c2--){
				for(int r=0; r<m; r++){
					each[r]+=matrix[r][c2];
				}
				result = Math.max(result, getLargestSumCloseToK(each, k));
			}
		}

		return result;
	}

	public int getLargestSumCloseToK(int[] arr, int k){
		int sum=0;
		TreeSet<Integer> set = new TreeSet<Integer>();
		int result=Integer.MIN_VALUE;
		set.add(0);

		for(int i=0; i<arr.length; i++){
			sum=sum+arr[i];

			Integer ceiling = set.ceiling(sum-k);
			if(ceiling!=null){
				result = Math.max(result, sum-ceiling);
			}

			set.add(sum);
		}

		return result;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
