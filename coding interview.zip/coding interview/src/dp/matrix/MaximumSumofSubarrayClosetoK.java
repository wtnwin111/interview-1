package dp.matrix;

import java.util.TreeSet;

/**http://www.programcreek.com/2016/08/maximum-sum-of-subarray-close-to-k/
 * Given an array, find the maximum sum of subarray close to k but not larger than k.
 * Created by K25553 on 12/2/2016.
 */
public class MaximumSumofSubarrayClosetoK {
    public int getLargestSumCloseToK(int[] arr, int k){
        if(arr.length==0||arr==null){
            return 0;
        }
        TreeSet<Integer> set = new TreeSet<>();
        set.add(0);
        int sum = 0;
        int res = Integer.MIN_VALUE;
        for(Integer i : arr){
            sum+= i;
            Integer rest = set.ceiling(sum-k);
            if(rest!=null){
                res= Math.max(res, sum-res);
            }
            set.add(i);
        }
        return res;
    }
}
