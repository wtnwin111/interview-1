package dp.matrix;

import java.util.TreeSet;

/**Given a non-empty 2D matrix matrix and an integer k, find the max sum of a rectangle in the matrix such that its sum is no larger than k.

 Example:
 Given matrix = [
 [1,  0, 1],
 [0, -2, 3]
 ]
 k = 2
 The answer is 2. Because the sum of rectangle [[0, 1], [-2, 3]] is 2 and 2 is the max number no larger than k (k = 2).

 Note:
 The rectangle inside the matrix must have an area > 0.
 What if the number of rows is much larger than the number of columns?
 * Created by K25553 on 11/29/2016.
 */
public class MaxSumofRectangleNoLargerThanK {
    public static int maxSumSubmatrix(int[][] matrix, int k) {
        int result = Integer.MIN_VALUE;
        int M = matrix.length;
        if (M == 0) return result;
        int N = matrix[0].length;
        if (N == 0) return result;
        // pre-compute: sum[i][j] = sum of submatrix [(0, 0), (i, j)]
        int[][] sum = new int[M+1][N+1];
        // init the dp[0][i]=dp[j][0]=0
        for (int j=0; j<=N; ++j) sum[0][j] = 0;
        for (int i=1; i<=M; ++i) sum[i][0] = 0;
        //calculate all 00 to ij summatrix sum = sum i-1 j + sum i j-1 + mtrx i j -sum i-1 j-1
        for (int i=0; i<M; ++i) {
            for (int j=0; j<N; ++j)
                sum[i+1][j+1] = matrix[i][j] + sum[i+1][j] + sum[i][j+1] - sum[i][j];
        }
        for (int l=0; l<M; ++l) {
            for (int h=l+1; h<=M; ++h) {
                // for each height
                int [] tmp = new int[N+1] ;
                for (int j=1; j<=N; ++j) {
                    tmp[j] = sum[h][j] - sum[l][j];
                }
                result  = findMax(k,tmp, result);
                if(result ==k){
                    return result;
                }
            }
        }
        return result;
    }

    private static int findMax(int k, int[] tmp, int result) {
        TreeSet<Integer> treeset = new TreeSet<>();
        int sum = Integer.MIN_VALUE;

        int res = 0;
        for(int i: tmp){
            int rest = i -k;
            if(treeset.last()>=rest){
                sum = Math.max(sum, i - treeset.ceiling(rest));
            }
            treeset.add(i);
        }
        return Math.max(sum, result);
    }

    public int maxSumSubmatrix1(int[][] matrix, int k) {
        if(matrix==null||matrix.length==0||matrix[0].length==0)
            return 0;

        int m=matrix.length;
        int n=matrix[0].length;

        int result = Integer.MIN_VALUE;

        for(int c1=0; c1<n; c1++){
            int[] each = new int[m];
            for(int c2=c1; c2>=0; c2--){

                for(int r=0; r<m; r++){
                    each[r]+=matrix[r][c2];
                }

                result = Math.max(result, getLargestSumCloseToK(each, k));
            }
        }

        return result;
    }

    public int getLargestSumCloseToK(int[] arr, int k){
        int sum=0;
        TreeSet<Integer> set = new TreeSet<Integer>();
        int result=Integer.MIN_VALUE;
        set.add(0);

        for(int i=0; i<arr.length; i++){
            sum=sum+arr[i];

            Integer ceiling = set.ceiling(sum-k);
            if(ceiling!=null){
                result = Math.max(result, sum-ceiling);
            }

            set.add(sum);
        }

        return result;
    }
    //The time complexity is O(n*n*m*log(m)). If m is greater than n, this solution is fine. However, if m is less than n,
    // then this solution is not optimal. In this case, we should reverse the row and column, like Solution 2.
    public int maxSumSubmatrix2(int[][] matrix, int k) {
        if(matrix==null||matrix.length==0||matrix[0].length==0)
            return 0;

        int row=matrix.length;
        int col=matrix[0].length;

        int m = Math.max(row, col);
        int n = Math.min(row, col);
        boolean isRowLarger = false;
        if(row>col)
            isRowLarger=true;

        int result = Integer.MIN_VALUE;

        for(int c1=0; c1<n; c1++){

            int[] each = new int[m];
            for(int c2=c1; c2>=0; c2--){

                for(int r=0; r<m; r++){
                    each[r]+=isRowLarger?matrix[r][c2]:matrix[c2][r];
                }

                result = Math.max(result, getLargestSumCloseToK(each, k));
            }
        }

        return result;
    }
    public static void  main(String [] args){
            int M[][] ={{2,2,-1}};

//                {{1, 2, -1, -4, -20},
//            {-8, -3, 4, 2, 1},
//            {3, 8, 10, 1, 3},
//            {-4, -1, 1, 7, -6}
//        };

        System.out.println(maxSumSubmatrix(M, -1));
    }
}
