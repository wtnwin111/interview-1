package dp.matrix;

import java.util.TreeSet;

/**
 * https://rafal.io/posts/subsequence-closest-to-t.html
 * Let prefix[i] be the cumulative sum up to ii, like in the example above.
 * Then, we need to compute the best subarray ending at ii.
 * This means we need to find an index j<ij<i such that the sum is as close as possible to tt.
 * This means that this value needs to be as close as possible to prefix[i] - t, since  prefix[i] - prefix[j] is the sum of the subsequence between
 * [j,i]. So, for every prefix, we must find another earlier prefix that��s as close in value to prefix[i] - t.
 *
 * We can use a Java TreeSet for this which supports O(log(n))O(log?(n)) insertion, lower bound, and upper bound operations.
 * The floor(x) operation returns the greatest element less than or equal to xx,
 * and similarly, ceiling(x) returns the least element greater than or equal to xx in the set. With that,
 * we first check if the smallest element in the set of prefixes is �ܡ� to our required sum. If it this,
 * we get that prefix since it might improve leastDiff. Similarly, if the largest element is �ݡ� our required sum,
 * we find the least element greater than or equal to the sum we need to balance out, and check whether it helps.
 * Created by K25553 on 11/30/2016.
 */
public class SubarraySumClosestToK {
    class Element implements Comparable<Element>{
        int val;
        int index;
        public Element(int v, int i){
            val = v;
            index = i;
        }

        public int compareTo(Element other){
            return this.val-other.val ;
        }

        public int getIndex(){
            return index;
        }

        public int getValue(){
            return val;
        }
    }
    public int[] subarraySumClosest(int[] x) {
        TreeSet<Element> treeSet = new TreeSet<>();
        int prefix = 0;
        treeSet.add(new Element(0, -1));
        int minDiff = Integer.MAX_VALUE;
        int res [] = new int[2];
        for (int i =0; i< x.length; i++){
            prefix += x[i];
            if(treeSet.first().val<= prefix){
                Element low  = treeSet.floor(new Element(prefix, -2));
                int sum = prefix -low.val;
                if(Math.abs(minDiff)>Math.abs(sum-prefix)){
                    minDiff = prefix -sum;
                    res[1]= i;
                    res[0]= low.index+1;
                }
            }
            if(treeSet.last().val>= prefix){
                Element high  = treeSet.ceiling(new Element(prefix, -2));
                int sum = prefix -high.val;
                if(Math.abs(minDiff)>Math.abs(sum-prefix)){
                    minDiff = prefix -sum;
                    res[1]= i;
                    res[0]= high.index+1;
                }
            }
            treeSet.add(new Element(prefix, i));
        }
        return res;

    }

    public static int closestToT(int[] x, int t){
        TreeSet<Integer> treeSet = new TreeSet<>();
        int prefix = 0;
        treeSet.add(prefix);
        int minDiff = Integer.MAX_VALUE;
        int res = 0;
        for(int i : x){
            prefix += i;
            int rest = i - t;
            //greatest value smaller than t
            if(treeSet.first()<= rest ){
                int sum = prefix - treeSet.floor(rest);
                int crtDiff = Math.abs(sum -t);
                if(minDiff>crtDiff){
                    res = sum;
                    minDiff = crtDiff;
                }
            }
            if(treeSet.last()>= rest){
                int sum = prefix- treeSet.ceiling(t);
                int crtDiff = Math.abs(sum-t);
                if(minDiff>crtDiff){
                    res = sum ;
                    minDiff = crtDiff;
                }
            }
            treeSet.add(prefix);
        }
        return res;
    }
}
