/**
 * 
 */
package dp.matrix;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Given an integer array, find a subarray with sum closest to zero. Return the indexes of the first number and last number.

Example 
Given [-3, 1, 1, -3, 5], return [0, 2], [1, 3], [1, 1], [2, 2] or [0, 4]
Challenge 
O(nlogn) time

 * @author Tiannan
 *Analysis:
any subarray sum [ij]= (array sum[0,j] - subarray sum[0,i]): sum[2,3]= sum[0,3]-sum[0,1]
for each sum[i]= sum[0,i]
sort sum[]
for each ajacent sum [i] and sum[i+1]
diff btw sum i and sum i+1 is from i-j abs(0-i - 0-j),
if diff < min
 sumarray {min{sum i. index, sum i+1. index},max{sum i. index, sum i+1. index} }
 */
public class SubarraySumClosest {
	class Element implements Comparable<Element>{
	    int val;
	    int index;
	    public Element(int v, int i){
	        val = v;
	        index = i;
	    }

	    public int compareTo(Element other){
	        return other.val -this.val ;
	    }

	    public int getIndex(){
	        return index;
	    }

	    public int getValue(){
	        return val;
	    }
	}


	    /**
	     * @param nums: A list of integers
	     * @return: A list of integers includes the index of the first number
	     *          and the index of the last number
	     */
	    public ArrayList<Integer> subarraySumClosest(int[] nums) {
	        ArrayList<Integer> res = new ArrayList<Integer>();
	        if (nums.length==0) return res;
	        //store all ele to array of ele with index and sum value from the 0-i
	        Element[] sums = new Element[nums.length+1];
	        sums[0] = new Element(0,-1);
	        int sum = 0;
	        for (int i=0;i<nums.length;i++){
	            sum += nums[i];
	            sums[i+1] = new Element(sum,i);
	        }
	        //sort it from max to min
	        //for loop to finding the min differ
	        Arrays.sort(sums);
	        int min = Math.abs(sums[0].getValue() - sums[1].getValue());
	        int start =  Math.min(sums[0].getIndex(), sums[1].getIndex())+1;
	        int end = Math.max(sums[0].getIndex(), sums[1].getIndex());
	        for (int i=1;i<nums.length;i++){
	            int diff = Math.abs(sums[i].getValue() - sums[i+1].getValue());
	            if (diff<min){
	                min = diff;
	                start = Math.min(sums[i].getIndex(), sums[i+1].getIndex())+1;
	                end  = Math.max(sums[i].getIndex(), sums[i+1].getIndex());
	            }
	        }

	        res.add(start);
	        res.add(end);
	        return res;
	    }
	    public int[] subarraySumClosest2(int[] a) {
	    	 int res[] = new int[2];
		    	if(a.length==0||a==null||a.length==1){
		    		return res;
		    	}
		    	int sum= 0;
		    	Element element[] = new Element[a.length];
		    	for (int i=0; i < a.length; i++){
		    		sum += a[i];
		    		element[i]=new Element(sum, i);
		    	}
		    	Arrays.sort(element);
		    	int min= Math.abs(element[0].getValue()-element[1].getValue());
		    	int index1 = Math.min(element[0].getIndex(),element[1].getIndex())+1;
		    	int index2 = Math.max(element[0].getIndex(),element[1].getIndex());
		    	for (int i=1; i < element.length-1; i++){
		    		if(Math.abs(element[i].getValue()-element[i+1].getValue())<= min){
		    		min=Math.abs(element[i].getValue()-element[i+1].getValue());
		    		index1 = Math.min(element[i].getIndex(),element[i+1].getIndex())+1;
			    	index2 = Math.max(element[i].getIndex(),element[i+1].getIndex());
		    		}
		    	}
		    	res[0]= index1;
		    	res[1]= index2;
		    	return res;
	    }

}
