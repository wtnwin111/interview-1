/**
 *
 */
package dp.matrix;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

/**
 * Given an integer array, find a subarray where the sum of numbers is zero.
 * Your code should return the index of the first number and the index of the
 * last number.
 *
 * ����
 *
 * Given [-3, 1, 2, -3, 4], return [0, 2] or [1, 3].
 *
 * @author Tiannan
 *
 *         �����еĺ͵�ֵ Ϊ��������� �� �����еĲ�ֵ
 *         O(N)�Ľⷨ��ʹ��Map ����¼index,
 *         sum��ֵ������������index��sum��ͬʱ����ʾ��index1+1��index2��һ���⡣
 *
 *         ע�⣺����һ��index = -1��Ϊ����ڵ㡣�������ǲſ��Լ�¼index1 = 0�Ľ⡣
 *
 *         �ռ临�Ӷȣ�O(N)
 */
public class SubarraySum {
	/**
	 * @param nums
	 *            : A list of integers
	 * @return: A list of integers includes the index of the first number
	 *          and the index of the last number
	 */
	public ArrayList<Integer> subarraySum(int[] nums) {
		// write your code here

		int len = nums.length;

		ArrayList<Integer> ret = new ArrayList<Integer>();

		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();

		// We set the index -1 sum to be 0 to let us more convient to count.
		map.put(0, -1);

		int sum = 0;
		for (int i = 0; i < len; i++) {
			sum += nums[i];

			if (map.containsKey(sum)) {
				// For example:
				// -3 1 2 -3 4
				// SUM: 0 -3 -2 0 -3 1
				// then we got the solution is : 0 - 2
				ret.add(map.get(sum) + 1);
				ret.add(i);
				return ret;
			}

			// Store the key:value of sum:index.
			map.put(sum, i);
		}

		return ret;
	}
	public static double closestToZero(double[] x){
		double[] cumulative = new double[x.length];
		cumulative[0] = x[0];
		for(int i = 1; i < x.length; i++){
			cumulative[i] = cumulative[i-1] + x[i];
		}
		Arrays.sort(cumulative);
		double mindiff = Double.MAX_VALUE;
		for(int i = 0; i < cumulative.length-1; i++){

			mindiff = Math.min(mindiff,cumulative[i+1] - cumulative[i]);
		}
		return mindiff;
	}
}
