package dp.sum;

import java.util.HashMap;
import java.util.Map;

/**Given an array of integers, find two numbers such that they add
 * up to a specific target number.

The function twoSum should return indices of the two numbers such
 that they add up to the target, where index1 must be less than 
 index2. Please note that your returned answers (both index1 and 
 index2) are NOT zero-based.
 * @author K25553
 *
 */
public class TwoSum {
	/*
     * @param numbers : An array of Integer
     * @param target : target = numbers[index1] + numbers[index2]
     * @return : [index1 + 1, index2 + 1] (index1 < index2)
     */
    public int[] twoSum1(int[] numbers, int target) {
       	if(numbers == null || numbers.length < 2) {
	    		return null;
	    	}
	        HashMap<Integer, Integer> hs = new HashMap<Integer, Integer>();
	        for(int i=0; i<numbers.length; i++){
	            hs.put(numbers[i], i+1);
	        }       
	        
	        int[] a = new int[2];
	        
	        for(int i=0; i<numbers.length ; i++){
	            if ( hs.containsKey( target - numbers[i] )){
	                int index1 = i+1;
	                int index2 = hs.get(target - numbers[i]);
	                if (index1 == index2){
	                    continue;
	                }
	                a[0] = index1;
	                a[1] = index2;
	                return a;
	            }
	        }
	        return a;
    }
// simplify sol 1
	public int[] twoSum2(int[] nums, int target) {
		Map<Integer, Integer> map = new HashMap<>();
		for (int i = 0; i < nums.length; i++) {
			int complement = target - nums[i];
			if (map.containsKey(complement)) {
				return new int[] { map.get(complement), i };
			}
			map.put(nums[i], i);
		}
		throw new IllegalArgumentException("No two sum solution");
	}

    //
    public int[] twoSum3(int[] nums, int target) {
        for (int i = 0; i < nums.length; i++) {
            for (int j = i + 1; j < nums.length; j++) {
                if (nums[j] == target - nums[i]) {
                    return new int[] { i, j };
                }
            }
        }
        throw new IllegalArgumentException("No two sum solution");
    }
	//Given an array of integers that is already sorted in ascending order, find two numbers such that they add up to a specific target number.
	public int[] twoSum(int[] n, int t) {
		int[] res = new int[2];
		if(n==null||n.length==0){
			return res;
		}
		int l=0,r=n.length-1;
		while(l<r){
			int sum = n[l]+n[r];
			if (sum==t){
				res[0]=l;
				res[1]=r;
				break;
			}
			else if(sum>t ){
				r--;
			}
			else{
				l++;
			}
		}
		return res;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
