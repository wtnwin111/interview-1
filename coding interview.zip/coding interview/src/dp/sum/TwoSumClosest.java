/**
 *
 */
package dp.sum;

import java.util.Arrays;

/**Given an array nums of n integers, find two integers in nums such that the sum is closest to a given number, target.

 Return the difference between the sum of the two integers and the target.

 Have you met this question in a real interview? Yes
 Example
 Given array nums = [-1, 2, 1, -4], and target = 4.

 The minimum difference is 1. (4 - (2 + 1) = 1).
 * @author K25553
 *
 */
public class TwoSumClosest {
	/**
	 * @param nums
	 *            an integer array
	 * @param target
	 *            an integer
	 * @return the difference between the sum and the target
	 */
	public int twoSumCloset(int[] nums, int target) {
		Arrays.sort(nums);
		int l = 0, r = nums.length - 1, diff = Integer.MAX_VALUE;
		while (l < r) {
			if (nums[l] + nums[r] > target) {
				if (nums[l] + nums[r] - target < diff) {
					diff = nums[l] + nums[r] - target;
				}
				r--;
			} else {
				if (target - nums[l] - nums[r] < diff) {
					diff = target - nums[l] - nums[r];
				}
				l++;
			}
		}
		return diff;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
