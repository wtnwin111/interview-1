package Set;

import java.util.ArrayList;
import java.util.HashMap;

/**Given a digit string excluded 01, return all possible letter combinations that the number could represent.

 A hmping of digit to letters (just like on the telephone buttons) is given below.

 Given "23"

 Return ["ad", "ae", "af", "bd", "be", "bf", "cd", "ce", "cf"]
 * Created by K25553 on 9/13/2016.
 */
public class LetterCombinationsofaPhoneNumber {
    /**
     * @param digits A digital string
     * @return all posible letter combinations
     */
    public ArrayList<String> letterCombinations(String digits) {
        ArrayList<String> result =  new ArrayList<String>();
        if (digits == null || digits.equals("")) {
            return result;
        }

        HashMap<Character, char[]> hm = new HashMap<>();
        hm.put('0', new char[] {});
        hm.put('1', new char[] {});
        hm.put('2', new char[] { 'a', 'b', 'c' });
        hm.put('3', new char[] { 'd', 'e', 'f' });
        hm.put('4', new char[] { 'g', 'h', 'i' });
        hm.put('5', new char[] { 'j', 'k', 'l' });
        hm.put('6', new char[] { 'm', 'n', 'o' });
        hm.put('7', new char[] { 'p', 'q', 'r', 's' });
        hm.put('8', new char[] { 't', 'u', 'v'});
        hm.put('9', new char[] { 'w', 'x', 'y', 'z' });

        StringBuilder sb = new StringBuilder();
        helper(hm, digits, sb, result, 0);

        return result;

    }

    private void helper(HashMap<Character, char[]> hm, String digits, StringBuilder sb, ArrayList<String> result, int index) {
        if(sb.length()==digits.length()){
            result.add(new String(sb.toString()) );
            return;
        }
        for (char c: hm.get(digits.charAt(index)) ){
            sb.append(c);
            helper(hm,digits,sb,result,index+1);
            sb.deleteCharAt(sb.length()-1);
        }
    }

}
