package Set;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Given a set of distinct integers, return all possible subsets.


Example 

If S = [1,2,3], a solution is:
[
  [3],
  [1],
  [2],
  [1,2,3],
  [1,3],
  [2,3],
  [1,2],
  []
]

 */

/**
 * @author Tiannan
 *dfs
 */
public class Subsets {
	 /**
     * @param S: A set of numbers.
     * @return: A list of lists. All valid subsets.
     */
    public static ArrayList<ArrayList<Integer>> subsets(ArrayList<Integer> s) {
        // write your code here
    	ArrayList<ArrayList<Integer>> result= new ArrayList<ArrayList<Integer>>();
    	if(s==null||s.size()==0){
    		return result;
    	}
    	ArrayList<Integer> list= new ArrayList<Integer>();
    	dfs(result,list,s,0);
    	return result;
    	
    }
	private static void dfs(ArrayList<ArrayList<Integer>> result,
			ArrayList<Integer> list, ArrayList<Integer> s, int pos) {
		result.add(new ArrayList<Integer>(list));
		for(int i=pos;i<s.size();i++){
			list.add(s.get(i));
			dfs(result,list,s,i+1);
			list.remove(list.size()-1);
			
		}
		
	}
	
	/**
     * @param S: A set of numbers.
     * @return: A list of lists. All valid subsets.
     */
    public static ArrayList<ArrayList<Integer>> subsets1(int[] nums) {
    	ArrayList<ArrayList<Integer>> res = new ArrayList<ArrayList<Integer>>();
    	if(nums==null||nums.length==0){
    		return  res;
    	}
    	ArrayList<Integer> list = new ArrayList<Integer>();
    	dfs1(res, list, nums, 0);
    	
		return res;

    }
	private static void dfs1(ArrayList<ArrayList<Integer>> res,
			ArrayList<Integer> list, int[] nums, int pos) {
		res.add(new ArrayList<Integer>(list));
        for (int i = pos; i < nums.length; i++) {
            list.add(nums[i]);
            dfs1(res, list, nums, i + 1);
            list.remove(list.size()-1);
        }
		
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> list= new ArrayList<Integer>(Arrays.asList(1,2,3,4));
		int num[]={
				1,2,3,4
		};
		System.out.print(subsets(list).toString());
		System.out.print(subsets1(num).toString());
	}

}
