package Set;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Given a set of candidate numbers (C) and a target number (T),
 find all unique combinations in C where the candidate numbers sums to T.
 The same repeated number may be chosen from C unlimited number of times.

 For example, given candidate set 2,3,6,7 and target 7,
 A solution set is:
 [7]
 [2, 2, 3]

 Have you met this question in a real interview? Yes
 Example
 given candidate set 2,3,6,7 and target 7,
 A solution set is:
 [7]
 [2, 2, 3]

 Note
 - All numbers (including target) will be positive integers.
 - Elements in a combination (a1, a2, �� , ak) must be in non-descending order.
 (ie, a1 �� a2 �� �� �� ak).
 - The solution set must not contain duplicate combinations.
 * Created by K25553 on 7/26/2016.
 *  Permutations ʮ�����ƣ��������ڼ�֦������ͬ����������һ��Ԫ�ر����ʹ�ã��ʵݹ�ʱ���������ֵ�������������� for ѭ���ı䡣
 */
public class CombinationSum {
    /**
     * @param c: A list of integers
     * @param t:An integer
     * @return: A list of lists of integers
     */
    public List<List<Integer>> combinationSum(int[] c, int t) {
        List<List<Integer>> res = new ArrayList<>();
        if(c.length==0|| c==null){
            return res;
        }
        Arrays.sort(c);
        List<Integer> list = new ArrayList<>();
        dfs(c,t,0,res,list);
        return res;
    }

    private void dfs(int[] c, int t, int pos, List<List<Integer>> res, List<Integer> list) {
        if(t==0){
            res.add(new ArrayList<>(list));
            return;
        }
        int len=c.length;
        for(int i=pos; i<len;i++){
            if(t<c[i]){
                return;
            }
            list.add(c[i]);
            dfs(c,t-c[i],i,res,list);
            list.remove(list.size()-1);

        }
    }

}
