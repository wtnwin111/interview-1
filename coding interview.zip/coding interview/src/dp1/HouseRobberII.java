package dp1;

/**After robbing those houses on that street, the thief has found himself a new place for his thievery so that he will not get too much attention. This time, all houses at this place are arranged in a circle. That means the first house is the neighbor of the last one. Meanwhile, the security system for these houses remain the same as for those in the previous street.

 Given a list of non-negative integers representing the amount of money of each house, determine the maximum amount of money you can rob tonight without alerting the police.

 Notice

 This is an extension of House Robber.

 Have you met this question in a real interview? Yes
 Example
 nums = [3,6,4], return 6
 * Created by wtnwi on 9/18/2016.
 * if nums of houses are even, then there is not effect
 * else (odd), calcu
 */
public class HouseRobberII {
    /**
     * @param a: An array of non-negative integers.
     * return: The maximum amount of money you can rob tonight
     */
    public int houseRobber2(int[] a) {
        if(a.length==0||a==null){
            return 0;
        }
        if(a.length==1){
            return a[0];
        }else if(a.length==2){
            return Math.max(a[1], a[0]);
        }
       return Math.max(rob(a,0,a.length-2),rob(a,1,a.length-1) );
    }

    private int rob(int[] a, int l, int r) {
        if(l==r){
            return a[l];
        }else if(r-l==1){
            return Math.max(a[l], a[r]);
        }
        int dp[] = new int [2];
       dp[l%2]= a[l];
        dp[(l+1)%2] = Math.max(a[l], a[l+1]);

        for(int i=l+2;i<=r;i++){
            dp[i%2]=Math.max(dp[(i-1)%2], dp[(i-2)%2]+a[i]);
        }
        return dp[r%2];
    }
}
