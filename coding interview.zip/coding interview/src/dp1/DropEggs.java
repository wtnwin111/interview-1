package dp1;

/**There is a building of n floors. If an egg drops from the k th floor or above, it will break. If it's dropped from any floor below, it will not break.

 You're given two eggs, Find k while minimize the number of drops for the worst case. Return the number of drops in the worst case.

 Have you met this question in a real interview? Yes
 Clarification
 For n = 10, a naive way to find k is drop egg from 1st floor, 2nd floor ... kth floor. But in this worst case (k = 10), you have to drop 10 times.

 Notice that you have two eggs, so you can drop at 4th, 7th & 9th floor, in the worst case (for example, k = 9) you have to drop 4 times.

 Example
 Given n = 10, return 4.
 Given n = 100, return 14
 * Created by K25553 on 11/14/2016.
 *Let we make our first attempt on x'th floor.

 If it breaks, we try remaining (x-1) floors one by one.
 So in worst case, we make x trials.

 If it doesn��t break, we jump (x-1) floors (Because we have
 already made one attempt and we don't want to go beyond
 x attempts.  Therefore (x-1) attempts are available),
 Next floor we try is floor x + (x-1)

 Similarly, if this drop does not break, next need to jump
 up to floor x + (x-1) + (x-2), then x + (x-1) + (x-2) + (x-3)
 and so on.

 Since the last floor to be tired is 100'th floor, sum of
 series should be 100 for optimal value of x.

 x + (x-1) + (x-2) + (x-3) + .... + 1  = 100

 x(x+1)/2  = 100
 x = 13.651

 Therefore, we start trying from 14'th floor. If Egg breaks
 we one by one try remaining 13 floors.  If egg doesn't break
 we go to 27th floor.
 If egg breaks on 27'th floor, we try floors form 15 to 26.
 If egg doesn't break on 27'th floor, we go to 39'th floor.

 An so on...

 */
public class DropEggs {
    /**
     * @param n an integer
     * @return an integer
     */
    public int dropEggs(int n) {
        if(n==1||n==0){
            return 1;
        }
        long ans = 0;
        for (int i = 1; ; ++i) {
            ans += (long)i;
            if (ans >= (long)n)
                return i;
        }
    }
}
