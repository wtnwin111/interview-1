/**
 *
 */
package dp1;

/**
 * There are n coins with different value in a line. Two players take turns to
 * take one or two coins from left side until there are no more coins left. The
 * player who take the coins with the most value wins.
 *
 * Could you please decide the first player will win or lose?
 * Example
 * Given values array A = [1,2,2], return true.
 * 
 * Given A = [1,2,4], return false.
 * 
 * @author Tiannan
 *analysis: dp[i]= starting from first one, in the length i array, the max fist can get
 *max(min(dp[-2],dp[-3])+v[n-i], min(dp[-3],dp[-4])+v[n-i]+v[n-i+1])
 *			6
 *	f	-1		-2
 *		5		 4
 *s	-2	   -3	-3		-4
 *	 4		3	 3		  2	
 */
public class CoinsinaLineII {

	/**
	 * @param values
	 *            : an array of integers
	 * @return: a boolean which equals to true if the first player will win
	 */
	public boolean firstWillWin(int[] values) {
		// write your code here
		int[] dp = new int[values.length + 1];
		boolean[] flag = new boolean[values.length + 1];
		int sum = 0;
		for (int now : values) {
			sum += now;
		}

		return sum < 2 * MemorySearch(values.length, dp, flag, values);
	}

	int MemorySearch(int n, int[] dp, boolean[] flag, int[] values) {
		if (flag[n] == true) {
			return dp[n];
		}
		flag[n] = true;
		if (n == 0) {
			dp[n] = 0;
		} else if (n == 1) {
			dp[n] = values[values.length - 1];
		} else if (n == 2) {
			dp[n] = values[values.length - 1] + values[values.length - 2];
		} else if (n == 3) {
			dp[n] = values[values.length - 2] + values[values.length - 3];
		} else {
			dp[n] = Math.max(
					Math.min(MemorySearch(n - 2, dp, flag, values),
							MemorySearch(n - 3, dp, flag, values))
							+ values[values.length - n],
							Math.min(MemorySearch(n - 3, dp, flag, values),
									MemorySearch(n - 4, dp, flag, values))
									+ values[values.length - n]
											+ values[values.length - n + 1]);
		}

		return dp[n];
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
