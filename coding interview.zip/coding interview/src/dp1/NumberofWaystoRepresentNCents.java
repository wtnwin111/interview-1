package dp1;

/**Given an infinite number of quarters (25 cents), dimes (10 cents), nickels (5 cents) and pennies (1 cent), write code to calculate the number of ways of representing n cents.

 Have you met this question in a real interview? Yes
 Example
 n = 11

 11 = 1 + 1 + 1... + 1
 = 1 + 1 + 1 + 1 + 1 + 1 + 5
 = 1 + 5 + 5
 = 1 + 10
 return 4
 * Created by K25553 on 10/25/2016.
 * j    123456789 10
 * i=1  111111111 1
 * 5    000011111 2
 * 10             1
 * sum  111122222 4
 */
public class NumberofWaystoRepresentNCents {
    /**
     * @param n an integer
     * @return an integer
     */
    public int waysNCents(int n) {
        if(n==0){
            return 0;
        }else if ( n<5){
            return 1;
        }
        int dic[] = new int[]{
                1,5,10, 25
        };
        int dp[]  = new int[n+1];
        dp[0]=1;
        //MUST FOR DIC THEN FOR DP, SINCE FOR DIC 1  EVERY ELE SHOULD ONLY UPDATE ITS DP UNDER DIC 1 OTHER
        for( int i= 1; i<n+1; i++ ){
            for( int j=0; j<4; j++){
                if(dic[j]<=i){
                    dp[i]+= dp[i-j];
                }
            }
        }
        return dp[n];
    }
}
