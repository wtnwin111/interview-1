package dp1;

/**
 * Created by K25553 on 9/16/2016.
 */
public class DecodeWays {
    /**
     * @param s a string,  encoded message
     * @return an integer, the number of ways decoding
     */
    public int numDecodings(String s) {
        if(s.length()==0||s==null){
            return 0;
        }
        int []dp = new int[s.length()+1];
        dp[0] = 1; // for dp[i-1], e.g. 12= dp1 +dp2 + dp0 where dp12 = dp 0 (index 2-2)
        if(s.charAt(0)=='0'){
            dp[1]=0;
        }else{
            dp[1]=1;
        }

        for(int i =2; i < s.length()+1;i++){
            if(s.charAt(i-1)!='0'){// 12 ->ab or l ==2   but 10 obly Z ==1 (dpi-2==dp0)
                dp[i]=dp[i-1];
            }

            int two= Integer.valueOf(s.substring(i-2, i));
            if(two>=10&&two<=26){
                dp[i]+=dp[i-2];
            }

        }
        return dp[s.length()];
    }
}
