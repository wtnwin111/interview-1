/**
 *
 */
package dp1;

/**
 * 有 n 个硬币排成一条线，每一枚硬币有不同的价值。
 * 两个参赛者轮流从任意一边取一枚硬币，知道没有硬币为止。
 * 计算拿到的硬币总价值，价值最高的获胜。
 *
 * 请判定 第一个玩家 是输还是赢？
 *
 * 您在真实的面试中是否遇到过这个题？ Yes
 * 样例
 * 给定数组 A = [3,2,2], 返回 true.
 *
 * 给定数组 A = [1,2,4], 返回 true.
 *
 * 给定数组 A = [1,20,4], 返回 false.
 *
 * @author Tiannan
 *         state: f[x][y] 现在还第x到第y的硬币，现在先⼿取硬币的⼈最后最多取硬币价值
 *         function:
 *         f[x][y] = max(min(f[x+2][y], f[x+1][y-1])+a[x] ) ,
 *         (min(f[x][y-2], f[x+1][y-1])+a[y] )
 *         intialize:
 *         f[x][x] = a[x],
 *         f[x][x+1] = max(a[x],a[x+1]),
 *
 *         Answer:f[n][m]
 */
public class CoinsinaLineIII {
	/**
	 * @param values
	 *            : an array of integers
	 * @return: a boolean which equals to true if the first player will win
	 */
	public boolean firstWillWin1(int[] v) {
		int len = v.length;
		if (v == null || len == 0) {
			return false;
		}
		int sum = 0;
		for (int a : v) {
			sum += a;
		}
		boolean[][] flag = new boolean[len + 1][len + 1];
		int dp[][] = new int[len + 1][len + 1];// represent the num of value
		// collect from first guy from
		// index x to y;
		return sum < 2 * MemorySearch1(0, len + 1, dp, flag, v);
	}

	private int MemorySearch1(int l, int r, int[][] dp, boolean[][] flag,
			int[] v) {
		if (flag[l][r]) {
			return dp[l][r];
		}
		flag[l][r] = true;
		if (l > r) {
			// error: return 0; not register the data to dp[][];
			dp[l][r] = 0;
		} else if (l == r) {
			// error: return v[l];
			dp[l][r] = v[l];
		} else if (l + 1 == r) {
			// error:return Math.max(v[l], v[r]);
			dp[l][r] = Math.max(v[l], v[r]);
		} else {
			int l_pick = Math.min(MemorySearch1(l + 1, r - 1, dp, flag, v),
					MemorySearch1(l + 2, r, dp, flag, v)) + v[l];
			int r_pick = Math.min(MemorySearch1(l + 1, r - 1, dp, flag, v),
					MemorySearch1(l, r - 2, dp, flag, v)) + v[r];
			dp[l][r] = Math.max(l_pick, r_pick);
		}
		return dp[l][r];
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
