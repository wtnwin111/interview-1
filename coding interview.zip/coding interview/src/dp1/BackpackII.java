package dp1;

public class BackpackII {
	/*
	 * Given n items with size Ai and value Vi, and a backpack with size m.
	 * What's the maximum value can you put into the backpack?
	 * Example
	 * Given 4 items with size [2, 3, 5, 7] and value [1, 5, 2, 4], and a
	 * backpack with size 10. The maximum value is 9.
	 */
	/**
	 * f[m]= max f[m-a[i]]+v[i], init f[0-m]=0,
	 *
	 * @param m
	 *            : An integer m denotes the size of a backpack
	 * @param a
	 *            & V: Given n items with size A[i] and value V[i]
	 * @return: The maximum value
	 */
	public int backPackII1(int m, int[] a, int v[]) {
		int f[] = new int[m + 1];
		for (int i = 0; i < m + 1; i++) {
			f[i] = 0;
		}
		for (int i = 0; i < a.length; i++) {
			for (int j = m; j >= a[i]; j--) {
				f[j] = Math.max(f[j], f[j - a[i]] + v[i]);
			}
		}
		return f[m];
	}
    public int backPackII(int m, int[] A, int V[]) {
        int[][] res = new int[A.length+1][m+1];
        res[0][0] = 0;
        for (int i=1; i<=A.length; i++) {
            for (int j=0; j<=m; j++) {
                if (j - A[i-1] < 0)
                    res[i][j] = res[i-1][j];
                if (j - A[i-1] >= 0) {
                    res[i][j] = Math.max(res[i-1][j], res[i-1][j-A[i-1]]+V[i-1]);
                }
            }
        }

        return res[A.length][m];
    }
	public static void main(String[] args) {
        int m=200, a[] = new int[] {9,58,86,11,28,62,15,68}, v[] = new int[]{83,14,54,79,72,52,48,62};
//        System.out.println(backPackII(m,a,v));

	}

}
