package dp1;

/**There is a building of n floors. If an egg drops from the k th floor or above, it will break.
 * If it's dropped from any floor below, it will not break.
 You're given m eggs, Find k while minimize the number of drops for the worst case. Return the number of drops in the worst case.

 Have you met this question in a real interview? Yes
 Example
 Given m = 2, n = 100 return 14
 Given m = 2, n = 36 return 8
 * Created by K25553 on 11/14/2016.
 * When we drop an egg from a floor x, there can be two cases (1) The egg breaks (2) The egg doesn��t break.

 1) If the egg breaks after dropping from xth floor, then we only need to check for floors lower than x with remaining eggs; so the problem reduces to x-1 floors and n-1 eggs
 2) If the egg doesn��t break after dropping from the xth floor, then we only need to check for floors higher than x; so the problem reduces to k-x floors and n eggs.

 Since we need to minimize the number of trials in worst case, we take the maximum of two cases. We consider the max of above two cases for every floor and choose the floor which yields minimum number of trials.

 k ==> Number of floors
 n ==> Number of Eggs
 eggDrop(n, k) ==> Minimum number of trails needed to find the critical
 floor in worst case.
 eggDrop(n, k) = 1 + min{max(eggDrop(n - 1, x - 1), eggDrop(n, k - x)):
 x in {1, 2, ..., k}}
 */
public class DropEggsII {
    /**
     * @param m the number of eggs
     * @param n the umber of floors
     * @return the number of drops in the worst case
     */
    public int dropEggs2(int m, int n) {
        if(n==1||n==0){
            return n;
        }
        if(m==1){
            return n;
        }
// We need one trial for one floor and0 trials for 0 floors
        int dp[][]= new int[m+1][n+1];
        for(int i=1; i<= m; i++){
            dp[i][0]=0;
            dp[i][1]=1;
        }
        // We always need j trials for one egg and j floors.
        for(int i=1; i<= n; i++){
            dp[1][i]=i;
        }
        for(int i= 2; i<=m; i++){
            for (int j=2; j<=n;j++){
                dp[i][j] = Integer.MAX_VALUE;
                for(int k=1;k<=j;k++ ){
                    dp[i][j] = Math.min(dp[i][j], 1+Math.max(dp[i][j-k],dp[i-1][k-1]));
                }
            }
        }

        return dp[m][n];
    }
}
