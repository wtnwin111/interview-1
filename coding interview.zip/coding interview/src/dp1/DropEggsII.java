package dp1;

/**There is a building of n floors. If an egg drops from the k th floor or above, it will break.
 * If it's dropped from any floor below, it will not break.
 You're given m eggs, Find k while minimize the number of drops for the worst case. Return the number of drops in the worst case.

 Have you met this question in a real interview? Yes
 Example
 Given m = 2, n = 100 return 14
 Given m = 2, n = 36 return 8
 * Created by K25553 on 11/14/2016.
 */
public class DropEggsII {
    /**
     * @param m the number of eggs
     * @param n the umber of floors
     * @return the number of drops in the worst case
     */
    public int dropEggs2(int m, int n) {
        // Write your code here
    }
}
