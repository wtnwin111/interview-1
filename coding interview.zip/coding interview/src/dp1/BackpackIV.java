package dp1;

import java.util.ArrayList;
import java.util.Arrays;

/**Given n items with size nums[i] which an integer array and all positive numbers,no duplicates.
 * An integer target denotes the size of a backpack. Find the number of possible fill the backpack.

 Each item may be chosen unlimited number of times

 Example
 Given candidate items [2,3,6,7] and target 7,

 A solution set is:
 [7]
 [2, 2, 3]
 return 2
 * Created by K25553 on 9/6/2016.
 */
public class BackpackIV {
    /**
     * @param nums an integer array and all positive numbers, no duplicates
     * @param target an integer
     * @return an integer
     */
    public int backPackIV(int[] nums, int target) {

        if(nums==null||nums.length==0){
            return 0;
        }
        Arrays.sort(nums);
        ArrayList<ArrayList<Integer>> res = new ArrayList<>();

        dfs(nums, target, 0, new ArrayList<Integer>(),res);
        return res.size();
    }

    private void dfs(int[] nums, int target, int pos, ArrayList<Integer> path, ArrayList<ArrayList<Integer>> res) {
        if (target==0 ){
            res.add(new ArrayList<>(path));
            return;
        }
        for(int i=pos; i<nums.length; i++){
            if(target<nums[i]){
                return;
            }
            path.add(nums[i]);
            dfs(nums, target-nums[i], i, path, res);
            path.remove(path.size()-1);
        }
    }
    /**
     * @param nums an integer array and all positive numbers, no duplicates
     * @param target an integer
     * @return an integer
     */
    public int backPackIV2(int[] nums, int target) {

        if(nums==null||nums.length==0){
            return 0;
        }
       int f[]= new int[target+1];
        f[0]= 0;
        for( int i =1; i< target+1;i++){
            for( int j =0; j<nums.length ;j++){
                if(nums[j]<=i){
                    f[i]+=f[j-nums[i]];
                }

            }
        }
        return f[target];

    }

}
