package dp1;

/**Given n kind of items with size Ai and value Vi( each item has an infinite number available) and a backpack with size m.
 *  What's the maximum value can you put into the backpack?
 *  Given 4 items with size [2, 3, 5, 7] and value [1, 5, 2, 4], and a backpack with size 10. The maximum value is 15.
 * Created by K25553 on 9/7/2016.
 */
public class BackpackIII {
    /**
     * @param A an integer array
     * @param V an integer array
     * @param m an integer
     * @return an array
     */
    public int  backPackIII(int m, int[] a, int v[]) {
        int f[][] = new int[a.length][m+1];
        f[0][a[0]] =v[0];
        for (int i = 0; i < a.length; i++) {
            for (int j =a[i]; j < m+1; j++) {
                f[i][j] = Math.max(f[i-1][j], f[i-1][j - a[i]] + v[i]);
            }
        }
        return f[a.length-1][m];
    }
    public int  backPackII1(int m, int[] a, int v[]) {
        int dp[] = new int[m+1];

        for (int i = 0; i < a.length; i++) {
            for (int j =a[i]; j < m+1; j++) {
                dp[j] = Math.max(dp[j], dp[j - a[i]] + v[i]);
            }
        }
        return dp[m];
    }
}
