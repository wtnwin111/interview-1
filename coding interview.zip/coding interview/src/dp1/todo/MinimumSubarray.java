package dp1.todo;

import java.util.ArrayList;

/**Given an array of integers, find the subarray with smallest sum.

 Return the sum of the subarray.

 Notice

 The subarray should contain one integer at least.

 Have you met this question in a real interview? Yes
 Example
 For [1, -1, -2, 1], return -3.
 * Created by K25553 on 9/15/2016.
 *
 */
public class MinimumSubarray {
    /**
     * @param nums: a list of integers
     * @return: A integer indicate the sum of minimum subarray
     */
    public int minSubArray(ArrayList<Integer> nums) {
        int sum=0, sumMax= 0, min = Integer.MAX_VALUE;
        for(int i = 0; i< nums.size(); i++){
            sum += nums.get(i);
            min= Math.min(min, sum-sumMax);
            sumMax = Math.max(sumMax, sum);

        }
        return min;
    }
}
