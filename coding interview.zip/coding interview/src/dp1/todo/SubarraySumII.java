package dp1.todo;

/**Given an integer array, find a subarray where the sum of numbers is in a given interval.
 * Your code should return the number of possible answers. (The element in the array should be positive)

 Example
 Given [1,2,3,4] and interval = [1,3], return 4. The possible answers are:

 [0, 0]
 [0, 1]
 [1, 1]
 [2, 2]
 * Created by K25553 on 8/29/2016.
 *
 */
public class SubarraySumII {
    /**subarray sum= (array sum - its subarray sum): sum[2,3]= sum[0,3]-sum[0,1]
     * Given The element in the array should be positive
     * from sum [00] to sum[0len] it is increasing sums.
     * for each sum[i]
     *  {for each sum[j] from 0 to i-1
     *      if{start<=sum[i]-sum[j]<=end}
     *      {ct++;}
     *}
     *
     * optimzed: for each sum[i], the ct = ct (sum[i]-start in [0,len])-ct(sum[i]-end in [0,len])
     *
     *
     * {
     *
     *
     * }
     * @param a an integer array
     * @param start an integer
     * @param end an integer
     * @return the number of possible answer
     */
    public int subarraySumII2(int[] a, int start, int end) {
        if(a.length==0||a==null){
            return 0;
        }
        int ct = 0;
        for(int i=1; i < a.length; i++){
            a[i]+=a[i-1];
        }
        for(int i=0; i < a.length; i++){
            if(a[i]<=end&&a[i]>=start){
                ct++;
            }
            for(int j=0; j < i; j++){
                int sum= a[i]-a[j];
                if(sum<=end&&sum>=start){
                    ct++;
                }
            }
        }
        return ct;
    }
    public int subarraySumII(int[] a, int start, int end) {
        if(a.length==0||a==null){
            return 0;
        }
        int ct = 0;
        for(int i=1; i < a.length; i++){
            a[i]+=a[i-1];
        }
        for(int i=0; i < a.length; i++){
            if(a[i]<=end&&a[i]>=start){
                ct++;
            }
            ct+= find1(i,a, a[i]-start, true ) - find1(i,a, a[i]-end, false);
        }
        return ct;
    }

    private int find1 ( int len, int [] a, int val, boolean mode){
        if(val<=0){
            return 0;
        }
        int l=0, r=len,ans=0;
        if(mode==true){
            while(l<=r){
                int mid= l+r/2;
                if(a[mid]<=val){
                    ans=a[mid];
                    l=mid+1;
                }else {
                    r=mid-1;
                }
            }
        }else {
            while(l<=r){
                int mid= l+r/2;
                if(a[mid]>=val){
                    ans=a[mid];
                    r=mid-1;
                }else {
                    l=mid+1;
                }
            }
        }

        return ans;
    }

}
