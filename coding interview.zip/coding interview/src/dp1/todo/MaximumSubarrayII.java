/**
 * 
 */
package dp1.todo;

import java.util.ArrayList;

/**
 * Given an array of integers, find two non-overlapping subarrays which have the largest sum.

The number in each subarray should be contiguous.

Return the largest sum.
 * @author Tiannan
 *  find two non-overlapping subarrays which have the largest sum.
 *   two non-overlapping : a scope and a poiter split the scope into 2 ranges, range 1 (0,i)and range2 (i, len)
 *   to find max in 1 and 2, for 1, from 0 to i, for 2 from len to i
 *   reorganize logic in global: search from 0 to len to record each index max sub, search from len to 0 to record each index max sub,then find point which sub is max of legt[i]+right[i]
 *  1 2 non overlapping subs: for position i subl is max sub from 0 to i of all subs, subr is max from len-1 to i+1 of all subs
 *  2 max of 2 subs is max(max, subl+subr) from 0 to le-1
 */
public class MaximumSubarrayII {
    /**
     * @param nums: A list of integers
     * @return: An integer denotes the sum of max two non-overlapping subarrays
     */
    public static int maxTwoSubArrays(ArrayList<Integer> nums) {
        if(nums==null||nums.size()==0){
            return 0;
        }
        int len= nums.size();
        int [] l= new int[len];l[0]=nums.get(0);
        int [] r= new int[len];r[len-1]=nums.get(len-1);

        for(int i=1; i< len; i++){
            l[i]= Math.max(l[i-1]+nums.get(i),nums.get(i) );
        }
        for(int i=1; i< len; i++){
            l[i]= Math.max(l[i-1],l[i]);
        }
        for(int i=len-2; i> -1; i--){
            r[i]= Math.max(r[i+1]+nums.get(i), nums.get(i));
        }
        for(int i=len-2; i< -1; i--){
            r[i]= Math.max(r[i],r[i+1]);
        }
        int max = Integer.MIN_VALUE;
        for(int i = 0; i < len - 1; i++){
            max = Math.max(max, l[i] + r[i + 1]);
        }
        return max;
    }

	// sliding window:
	//if current ele is less than 0, sum =0,
	public static int maxTwoSubArrays(int []nums) {
		int [ ] left = new int [nums.length];
		int [ ] right = new int [nums.length];
		left[0]=nums[0];
		right[nums.length-1]= nums[nums.length-1];
		for(int i=1;i<nums.length;i++){
			left[i]=Math.max(nums[i], left[i-1]+nums[i]);

		}
		for(int i=nums.length-2;i>=0;i--){
			right[i]=Math.max(nums[i], right[i+1]+nums[i]);

		}
		int lmax,rmax;
		int max= lmax=rmax=Integer.MIN_VALUE;
		int i=1;int j= nums.length-2;
		while(i<j){
			lmax=Math.max(left[i], left[i-1]);
			rmax=Math.max(right[j], right[j+1]);
			i++;j--;
		}
		return lmax+rmax;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println(maxTwoSubArrays(new int []{-1,-2,-3,-100,-1,-50}));
        ArrayList<Integer> res = new ArrayList<Integer>();
        int dic[] = new int []{-1,-2,-3,-100,-1,-50};
        for (int i:dic){
            res.add(i);
        }

        System.out.println(maxTwoSubArrays(res));

    }

}
