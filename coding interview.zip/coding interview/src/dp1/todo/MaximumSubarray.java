/**
 *
 */
package dp1.todo;

/**
 * Given an array of integers, find a contiguous subarray which has the largest
 * sum.
 *
 * Notice
 *Constraints
 3<=N<=10^7
 1<=M<=2*10^5
 1<=a<=b<=N
 0<=k<=10^9
 * The subarray should contain at least one number.
 *
 * Have you met this question in a real interview? Yes
 * Example
 * Given the array [−2,2,−3,4,−1,2,1,−5,3], the contiguous subarray [4,−1,2,1]
 * has the largest sum = 6.
 *
 * @author K25553
 *         analysis: worst case all negative ele,
 *         then max sum would be [] = 0;
 *         so
 */
public class MaximumSubarray {
	// Version 2: Prefix Sum
	public int maxSubArray2(int[] A) {
		if (A == null || A.length == 0){
			return 0;
		}

		int max = Integer.MIN_VALUE, sum = 0, minSum = 0;
		for (int i = 0; i < A.length; i++) {
			sum += A[i];
			max = Math.max(max, sum - minSum);
			minSum = Math.min(minSum, sum);
		}

		return max;
	}
	/**
	 * @param nums
	 *            : A list of integers
	 * @return: A integer indicate the sum of max subarray
	 */
	public int maxSubArray(int[] nums) {
		if (nums.length == 0 || nums == null) {
			return 0;
		}

		int max = Integer.MIN_VALUE;
		int sum = 0;
		for (int i = 0; i < nums.length; i++) {
			sum += nums[i];
			max = Math.max(max, sum);
			sum = Math.max(sum, 0);
		}
		return max;
	}

	/**
	 * @param nums
	 *            : A list of integers
	 * @return: A integer indicate the sum of max subarray
	 */
	public int maxSubArray1(int[] nums) {
		if (nums.length == 0 || nums == null) {
			return 0;
		}
		int [] local = new int[nums.length];
        int [] global = new int[nums.length];
        local[0]= nums[0]; global[0]=nums[0];
        for (int i=1; i< nums.length;i++){
            local[i]=Math.max(nums[i], local[i-1]+nums[i]);
            global[i]= Math.max(local[i],global[i-1]);
        }
        return global[nums.length];
	}

}
