package tree;

/**
 * Created by K25553 on 9/19/2016.
 */
public class IdenticalBinaryTree {
    /**
     * @param a, b, the root of binary trees.
     * @return true if they are identical, or false.
     */
    public boolean isIdentical(TreeNode a, TreeNode b) {
        if(a==null&&b==null){
            return true;
        }
        if((a==null&&b!=null)||(a!=null&&b==null)){
            return false;
        }

        if(a.left==null&&a.right==null){
            return a.val==b.val;
        }
        return (a.val==b.val)&&isIdentical(a.left, b.left)&&isIdentical(a.right,b.right);
    }
}
