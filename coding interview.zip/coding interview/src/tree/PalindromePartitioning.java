/**
 * 
 */
package tree;

import java.util.ArrayList;

/**Given a string s, partition s such that 
 * every substring of the partition is a palindrome. 
 * Return all possible palindrome partitioning of s. For example,
 *  given s = "aab", Return [ ["aa","b"], ["a","a","b"] ]
 * @author K25553
 *  a aa aab
 *  a a,a ab\ aa b\
 *  a a b, 
 *  anlysis dfs :
 *   start (dic(string), cache(temp list of string), res(list of list of string ), index position)
 *   helper :
 *   cache ends: 
 *    if (pos == s.length()) {
	            result.add(new ArrayList<String>(path));
	            return;
	        }
	  cache proceed:
	     for
	  
 */
public class PalindromePartitioning {
	  public ArrayList<ArrayList<String>> partition(String s) {
	        ArrayList<ArrayList<String>> result = new ArrayList<ArrayList<String>>();
	        if (s == null) {
	            return result;
	        }

	        ArrayList<String> path = new ArrayList<String>();
	        helper(s, path, 0, result);

	        return result;
	    }

	    private boolean isPalindrome(String s) {
	        int beg = 0;
	        int end = s.length() - 1;
	        while (beg < end) {
	            if (s.charAt(beg) != s.charAt(end)) {
	                return false;
	            }

	            beg++;
	            end--;
	        }

	        return true;
	    }

	    private void helper(String s, ArrayList<String> path, int pos,
	            ArrayList<ArrayList<String>> result) {
	    	//cache ends
	        if (pos == s.length()) {
	            result.add(new ArrayList<String>(path));
	            return;
	        }
//cache proceeds:
	        for (int i = pos + 1; i <= s.length(); i++) {
	            String prefix = s.substring(pos, i);
	            if (!isPalindrome(prefix)) {
	                continue;
	            }

	            path.add(prefix);
	            helper(s, path, i, result);
	            path.remove(path.size() - 1);
	        }
	    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
