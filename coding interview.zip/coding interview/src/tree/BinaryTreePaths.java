package tree;

import java.util.ArrayList;
import java.util.List;

/**Given a binary tree, return all root-to-leaf paths.

 Have you met this question in a real interview? Yes
 Example
 Given the following binary tree:

 1
 /   \
 2     3
 \
 5
 All root-to-leaf paths are:

 [
 "1->2->5",
 "1->3"
 ]
 Tags
 Binary Tree Binary Tree Traversal Facebook Google
 * Created by K25553 on 9/19/2016.
 */
public class BinaryTreePaths {
    /**
     * @param root the root of the binary tree
     * @return all root-to-leaf paths
     */
    public List<String> binaryTreePaths(TreeNode root) {
        List<String> res = new ArrayList<String>();
        if(root==null){
            return res;
        }

        dfs(root,String.valueOf(root.val),res );
        return res;
    }

    private void dfs(TreeNode root, String path, List<String> res) {
        if( root==null){
            return;
        }
        if(root.left==null&&root.right==null){
            res.add(path);
            return;
        }
        if(root.left!=null){
            dfs(root.left, path+"->"+String.valueOf(root.left.val), res);
        }
        if(root.right!=null){
            dfs(root.right, path+"->"+String.valueOf(root.right.val), res);
        }
    }


}
