package tree;

import java.util.LinkedList;
import java.util.Queue;

public class BST {
Node root;
    public class Node {
        public int data;
        public Node left, right;

        public Node(int val) {
            this.data = val;
            this.left = this.right = null;
        }



        public void insert(int el) {

            Node tmp = root, p = null;
            while (null != tmp && el != tmp.data) {
                p = tmp;
                if (el < tmp.data)
                    tmp = tmp.left;
                else
                    tmp = tmp.right;
            }
            if (tmp == null) {
                if (null == p)
                    root = new Node(el);
                else if (el < p.data)
                    p.left = new Node(el);
                else
                    p.right = new Node(el);
            }
        }//

        public Node clone() {
            if (null == root)
                return null;
            Queue<Node> queue = new LinkedList<Node>();
            queue.add(root);
            Node n;

            Queue<Node> q2 = new LinkedList<Node>();
            Node fresh;
            Node root2 = new Node(root.data);
            q2.add(root2);

            while (!queue.isEmpty()) {
                n = queue.remove();
                fresh = q2.remove();
                if (null != n.left) {
                    queue.add(n.left);
                    fresh.left = new Node(n.left.data);
                    q2.add(fresh.left);
                }
                if (null != n.right) {
                    queue.add(n.right);
                    fresh.right = new Node(n.right.data);
                    q2.add(fresh.right);
                }
            }
            return root2;
        }//

        private void inOrder(Node n) {
            if (null == n) return;
            inOrder(n.left);
            System.out.format("%d;", n.data);
            inOrder(n.right);
        }//

    }}