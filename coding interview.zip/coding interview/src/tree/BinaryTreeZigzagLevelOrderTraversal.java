/**
 *
 */
package tree;

import java.util.ArrayList;
import java.util.Stack;

/**
 * Accepted
 *
 * Given a binary tree, return the zigzag level order traversal of its nodes'
 * values.
 * (ie, from left to right, then right to left for the next level and alternate
 * between).
 * Example
 *
 * Given binary tree {3,9,20,#,#,15,7},
 * 3
 * / \
 * 9 20
 * / \
 * 15 7
 *
 *
 *
 *
 * return its zigzag level order traversal as:
 * [
 * [3],
 * [20,9],
 * [15,7]
 * ]
 *
 * @author Tiannan
 *         use 2 stack and 1 boolean flag to switch order, rlease current level
 *         and store the next lever
 *         use arraylist <arraylist>
 *         while curent stack is not empty
 *         new arraylist to store current level of all nodes
 *         while current stake not empty
 *         arraylist add node = current stack.pop
 *         flag is order1 from left to right
 *         next stack.push node.left
 *         next stack.push node.right
 *         else
 *         next statck.push node.right
 *         next stack.push node left
 *         reverse current stack and next stack
 *         flag is not flag
 *         arraylist added to arraylist<arraylist>
 *
 *         return Maximum arraylist<arraylist>
 *
 */
public class BinaryTreeZigzagLevelOrderTraversal {
	public ArrayList<ArrayList<Integer>> zigzagLevelOrder(TreeNode root) {
		ArrayList<ArrayList<Integer>> result = new ArrayList<ArrayList<Integer>>();

		if (root == null) {
			return result;
		}

		Stack<TreeNode> currLevel = new Stack<TreeNode>();
		Stack<TreeNode> nextLevel = new Stack<TreeNode>();
		Stack<TreeNode> tmp;

		currLevel.push(root);
		boolean normalOrder = true;

		while (!currLevel.isEmpty()) {
			ArrayList<Integer> currLevelResult = new ArrayList<Integer>();

			while (!currLevel.isEmpty()) {
				TreeNode node = currLevel.pop();
				currLevelResult.add(node.val);

				if (normalOrder) {
					if (node.left != null) {
						nextLevel.push(node.left);
					}
					if (node.right != null) {
						nextLevel.push(node.right);
					}
				} else {
					if (node.right != null) {
						nextLevel.push(node.right);
					}
					if (node.left != null) {
						nextLevel.push(node.left);
					}
				}
			}

			result.add(currLevelResult);
			tmp = currLevel;
			currLevel = nextLevel;
			nextLevel = tmp;
			normalOrder = !normalOrder;
		}

		return result;

	}

	public ArrayList<ArrayList<Integer>> zigzagLevelOrder1(TreeNode root) {
		ArrayList<ArrayList<Integer>> resArrayList = new ArrayList<ArrayList<Integer>>();
		if (root == null) {
			return resArrayList;
		}
		Stack<TreeNode> now = new Stack<TreeNode>(), next = new Stack<TreeNode>();
		now.push(root);

		boolean order = true;

		while (!now.isEmpty() || !next.isEmpty()) {
			ArrayList<Integer> layer = new ArrayList<Integer>();
			while (!now.isEmpty()) {
				TreeNode node = now.pop();
				if (order) {
					if (node.left != null) {
						next.push(node.left);
					}
					if (node.right != null) {
						next.push(node.right);
					}
				} else {
					if (node.right != null) {
						next.push(node.right);
					}
					if (node.left != null) {
						next.push(node.left);
					}
				}

				layer.add(node.val);
			}
			resArrayList.add(layer);
			order = !order;
			Stack<TreeNode> temp = now;
			now = next;
			next = temp;
		}
		return resArrayList;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
