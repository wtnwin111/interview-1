package tree;

/**One way to serialize a binary tree is to use pre-order traversal. When we encounter a non-null node, we record the node's value.
 * If it is a null node, we record using a sentinel value such as #.

     _9_
     /   \
    3     2
   / \   / \
  4   1 #  6
  / \ / \   / \
 #  ##  #  #   #
 For example, the above binary tree can be serialized to the string "9,3,4,#,#,1,#,#,2,#,6,#,#", where # represents a null node.

 Given a string of comma separated values, verify whether it is a correct preorder traversal serialization of a binary tree. Find an algorithm without reconstructing the tree.

 Each comma separated value in the string must be either an integer or a character '#' representing null pointer.

 You may assume that the input format is always valid, for example it could never contain two consecutive commas such as "1,,3".

 Example 1:
 "9,3,4,#,#,1,#,#,2,#,6,#,#"
 Return true

 Example 2:
 "1,#"
 Return false

 Example 3:
 "9,#,#,1"
 Return false
 * Created by K25553 on 9/29/2016.
 */
public class VerifyPreorderSerializationofaBinaryTree {
    public boolean isValidSerialization1(String preorder) {
        String s = preorder;
        boolean flag = true;
        while (s.length() > 1) {
            int index = s.indexOf(",#,#");
            if (index < 0) {
                flag = false;
                break;
            }
            int start = index;
            while (start > 0 && s.charAt(start - 1) != ',')
            {
                start --;
            }
            if (s.charAt(start) == '#') {
                flag = false;
                break;
            }
            s = s.substring(0, start) + s.substring(index + 3);
        }
        if (s.equals("#") && flag)
            return true;
        else
            return false;
    }

    public boolean isValidSerialization(String preorder) {
        String [] dic = preorder.split(",");
        if(dic[0].equals("#")&&dic.length>1){
            return false;
        }
        boolean l = true; int ct=0;
        return dfs(dic, 1, dic.length-1,l,ct );
    }

    private boolean dfs(String[] dic, int start, int end, boolean l, int ct ) {
        if(start>end&& ct>((end+1)/2+1)){
            return false;
        }
        //if crt is digit search l child branch
        if( !dic[start].equals("#")){
            l=true;
            return dfs(dic, start+1, end,l,ct);
        }
        //crt is l# and r# then it is leave l and l+1(right leave) search upper right(crt+2)
        if(end-start>0&&(ct+1<((end+1)/2+1)) &&dic[start].equals("#")){

            l=false;
            return dfs(dic, start+1, end,l,ct+1);
        }
        if(end-start==0&&(ct+1<=((end+1)/2+1))  && dic[start].equals("#")&&!l){

            return true;
        }

        return false;
    }
}
