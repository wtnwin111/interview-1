/**
 * 
 */
package tree;

import java.util.ArrayList;

/**
 * Given a binary tree, return the preorder traversal of its nodes' values.

Have you met this question in a real interview? Yes
Example
Given binary tree {1,#,2,3}:

1
 \
  2
 /
3
return [1,2,3].
 * @author K25553
 *
 */
public class BinaryTreePreorderTraversal {
	/**
     * @param root: The root of binary tree.
     * @return: Preorder in ArrayList which contains node values.
     */
    public ArrayList<Integer> postorderTraversal(TreeNode root) {
        // write your code here
    	ArrayList <Integer> result = new ArrayList<Integer>();
    	traverse(root, result);
		return result;
    }
	private void traverse(TreeNode root, ArrayList<Integer> result) {
		// TODO Auto-generated method stub
		if(root==null){
			return;
		}
		
		traverse(root.left,result);
		traverse(root.right,result);
		result.add(root.val);
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
