/**
 * 
 */
package tree;

/**
 * Given a root of Binary Search Tree with unique value for each node.  Remove the node with given value. If there is no such a node with given value in the binary search tree, do nothing. You should keep the tree still a binary search tree after removal.

Have you met this question in a real interview? Yes
Example
Given binary search tree:

          5

       /    \

    3          6

 /    \

2       4

Remove 3, you can either return:

          5

       /    \

    2          6

      \

         4

or :

          5

       /    \

    4          6

 /   

2
 * @author Tiannan
 *
 */
public class RemoveNodeFromBST {
	/**
	 * @param root: The root of the binary search tree.
	 * @param value: Remove the node with given value.
	 * @return: The root of the binary search tree after removal.
	 */
	public TreeNode removeNode(TreeNode root, int value) {
		// write your code here
		if(root==null){
			return root;
		}
		TreeNode dummy= new TreeNode(0);
		dummy.left= root;
		TreeNode father= find( root, dummy, value);
		if(father.left!= null && father.left.val==value){
			delete(father.left, father);
		}else if(father.right !=null && father.right.val==value){
			delete(father.right, father);
		}else{
			return dummy.left;
		}
		return dummy.left;
	}

	private void delete(TreeNode node, TreeNode father) {
		// TODO Auto-generated method stub
		if (node.left==null){
			if(father.left==node){
				father.left=node.right;
			}else{
				father.right=node.right;
			}
		}else if(node.right==null){
			if(father.left==node){
				father.right= node.left;
			}else{
				father.left= node.left;
			}
		}else{
			TreeNode temp= node.right;
			TreeNode f= node;
			if(temp.left==null){
				f =node;
			}else{							
				while(temp.left!=null){
					f=temp;
					temp=temp.left;
				}
				f.left=temp.right;
				if(father.left==node){
					father.left=temp;
				}else{
					father.right=temp;
				}
				
				temp.left=node.left;
				temp.right=node.right;
				//deal with the min of the right subtree
				//1 it is leave then father and 2 min have right sub

			}
		}


	}

	private TreeNode find(TreeNode root, TreeNode father, int k) {
		// TODO Auto-generated method stub
		if(root==null)
			return father;
		if(root.val==k){
			return father;
		}
		else if(root.val<k){
			return find(root.right, root, k);
		}else{
			return find(root.left, root, k);
		}

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
