package tree;

/**
 * Created by K25553 on 10/24/2016.
 */
public class RemoveNodeinBinarySearchTree {
    /**
     * @param root: The root of the binary search tree.
     * @param value: Remove the deleted with given value.
     * @return: The root of the binary search tree after removal.
     */
    public TreeNode removeNode(TreeNode root, int value) {
        if(root==null){
            return root;
        }
        TreeNode dummy = new TreeNode(0);
        dummy.left= root;
        TreeNode parent = findNode(dummy,root,value);
        if(parent==null){
            return root;
        }else if(parent.left!=null&&parent.left.val==value){
            deleteNode(parent,parent.left);
            return dummy.left;
        }else {
            deleteNode(parent,parent.right);
            return dummy.left;
        }
    }
    //return father of target deleted node
    private TreeNode  findNode (TreeNode parent, TreeNode crt, int value){
        if(crt==null){
            return null;
        }
        if(crt.val==value){
            return parent;
        }
        else if(crt.left==null&&crt.right==null){
            return null;
        }else if( value<crt.val){
            return findNode(crt,crt.left,value);
        }else {
            return findNode(crt,crt.right,value);
        }
    }
    private void deleteNode(TreeNode parent, TreeNode deleted) {

        //no child
        if(deleted.left==null&&deleted.right==null){
            if(parent.left==deleted){
                parent.left=null;
            }else{
                parent.right=null;
            }
            return;
        }
        //one child
        if(deleted.left==null&&deleted.right!=null){
            if(parent.left==deleted){
                parent.left= deleted.right;
            }else{
                parent.right=deleted.right;
            }
            return;
        }else if(deleted.right==null&&deleted.left!=null){
            if(parent.left==deleted){
                parent.left= deleted.left;
            }else{
                parent.right=deleted.left;
            }
            return;
        }
        // 2 children: either replace node with the max node of ltree or replace the nod with min node of the right tree,
        //then replace its sub tree node (either its left sub or right sub)
        if(parent.left==deleted){
            //find min of right tree
            TreeNode crt = deleted.right;
            TreeNode father = deleted;
            while(crt.left!=null){
                father =crt;
                crt=crt.left;
            }
            if(father.right==crt){
                father.right = crt.right;
            }else{
                if ( crt.right!=null){
                    father.left=crt.right;
                }else{
                    father.left=null;
                }
            }

            crt.left= parent.left.left;
            crt.right = parent.left.right;
            parent.left = crt;

        }else{
            TreeNode crt = deleted.right;
            TreeNode father = deleted;
            while(crt!=null&&crt.left!=null){
                father =crt;
                crt=crt.left;
            }
            if(father.right==crt){
                father.right = crt.right;
            }else{
                if ( crt.right!=null){
                    father.left=crt.right;
                }else{
                    father.left=null;
                }
            }
            crt.left= parent.right.left;
            crt.right = parent.right.right;
            parent.right = crt;
        }

    }
}
