package tree;

public class TreeNode {
    public int val; public String s;
    public TreeNode left;
   public TreeNode right;
   public TreeNode(int x) { val = x; }
    public TreeNode(int x, String string) { val = x;this.s=string; }
}