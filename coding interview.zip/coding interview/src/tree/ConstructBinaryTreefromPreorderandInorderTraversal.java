package tree;

/**Given preorder and inorder traversal of a tree, construct the binary tree.

 Notice

 You may assume that duplicates do not exist in the tree.

 Have you met this question in a real interview? Yes
 Example
 Given in-order [1,2,3] and pre-order [2,1,3], return a tree:

 2
 / \
 1   3
 * Created by K25553 on 9/20/2016.
 */
public class ConstructBinaryTreefromPreorderandInorderTraversal {
    /**
     *@param preorder : A list of integers that preorder traversal of a tree
     *@param inorder : A list of integers that inorder traversal of a tree
     *@return : Root of a tree
     */
    public TreeNode buildTree(int[] preorder, int[] inorder) {
        // write your code here
    }
}
