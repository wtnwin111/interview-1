package tree;

/**
 * Given a binary search tree (See Definition) and a node in it, find the in-order successor of that node in the BST.
 * <p>
 * If the given node has no in-order successor in the tree, return null.
 * <p>
 * Notice
 * <p>
 * It's guaranteed p is one node in the given tree. (You can directly compare the memory address to find p)
 * <p>
 * Have you met this question in a real interview? Yes
 * Example
 * Given tree = [2,1] and node = 1:
 * <p>
 * 2
 * /
 * 1
 * return node 2.
 * <p>
 * Given tree = [2,1,3] and node = 2:
 * <p>
 * 2
 * / \
 * 1   3
 * return node 3.
 * <p>
 * Challenge
 * O(h), where h is the height of the BST.
 * Created by K25553 on 9/26/2016.
 * analysis: inorder tranversal
 * left, root, right
 * 5
 * 2    7
 * 1 3 6   8
 * 4(from 3)
 * node sucess
 * 8       null
 * 2       4
 * 1       2
 * 5       6
 * logic:
 * 1 node is left subtree root, return current root
 * 2 node as root, right sutree's smallest
 * 3 node is right,
 */
public class InorderSuccessorinBinarySearchTree {
    public TreeNode inorderSuccessor(TreeNode root, TreeNode p) {
        if (p == null) {
            return null;
        }
        TreeNode up = null;
        while (root != null && root != p) {
            if (root.val > p.val) {
                up = root;
                root = root.left;
            } else {
                root = root.right;
            }
        }


        if (root == null){
            return null;
        }
        if(root.right==null){
            return up;
        }
        root = root.right;
        while( root.left!=null){
            root= root.left;
        }
        return root;
    }
}