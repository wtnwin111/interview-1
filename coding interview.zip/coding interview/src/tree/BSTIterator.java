/**
 * 
 */
package tree;

import java.util.Stack;

/**
 * @author K25553
 *
 */
public class BSTIterator {

	private Stack<TreeNode> stack = new Stack<>();
	private TreeNode crt;
	//@param root: The root of binary tree.
	public BSTIterator(TreeNode root) {
		crt= root;
	}

	//@return: True if there has next node, or false
	public boolean hasNext() {
		return (crt != null || !stack.isEmpty());
	}

	//@return: return next node
	public TreeNode next() {

		while (crt!=null){
			stack.push(crt);
			crt =crt.left;
		}
		crt=stack.pop();
		TreeNode res= crt.right;
		crt = crt.right;
		return  res;
	}

}
