package tree;

/**Invert a binary tree.

 Have you met this question in a real interview? Yes
 Example
 1         1
 / \       / \
 2   3  => 3   2
    /       \
   4         4
 * Created by K25553 on 9/19/2016.
 */
public class InvertBinaryTree {
    /**
     * @param root: a TreeNode, the root of the binary tree
     * @return: nothing
     */
    public void invertBinaryTree1(TreeNode root) {
        if( root== null){
            return;
        }
        if(root.left==null&&root.right==null){
            return;
        }
        if(root.left==null){
            root.left=root.right;
            root.right=null;
            invertBinaryTree(root.left);
            return;
        }
        if(root.right==null){
            root.right=root.left;
            root.left=null;
            invertBinaryTree(root.right);
            return;
        }

        TreeNode temp = root.left;
        root.left=root.right;
        root.right=temp;
        invertBinaryTree(root.left);
        invertBinaryTree(root.right);
    }

    /**
     * @param root: a TreeNode, the root of the binary tree
     * @return: nothing
     */
    public void invertBinaryTree(TreeNode root) {
        if (root == null) {
            return;
        }
        TreeNode temp = root.left;
        root.left = root.right;
        root.right = temp;

        invertBinaryTree(root.left);
        invertBinaryTree(root.right);
    }

    /**
     * @param root: a TreeNode, the root of the binary tree
     * @return: nothing
     */
    public void invertBinaryTree2(TreeNode root) {
        if( root== null){
            return;
        }
        if(root.left==null&&root.right==null){
            return;
        }
        if(root.left==null){

            invertBinaryTree(root.right);
            root.left=root.right;
            root.right=null;
            return;
        }
        if(root.right==null){
            invertBinaryTree(root.left);
            root.right=root.left;
            root.left=null;

            return;
        }
        invertBinaryTree(root.left);
        invertBinaryTree(root.right);
        TreeNode temp = root.left;
        root.left=root.right;
        root.right=temp;

    }
}
