/**
 * 
 */
package tree;

/**
 * @author Tiannan
 *
 */
public class MinimumPathSum {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
