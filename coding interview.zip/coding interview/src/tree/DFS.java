/**
 * 
 */
package tree;
/**
 * Definition for binary tree
 * public class TreeNode {
 *     int val;
 *     TreeNode left;
 *     TreeNode right;
 *     TreeNode(int x) { val = x; }
 * }
 */
/**
 * @author Tiannan
 *
 */
public class DFS {
	 public void traverse(TreeNode root) {
	        if (root == null) {
	            return;
	        }
	        // do something with root
	        traverse(root.left);
	        // do something with root
	        traverse(root.right);
	        // do something with root
	    }
	


	//Tempate 2: Divide & Conquer


	    public int traversal(TreeNode root) {
	        // null or leaf
	        if (root == null) {
	            // do something and return;
	        	return 1;
	        }
	        
	        // Divide
	        int left = traversal(root.left);
	        int right = traversal(root.right);
	        
	        // Conquer
	        //ResultType result = Merge from left and right.
	        //return result;
	       return  Math.max(left, right) + 1;
	    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
