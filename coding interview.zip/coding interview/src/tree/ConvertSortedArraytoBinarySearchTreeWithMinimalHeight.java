package tree;

/**
 * Created by K25553 on 9/19/2016.
 */
public class ConvertSortedArraytoBinarySearchTreeWithMinimalHeight {
    /**
     * @param A: an integer array
     * @return: a tree node
     */
    public TreeNode sortedArrayToBST(int[] a) {
        if(a==null){
            return null;
        }
        return build(0,a.length-1,a);
    }

    private TreeNode build(int l, int r, int[] a) {
        if(r==l){
            return new TreeNode(a[l]);
        }
        if(r<l){
            return null;
        }
        TreeNode root = new TreeNode(a[l+(r-l)/2]);
        root.left = build(l,l-1+((r-l)/2), a);
        root.right = build(l+1+((r-l)/2),r, a);
        return root;
    }
}
