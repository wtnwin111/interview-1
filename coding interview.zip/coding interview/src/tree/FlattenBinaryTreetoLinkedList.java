package tree;

/**Flatten a binary tree to a fake "linked list" in pre-order traversal.

 Here we use the right pointer in TreeNode as the next pointer in ListNode.

 Notice

 Don't forget to mark the left child of each node to null. Or you will get Time Limit Exceeded or Memory Limit Exceeded.

 Have you met this question in a real interview? Yes
 Example
 1
 \
 1          2
 / \          \
 2   5    =>    3
 / \   \          \
 3   4   6          4
 \
 5
 \
 6
 * Created by K25553 on 9/19/2016.
 */
public class FlattenBinaryTreetoLinkedList {
        /**
         * @param root: a TreeNode, the root of the binary tree
         * @return: nothing
         */
        public void flatten(TreeNode root) {
            dfs(root);
        }

    private TreeNode dfs(TreeNode root) {
        if(root==null){
            return null;
        }
        if(root.left==null&&root.right==null){
            return root;
        }
        if(root.left ==null){

            return dfs( root.right);
        }
        if(root.right ==null){
            root.right=root.left;
            root.left=null;
            return dfs( root.right);
        }
        TreeNode l = dfs( root.left);
        TreeNode r = dfs( root.right);

        l.right=root.right;
        root.right=root.left;
        root.left=null;
        return r;

    }
}
