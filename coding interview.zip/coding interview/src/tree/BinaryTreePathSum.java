package tree;

import java.util.ArrayList;
import java.util.List;

/**Given a binary tree, find all paths that sum of the nodes in the path equals to a given number target.

 A valid path is from root node to any of the leaf nodes.

 Example
 Given a binary tree, and target = 5:

 1
 / \
 2   4
 / \
 2   3
 return

 [
 [1, 2, 2],
 [1, 4]
 ]
 * Created by K25553 on 7/5/2016.
 */
public class BinaryTreePathSum {
    /**
     * @param root the root of binary tree
     * @param target an integer
     * @return all valid paths
     */
    public List<List<Integer>> binaryTreePathSum(TreeNode root, int target) {
        List<List<Integer>> result= new ArrayList<>();
        if(root==null){
            return result;
        }
        ArrayList<Integer> path= new ArrayList<>();
        path.add(root.val);
        int sum = root.val;
        helper(root,path,sum,target,result);
        return result;

    }
    private void helper(TreeNode root,
                        ArrayList<Integer> path,
                        int sum,
                        int target,
                        List<List<Integer>> result) {
        //leave
        if(root.left==null&&root.right==null){
            if (sum==target){
                result.add(new ArrayList<Integer>(path));
            }
        }
        if(root.left!=null){
            path.add(root.left.val);
            helper(root.left,path,sum+root.left.val,target,result);
            path.remove(path.size()-1);
        }
        if(root.right!=null){
            path.add(root.right.val);
            helper(root.right,path,sum+root.right.val,target,result);
            path.remove(path.size()-1);
        }
    }
}
