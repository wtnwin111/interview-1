package math;

public class MajorityNumber {

}
