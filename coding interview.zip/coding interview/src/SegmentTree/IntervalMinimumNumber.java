package SegmentTree;

import java.util.ArrayList;

/**Given an integer array (index from 0 to n-1, where n is the size of this array), and an query list. Each query has two integers [start, end]. For each query, calculate the minimum number between index start and end in the given array, return the result list.

 Notice

 We suggest you finish problem Segment Tree Build, Segment Tree Query and Segment Tree Modify first.

 Have you met this question in a real interview? Yes
 Example
 For array [1,2,7,8,5], and queries [(1,2),(0,4),(2,4)], return [2,1,5]

 Challenge
 O(logN) time for each query
 * Created by K25553 on 9/30/2016.
 */
public class IntervalMinimumNumber {
     public class Interval {
             int start, end;
             Interval(int start, int end) {
                     this.start = start;
                    this.end = end;
                }
     }
    class SegmentTreeNode {
        public int start, end, min;
        public SegmentTreeNode left, right;
        public SegmentTreeNode(int start, int end) {
                    this.start = start;
                    this.end = end;
                    this.left = this.right = null;}

    }
    /**
     *@param a, queries: Given an integer array and an query list
     *@return: The result list
     */
    public ArrayList<Integer> intervalMinNumber(int[] a,
                                                ArrayList<Interval> queries) {
        ArrayList<Integer> res =  new ArrayList<Integer>();
        SegmentTreeNode  root = build (0, a.length-1,a);
        if(queries==null||queries.size()==0){
            return res;
        }
        for (Interval query : queries){
            res.add(query(query.start, query.end, root));
        }
        return res;
    }

    private SegmentTreeNode build(int start, int end, int[] a) {
        if(start>end){
            return null;
        }
        SegmentTreeNode root = new SegmentTreeNode(start, end);
        if(start==end){
            root.min=a[start];
            return root;
        }
        int mid = (start+end)/2;
        if(start!=end){
            root.left = build(start, mid, a);
            root.right = build(mid+1, end, a);
            root.min= Math.min(root.left.min, root.right.min);

        }
        return root;
    }
    private int query(int start, int end, SegmentTreeNode root) {
        if (root.start==start&&root.end==end){
            return root.min;
        }
        int mid = (root.start+ root.end)/2;
        if(start<=mid){
            if(end<=mid){
                return query(start, end, root.left);
            }else{
                return Math.min(query(start, mid, root.left),query(mid+1, end, root.right));
            }

        }
        return query(start, end, root.right);
    }
}
