package SegmentTree;

import java.util.ArrayList;

/*Given an integer array (index from 0 to n-1, where n is the size of this array), and an query list. Each query has two integers [start, end]. For each query, calculate the sum number between index start and end in the given array, return the result list.

 Notice

We suggest you finish problem Segment Tree Build, Segment Tree Query and Segment Tree Modify first.

Have you met this question in a real interview? Yes
Example
For array [1,2,7,8,5], and queries [(0,4),(1,2),(2,4)], return [23,9,20]

Challenge
O(logN) time for each query
 */

public class IntervalSum {
	public class Interval {
		int start, end;

		Interval(int start, int end) {
			this.start = start;
			this.end = end;
		}
	}
		class SegmentTreeNode {
			public int start, end ; public long sum;
			public SegmentTreeNode left, right;
			public SegmentTreeNode(int start, int end) {
				this.start = start;
				this.end = end;
				this.left = this.right = null;}

		}
		/**
		 *@param a, queries: Given an integer array and an query list
		 *@return: The result list
		 */
		public ArrayList<Long> intervalSum(int[] a,
										   ArrayList<Interval> queries) {
			// write your code here

			ArrayList<Long> res =  new ArrayList<Long>();
			SegmentTreeNode  root = build (0, a.length-1,a);
			if(queries==null||queries.size()==0){
				return res;
			}
			for (Interval query : queries){
				res.add(query(query.start, query.end, root));
			}
			return res;
		}

		private SegmentTreeNode build(int start, int end, int[] a) {
			if(start>end){
				return null;
			}
			SegmentTreeNode root = new SegmentTreeNode(start, end);
			if(start==end){
				root.sum=a[start];
				return root;
			}
			int mid = (start+end)/2;
			if(start!=end){
				root.left = build(start, mid, a);
				root.right = build(mid+1, end, a);
				root.sum= root.left.sum+root.right.sum;

			}
			return root;
		}
		private long query(int start, int end, SegmentTreeNode root) {
			if (root.start==start&&root.end==end){
				return root.sum;
			}
			int mid = (root.start+ root.end)/2;
			if(start<=mid){
				if(end<=mid){
					return query(start, end, root.left);
				}else{
					return query(start, mid, root.left)+query(mid+1, end, root.right);
				}

			}
			return query(start, end, root.right);
		}
}