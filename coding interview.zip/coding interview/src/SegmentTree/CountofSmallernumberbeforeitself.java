/**
 * 
 */
package SegmentTree;

import java.util.ArrayList;

/**
 * ����һ���������飨�±��� 0 �� n-1�� n ��ʾ����Ĺ�ģ��ȡֵ��Χ�� 0 ��10000����
 * ���������е�ÿ�� ai Ԫ�أ������ ai ǰ�����б���С��Ԫ�ص�������

����
��������[1,2,7,8,5] ������ [0,1,2,3,2]
 * @author Tiannan
 *analysis: segment tree for value scope:
 *1 to build a value scope segment tree,= pinter scope segment tree with index cope of the values i.g. (0,10000)
 *2 query from 0,a[i]-1, to add the count to the ans
 *3modify the segement tree by add each ele from array, update the count, for the next query.  
 */
public class CountofSmallernumberbeforeitself {
	 /**
     * @param A: An integer array
     * @return: Count the number of element before this element 'ai' is 
     *          smaller than it and return count number array
     */ 
    class SegmentTreeNode {
        public int start, end;
        public int count;
        public SegmentTreeNode left, right;
        public SegmentTreeNode(int start, int end, int count) {
              this.start = start;
              this.end = end;
              this.count = count;
              this.left = this.right = null;
        }
    }
    SegmentTreeNode root;
    public SegmentTreeNode build(int start, int end) {
        // write your code here
        if(start > end) {  // check core case
            return null;
        }
        
        SegmentTreeNode root = new SegmentTreeNode(start, end, 0);
        
        if(start != end) {
            int mid = (start + end) / 2;
            root.left = build(start, mid);
            root.right = build(mid+1, end);
        } else {
            root.count =  0;
        }
        return root;
    }
    public int querySegmentTree(SegmentTreeNode root, int start, int end) {
        // write your code here
        if(start == root.start && root.end == end) { // ��� 
            return root.count;
        }
        
        
        int mid = (root.start + root.end)/2;
        int leftcount = 0, rightcount = 0;
        // ������
        if(start <= mid) {
            if( mid < end) { // ���� 
                leftcount =  querySegmentTree(root.left, start, mid);
            } else { // ���� 
                leftcount = querySegmentTree(root.left, start, end);
            }
        }
        // ������
        if(mid < end) { // ���� 3
            if(start <= mid) {
                rightcount = querySegmentTree(root.right, mid+1, end);
            } else { //  ���� 
                rightcount = querySegmentTree(root.right, start, end);
            } 
        }  
        // else ���ǲ��ཻ
        return leftcount + rightcount;
    }
    public void modifySegmentTree(SegmentTreeNode root, int index, int value) {
        // write your code here
        if(root.start == index && root.end == index) { // ���ҵ�
            root.count += value;
            return;
        }
        
        // ��ѯ
        int mid = (root.start + root.end) / 2;
        if(root.start <= index && index <=mid) {
            modifySegmentTree(root.left, index, value);
        }
        
        if(mid < index && index <= root.end) {
            modifySegmentTree(root.right, index, value);
        }
        //����
        root.count = root.left.count + root.right.count;
    }
    public ArrayList<Integer> countOfSmallerNumberII(int[] A) {
        // write your code here
        root = build(0, 10000);
        ArrayList<Integer> ans = new ArrayList<Integer>();
        int res;
        for(int i = 0; i < A.length; i++) {
            res = 0;
            if(A[i] > 0) {
                res = querySegmentTree(root, 0, A[i]-1);
            }
            modifySegmentTree(root, A[i], 1);
            ans.add(res);
        }
        return ans;
    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
