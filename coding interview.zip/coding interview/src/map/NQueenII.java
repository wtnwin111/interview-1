package map;

/**
 * Created by K25553 on 7/28/2016.
 */
public class NQueenII {
    /**
     * Calculate the total number of distinct N-Queen solutions.
     * @param n: The number of queens.
     * @return: The total number of distinct solutions.
     */
    public static int ct;
    public int totalNQueens(int n) {
        ct = 0;
        int[] placedCol = new int[n];
        dfs(n,0,placedCol);
        return ct;
    }

    private void dfs(int n, int row, int[] placedCol) {
        if(row==n){
            ct++;
            return;
        }
        for(int j=0;j<n;j++){
            if(isValid(row,j,placedCol)){
                placedCol[row]=j;
                dfs(n,row+1,placedCol);
            }else{
                continue;
            }
        }
    }

    private boolean isValid(int row, int col, int[] placedCol) {
        for(int i=0; i<row; i++){
            if(placedCol[i]==col){
                return false;
            }
            if(Math.abs(placedCol[i]-col)==Math.abs(row-i)){
                return false;
            }
        }
        return true;
    }
}
