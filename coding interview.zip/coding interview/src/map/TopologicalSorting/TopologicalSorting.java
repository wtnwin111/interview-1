package map.TopologicalSorting;

import java.util.*;

/**Given an directed graph, a topological order of the graph nodes is defined as follow:

 For each directed edge A -> B in graph, A must before B in the order list.
 The first node in the order can be any node in the graph with no nodes direct to it.
 Find any topological order for the given graph
 * Created by K25553 on 7/28/2016.
 * ��ͼ���У���һ�������޻�ͼ�Ķ�����ɵ����У����ҽ���������������ʱ����Ϊ��ͼ��һ����������Ӣ�Topological sorting����
 ÿ�����������ֻ����һ�Σ�
 ��A������������B��ǰ�棬����ͼ�в����ڴ�B��A��·����
 */
public class TopologicalSorting {

    class DirectedGraphNode {
         int label;
          ArrayList<DirectedGraphNode> neighbors;
          DirectedGraphNode(int x) { label = x; neighbors = new ArrayList<DirectedGraphNode>(); }
      };
    public ArrayList<DirectedGraphNode> topSort1(ArrayList<DirectedGraphNode> graph) {
        HashMap<DirectedGraphNode,Integer> map = new HashMap<>();
        ArrayList<DirectedGraphNode> res = new ArrayList<>();
        for(DirectedGraphNode node: graph){
            for (DirectedGraphNode neighbor: node.neighbors){
                if(map.containsKey(neighbor)){
                    map.put(neighbor, map.get(neighbor)+1);
                }else{
                    map.put(neighbor,1);
                }
            }
        }
        Queue<DirectedGraphNode> q = new LinkedList<>();
        for (DirectedGraphNode node: graph){
            if(!map.containsKey(node)){
                q.offer(node);
                //The first node in the order can be any node in the graph with no nodes direct to it.
                res.add(node);
            }
        }
        while(!q.isEmpty()){
            DirectedGraphNode node = q.poll();
            for(DirectedGraphNode neighbor:node.neighbors){
                map.put(neighbor,map.get(neighbor)-1);
                if(map.get(neighbor)==0){
                    res.add(neighbor);
                    //The first node in the order can be any node in the graph with no nodes direct to it.
                    q.offer(neighbor);
                }

            }
        }

        return res;
    }

    public ArrayList<DirectedGraphNode> topSort(ArrayList<DirectedGraphNode> graph) {
        Stack<DirectedGraphNode> stack = new Stack<>();
        HashMap<DirectedGraphNode, Integer> map= new HashMap<>();
        for(DirectedGraphNode node: graph){
           for(DirectedGraphNode neightbor: node.neighbors){
               if(map.containsKey(neightbor)){
                   map.put(node, map.get(node)+1);
               }else{
                   map.put(node,1);
               }
           }
        }
        for(DirectedGraphNode node: graph){
            if(!map.containsKey(node)){
                stack.push(node);
            }
        }
        ArrayList<DirectedGraphNode> res = new ArrayList<>();
        while(!stack.isEmpty()){
            DirectedGraphNode crt = stack.pop();
            res.add(crt);
            for(DirectedGraphNode node: crt.neighbors){
                int indegree =  map.get(node)-1;
                map.put(node, map.get(node)-1);
                if(indegree==0){
                    stack.push(node);
                }
            }
        }
        return res;
    }
}
