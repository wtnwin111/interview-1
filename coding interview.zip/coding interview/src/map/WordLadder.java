package map;

import java.util.*;

/**Given two words (start and end), and a dictionary, find the length of shortest transformation sequence from start to end, such that:

 Only one letter can be changed at a time
 Each intermediate word must exist in the dictionary
 Example
 Given:
 start = "hit"
 end = "cog"
 dict = ["hot","dot","dog","lot","log"]
 As one shortest transformation is "hit" -> "hot" -> "dot" -> "dog" -> "cog",
 * Created by K25553 on 8/4/2016.
 * map shortest path: bfs to get all shortest distance bwt start to all nodes
 * BFS: map <ele, List of adjacent ele>, dictionary set<ele>, distance map<ele, distance>, start
 */
public class WordLadder {
    /**
     * @param start, a string
     * @param end, a string
     * @param dict, a set of string
     * @return an integer
     */
    public int ladderLength(String start, String end, Set<String> dict) {
        HashMap<String, Integer> distance = new HashMap<>();
        HashMap<String, List<String>> adjacentMap = new HashMap<>();
        dict.add(start);
        dict.add(end);
        bfs(dict, distance, adjacentMap, start, end);
        return distance.get(end);
    }

    private void bfs(Set<String> dict, HashMap<String, Integer> distance, HashMap<String, List<String>> adjacentMap, String start, String end) {
        //initialize
        distance.put(start,0);
        if(start.equals(end)){
            return;
        }
        for(String ele: dict){
            adjacentMap.put(ele, new ArrayList<String>());
        }
        Queue<String> q = new LinkedList<>();
        q.offer(start);
        while(!q.isEmpty()){
            String crt = q.poll();
            ArrayList<String>  adjacent = findAdjacent(dict,crt,distance,adjacentMap);
            for (String ele: adjacent){
                if(!distance.containsKey(ele)){
                    distance.put(ele,distance.get(crt)+1);
                    if(ele.equals(end)){
                        return;
                    }
                    q.offer(ele);
                }
            }
        }
    }
    private ArrayList<String> findAdjacent(Set<String> dict, String crt, HashMap<String, Integer> distance, HashMap<String, List<String>> adjacentMap) {
        ArrayList<String>  adjacent = new ArrayList<>();
        for (int i=0; i< crt.length();i++){
            for (char j='a'; j<'z';j++){
                if(dict.contains(crt.substring(0,i)+j+crt.substring(i+1))&&j!=crt.charAt(i)){
                    adjacent.add(crt.substring(0,i)+j+crt.substring(i+1));
                }
            }
        }
        adjacentMap.put(crt,adjacent);
        return adjacent;
    }

    //dis:if (disct is too larger than 26 alphabets, running time is amplified longer  )
    private ArrayList<String> findAdjacent1(Set<String> dict, String crt, HashMap<String, Integer> distance, HashMap<String, List<String>> adjacentMap) {
        ArrayList<String>  adjacent = new ArrayList<>();
        for (int i=0; i< crt.length();i++){
            for (String ele: dict){
                if(crt.substring(0,i).equals(ele.substring(0,i))&&crt.substring(i+1).equals(ele.substring(i+1))&&crt.charAt(i)!=(ele.charAt(i))){
                    adjacent.add(ele);
                }
            }
        }
        adjacentMap.put(crt,adjacent);
        return adjacent;
    }

}
