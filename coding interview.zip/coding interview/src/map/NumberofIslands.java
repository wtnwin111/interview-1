/**
 * 
 */
package map;

/**Given a boolean 2D matrix, find the number of islands.
 * [
  [1, 1, 0, 0, 0],
  [0, 1, 0, 0, 1],
  [0, 0, 0, 1, 1],
  [0, 0, 0, 0, 0],
  [0, 0, 0, 0, 1]
]
 * @author K25553
 *
 */
public class NumberofIslands {
	private int n, m;
    static int[] dx = {1, 0, 0, -1};
    static int[] dy = {0, 1, -1, 0};
	 /**
     * @param grid a boolean 2D matrix
     * @return an integer
     */
    public int numIslands(boolean[][] g) {
       int ct= 0;
       n=g.length;
       //imp: chek  g.len of first then g[0].len; since g[0].len may not exist 
       if(n==0){
           return 0;
       }
       
       m=g[0].length;
       if(m==0){
           return 0;
       }
       
       for(int i=0; i<n;i++){
    	   for(int j=0; j<m;j++){
    		   if (g[i][j]==true){
    			   UnionFind(i,j,g);
    			   ct++;
    		   }
    	   }
       }
       return ct;
    }
    
	private void UnionFind(int i, int j, boolean[][] g) {
		g[i][j]=false;
		for(int d=0;d<4;d++ ){
			int x= i+dx[d];
			int y= j+dy[d];
			if (x<n&&y<m&&x>=0&&y>=0&&g[x][y]==true){
				UnionFind(x,y,g);
			}
		}
	}	
		
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
