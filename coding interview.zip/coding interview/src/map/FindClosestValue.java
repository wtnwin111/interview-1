package map;

import java.util.Map;
import java.util.TreeMap;

public class FindClosestValue {
	public static void main(String... args) throws Exception {
	    Map<Long, Object> map = new TreeMap<Long, Object>();
	    map.put(2L, "2");
	    map.put(5L, "5");
	    map.put(8L, "8");
	    map.put(3L, "3");

	    System.out.println(findNearest(map, 2)); //prints 2
	    System.out.println(findNearest(map, 4)); //prints 3
	    System.out.println(findNearest(map, 7)); //prints 8
	    System.out.println(findNearest1(map, 100)); //prints 8
	    System.out.println(nearestKey(map, (long) 100)); //prints 8
	}

	private static Object findNearest(Map<Long, Object> map, long value) {
	    Map.Entry<Long, Object> previousEntry = null;
	    for (Map.Entry<Long, Object> e : map.entrySet()) {
	        if (e.getKey().compareTo(value) >= 0) {
	            if (previousEntry == null) {
	                return e.getValue();
	            } else {
	                if (e.getKey() - value >= value - previousEntry.getKey()) {
	                    return previousEntry.getValue();
	                } else {
	                    return e.getValue();
	                }
	            }
	        }
	        previousEntry = e;
	    }
	    return previousEntry.getValue();
	}
	private static Object findNearest1(Map<Long, Object> map1, long value) {
	
	Map.Entry<Long,Object> low = ((TreeMap<Long, Object>) map1).floorEntry(value);
	Map.Entry<Long,Object> high = ((TreeMap<Long, Object>) map1).ceilingEntry(value);
	Object res = null;
	if (low != null && high != null) {
	    res = Math.abs(value-low.getKey()) < Math.abs(value-high.getKey())
	    ?   low.getValue()
	    :   high.getValue();
	} else if (low != null || high != null) {
	    res = low != null ? low.getValue() : high.getValue();
	}
	return res;}
	
	public static Long nearestKey(Map<Long, Object> map, Long target) {
	    double minDiff = Double.MAX_VALUE;
	    Long nearest = null;
	    for (long key : map.keySet()) {
	        double diff = Math.abs((double) target - (double) key);
	        if (diff < minDiff) {
	            nearest = key;
	            minDiff = diff;
	        }
	    }
	    return nearest;
	}
}
