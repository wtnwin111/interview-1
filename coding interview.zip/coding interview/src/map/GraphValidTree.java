/**
 *
 */
package map;

import java.util.HashMap;

/**
 * Given n nodes labeled from 0 to n - 1 and a list of undirected edges (each
 * edge is a pair of nodes), write a function to check whether these edges make
 * up a valid tree.
 *
 * @author K25553
 *         Example
 *         Given n = 5 and edges = [[0, 1], [0, 2], [0, 3], [1, 4]], return
 *         true.
 *
 *         Given n = 5 and edges = [[0, 1], [1, 2], [2, 3], [1, 3], [1, 4]],
 *         return false.
 *
 *         the int[][] edges is actually [the number of edges][2], so edge[i][0]
 *         is one vertice, edge[i][1] is another vertice,
 *         solution: iterate all the edge(a,b) if vertice a's root is equal to b
 *         then false else union vertice b to a
 */
public class GraphValidTree {
	class UnionFind {
		HashMap<Integer, Integer> father = new HashMap<Integer, Integer>();

		UnionFind(int n) {

		}

//		int compressed_find(int x) {
//
//		}

		void union(int x, int y) {

		}
	}

	/**
	 * @param n
	 *            an integer
	 * @param edges
	 *            a list of undirected edges
	 * @return true if it's a valid tree, or false
	 */
//	public boolean validTree(int n, int[][] edges) {
//
//	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
