/**
 * 
 */
package map.unionFind;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import epic.findingWords;

/**
 * Given a n,m which means the row and column of the 2D matrix and an array of pair A( size k). 
 * Originally, the 2D matrix is all 0 which means there is only sea in the matrix. 
 * The list pair has k operatorserator and each operatorserator has two integer A[i].x, A[i].y means that 
 * you can change the grid matrix[A[i].x][A[i].y] from sea to island. Return how many island are there in the matrix after each operatorserator.
 * @author K25553
 *
 */
public class NumberofIslandsII {
	  class Point {
		      int x;
		     int y;
		     Point() { x = 0; y = 0; }
		     Point(int a, int b) { x = a; y = b; }}
    class UnionFind{
		HashMap<Integer, Integer> hm = new HashMap<Integer, Integer>();
		UnionFind(int n, int m) {
			// TODO Auto-generated constructor stub
			for(int i=0; i< n; i++){
				for (int j=0; j< m; j++){
					int id = (i*m+j);
					hm.put(id, id);
				}
			}
		}
		int find(Integer x){
			int fa =x;
			while(fa!=hm.get(fa)){
				fa=hm.get(fa);

			}
			int temp;
			int node=x;
			while(node!=hm.get(node)){
				temp=hm.get(node);
				hm.put(node, fa);
				node=temp;
			}
			return fa;
		}
		void union (int a, int b){
			int af= find(a);
			int bf= find(b);
			if (af!=bf){
				hm.put(af, bf);
			}
		}
	}

	/**
	 * @param n an integer
	 * @param m an integer
	 * @param operatorserators an array of point
	 * @return an integer array
	 */
	public List<Integer> numIslands2(int n, int m, Point[] operators) {
		
		UnionFind uf = new UnionFind(n,m);
		//init res set
		List<Integer> res = new ArrayList<Integer>();
		//init direcion
		int []dx = {0,-1, 0, 1};
		int []dy = {1, 0, -1, 0};
		//init grid
		int [][] a= new int [n][m];
		int ct =0;
		//imp: chekc op if [] then null pointer
		 if(operators != null) {
		for (int j=0;j<operators.length;j++){
			int x=operators[j].x;
			int y=operators[j].y;
            //imp: check node if added already 
			if (a[x][y]!=1){
				a[x][y]=1;
				ct++;
				int id= x*m+y;
				
				for(int i=0; i< 4;i++ ){
					int x1=operators[j].x+dx[i];
					int y1=operators[j].y+dy[i];
					if(x1<n&&x1>=0&&y1<m&&y1>=0&&a[x1][y1]==1){
						int nid= x1*m+y1;
						//imp: find fa for node here since it update all the time 
						int fa= uf.find(id);
						int nfa=uf.find(nid);
						if(fa!=nfa){
						    uf.union(id, nid);
						    ct--; 
						}
						
					}
				}
			}
			res.add(ct);
		}}
		return res;
	}
}
