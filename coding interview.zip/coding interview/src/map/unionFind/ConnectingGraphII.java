package map.unionFind;

/**Given n nodes in a graph labeled from 1 to n. There is no edges in the graph at beginning.

 You need to support the following method:
 1. connect(a, b), an edge to connect node a and node b
 2. query(a), Returns the number of connected component nodes which include node a.

 Have you met this question in a real interview? Yes
 Example
 5 // n = 5
 query(1) return 1
 connect(1, 2)
 query(1) return 2
 connect(2, 4)
 query(1) return 3
 connect(1, 4)
 query(1) return 3
 * Created by K25553 on 11/29/2016.
 */
public class ConnectingGraphII {
    int[] ct =null;
    int[] father = null;
    public ConnectingGraphII(int n) {
       ct = new int[n+1];
        father = new int[n+1];
        for(int i=0; i<n+1; i++){
            ct[i]=1;
            father[i]= i;
        }
    }
    private int find(int i){
        if(father[i]==i){
            return i;
        }
        father[i]= find(father[i]);
        return father[i];
    }
    public void connect(int a, int b) {
        int roota = find(a);
        int rootb = find(b);
        if(roota!=rootb){
            father[roota]=rootb;
            ct[rootb] += ct[roota];
        }
    }

    public int query(int a) {
        int roota = find(a);
        return ct[roota];
    }

}
