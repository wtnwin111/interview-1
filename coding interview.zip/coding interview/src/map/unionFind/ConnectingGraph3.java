package map.unionFind;

/**Given n nodes in a graph labeled from 1 to n. There is no edges in the graph at beginning.

 You need to support the following method:
 1. connect(a, b), an edge to connect node a and node b
 2. query(), Returns the number of connected component in the graph

 Have you met this question in a real interview? Yes
 Example
 5 // n = 5
 query() return 5
 connect(1, 2)
 query() return 4
 connect(2, 4)
 query() return 3
 connect(1, 4)
 query() return 3
 * Created by K25553 on 11/29/2016.
 */
public class ConnectingGraph3 {

    int ct =0;
    int[] father = null;
    public ConnectingGraph3(int n) {
        ct = n;
        father = new int[n+1];
        for(int i=0; i<n+1; i++){

            father[i]= i;
        }
    }
    private int find(int i){
        if(father[i]==i){
            return i;
        }
        father[i]= find(father[i]);
        return father[i];
    }
    public void connect(int a, int b) {
        int roota = find(a);
        int rootb = find(b);
        if(roota!=rootb){
            father[roota]=rootb;
            ct--;
        }
    }

    public int query() {

        return ct;
    }
}
