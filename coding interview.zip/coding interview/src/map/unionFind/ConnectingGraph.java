package map.unionFind;

/**Given n nodes in a graph labeled from 1 to n. There is no edges in the graph at beginning.

 You need to support the following method:
 1. connect(a, b), add an edge to connect node a and node b. 2.query(a, b)`, check if two nodes are connected

 Have you met this question in a real interview? Yes
 Example
 5 // n = 5
 query(1, 2) return false
 connect(1, 2)
 query(1, 3) return false
 connect(2, 4)
 query(1, 4) return true
 * Created by K25553 on 11/29/2016.
 */
public class ConnectingGraph {
    private int father[] = null;
    public ConnectingGraph(int n) {
        father = new int[n+1];
        for(int i=0; i<n+1; i++){
            father[i]= 0;
        }
    }
    int find (int i){
        if(father[i]==0){
            return i;
        }
        father[i]= find(father[i]);
        return father[i];
    }
    public void connect(int a, int b) {
        int roota = find(a);
        int rootb = find(b);
        if(roota!=rootb)
            father[rootb] = roota;
    }

    public boolean  query(int a, int b) {
        int roota = find(a);
        int rootb = find(b);
        return roota == rootb;
    }
}
