package map;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**Given "abb", return ["abb", "bab", "bba"].

 Given "aabb", return ["aabb", "abab", "baba", "bbaa", "abba", "baab"]
 * Created by K25553 on 8/9/2016.
 */
public class StringPermutationII {

    /**
     * @param str a string
     * @return all permutations
     */
    public List<String> stringPermutation2_1(String str) {
        List<String> res = new ArrayList<>();
        if(str.equals(null)||str.length()==0){
            return res;
        }
        char[] dic = str.toCharArray();
        Arrays.sort(dic);
        boolean [] visited = new boolean[str.length()];
        dfs(dic, visited, res, new String() );
        return res;
    }

    private void dfs(char[] dic, boolean[] visited, List<String> res, String s) {
        if(s.length()==dic.length){
            res.add(new String (s));
            return;
        }
        for (int i=0; i< dic.length;i++){
            if(visited[i]==true||(i!=0&& dic[i]==dic[i-1]&& visited[i-1]==false)){
                continue;
            }
            visited[i]=true;
            s=s+dic[i];
            dfs(dic,visited,res,s);
            //backtracking
            visited[i]=false;
            s=s.substring(0,s.length()-1);
        }
    }
}
