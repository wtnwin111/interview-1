package bit.math;

public class MajorityNumber {

}
