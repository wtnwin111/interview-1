/**
 * 
 */
package bit.math;

/**
 * @author Tiannan
 *
 */
public class MissingTermInAp {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
