/**
 *
 */
package bit;

/**
 * Example
 * For n=4(100), return true;
 *
 * For n=5, return false;
 *
 * Challenge
 * O(1) time
 *
 * @author K25553
 *         if num is checkPowerOf2
 *         then num is 10..0
 *         so num-1 is 1..1
 *         then & is 0
 */
public class CheckPowerof2 {
	/*
	 * @param n: An integer
	 *
	 * @return: True or false
	 */
	public boolean checkPowerOf2(int n) {
		// write your code here
		if (((n & (n - 1)) == 0) && (n > 0)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
