/**
 * 
 */
package bit;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Tiannan
 *Given an array of integers, every element appears twice, except for two. Find the two singles.




˼·����ȫ������ڵõ��Ľ����������һ��������λΪ1��λ�á�
�������λ�õ���ֵ�Ĳ�ͬ����ԭ����A��ΪA1��A2�������飬
����A1���λȫ��Ϊ1��Ԫ�أ�A2���λȫ��Ϊ0��Ԫ�ء��ֱ�A1��A2���
�õ��Ľ��������ҪѰ�ҵ�����single numbers��

 */
public class SingleNumberIII {
	public static int[] singleNumber(int[] A) {
        if (A == null || A.length == 0) {
            return null;
        }

        // b xor a
        int res[] = new int[2];
        int diff = 0;
        for (int i = 0; i < A.length; i++) {
        	diff ^= A[i];
        }
        //fint a bit that is 1 from a xor b which differentiate a,b
        int diffPos = 0;
        for (int i = 0; i < 32; i++) {
        	if ((diff >> i & 1) == 1) diffPos = i;
        }
        
        //group array into 2 group based on the xor 1 position: 1 and 0 
        ArrayList<Integer> A1 = new ArrayList<Integer>();
        ArrayList<Integer> A2 = new ArrayList<Integer>();
        for (int i = 0; i < A.length; i++) {
        	if ((A[i] >> diffPos & 1) == 1) {
        		A1.add(A[i]);
        	} else {
        		A2.add(A[i]);
        	}
        }
        //xor each gorup and the result is the 2 ele appear one.
        for (int i = 0; i < A1.size(); i++) {
        	res[0] ^= A1.get(i);
        }
        for (int i = 0; i < A2.size(); i++) {
        	res[1] ^= A2.get(i);
        }
        
        return res;
    }
        public List<Integer> singleNumberIII(int[] a) {
                List<Integer> res = new ArrayList<Integer>();
                if(a==null||a.length==0){
                        return res;
                }
                int xor= 0;
                for(int i : a){
                        xor ^= i;
                }

                int pos=0;
                for(int i=0; i<32; i++){
                        if((xor>>i&1)==1){
                                pos=i;
                                break;
                        }
                }
                List<Integer> res1 = new ArrayList<Integer>();
                List<Integer> res2 = new ArrayList<Integer>();
                for(int i : a ){
                        if((i>>pos&1)==1){
                                res1.add(i);
                        }else{
                                res2.add(i);
                        }
                }
                int one =0;
                int two =0;
                for(int i: res1 ){
                        one ^= i;
                }
                for (int i: res2){
                        two ^= i;
                }
                res.add(one);
                res.add(two);
                return res;
        }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x []= new int []{1,2,2,3,3,4,4,5};
	       System.out.println(singleNumber(x).toString());   
	       int y = 4;
	       System.out.println(y>>8);   
	}

}
