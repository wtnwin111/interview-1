/**
 *
 */
package bit;

/**
 * @author Tiannan
 *        Given 2*n + 1 numbers, every numbers occurs twice except one, find it.

Have you met this question in a real interview? Yes
Example
Given [1,2,2,1,3,4,3], return 4

Challenge
One-pass, constant extra space.

Tags
Greedy
 */
public class SingleNumber {

	/**
	 * Given an array of integers, every element appears twice except for one.
	 * Find that single one.
	 * 
	 * Note:
	 * 
	 * Your algorithm should have a linear runtime complexity. Could you
	 * implement it without using extra memory?
	 * 
	 * @param args
	 */

	public static int singleNumber(int[] A) {
		// Note: The Solution object is instantiated only once and is reused by
		// each test case.
		if (A == null || A.length == 0) {
			return 0;
		}
		int res = A[0];

		for (int i = 1; i < A.length; i++) {
			res = res ^ A[i];

		}
		return res;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out
				.println(singleNumber(new int[] { 2, 2, 1, 4, 4, 5, 1, 3, 3 }));
		System.out.println(2 ^ 2);
		System.out.println(10000 ^ 10000);
	}

}
