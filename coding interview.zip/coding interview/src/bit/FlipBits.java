/**
 *
 */
package bit;

/**
 * Determine the number of bits required to flip if you want to convert integer
 * n to integer m.
 * Example
 * Given n = 31 (11111), m = 14 (01110), return 2.
 *
 * @author K25553
 *
 */
public class FlipBits {
	/**
	 * @param a
	 *            , b: Two integer
	 *            return: An integer
	 */
	public static int bitSwapRequired(int a, int b) {
		int i = a ^ b;
		int ct = 0;
		while (i != 0) {
			i = i & (i - 1);
			ct++;
		}
		return ct;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
