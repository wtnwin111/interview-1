package sort;

import java.util.Arrays;
import java.util.Comparator;

/**Construct minimum number by reordering a given non-negative integer array. Arrange them such that they form the minimum number.

 Notice

 The result may be very large, so you need to return a string instead of an integer.

 Have you met this question in a real interview? Yes
 Example
 Given [3, 32, 321], there are 6 possible numbers can be constructed by reordering the array:

 3+32+321=332321
 3+321+32=332132
 32+3+321=323321
 32+321+3=323213
 321+3+32=321332
 321+32+3=321323
 So after reordering, the minimum number is 321323, and return it.

 Challenge
 Do it in O(nlogn) time complexity.
 * Created by K25553 on 10/17/2016.
 */
public class ReorderArraytoConstructTheMinimumNumber {
    /**
     * @param nums n non-negative integer array
     * @return a string
     */
    public String minNumber(int[] nums) {
        if(nums==null||nums.length<1){
             return new String();
        }
        String [] res = new String[nums.length];
        int ct=0;
        for(int i:nums ){
            res[ct]=String.valueOf(i);
            ct++;
        }
        Arrays.sort(res, new Compare());
        String res1="";
        for(String crt: res){
            res1+=crt;
        }
        ct=0;
        //trim all "0"
        while(ct<res.length&&res1.charAt(ct)=='0'){
            ct++;
        }
        if(ct==res.length) return "0";
        return res1.substring(ct);

    }
    class Compare implements Comparator<String>{

        @Override
        public int compare(String a, String b) {
            String ab = a.concat(b), ba =b.concat(a);
            return ab.compareTo(ba);
        }
    }
}
