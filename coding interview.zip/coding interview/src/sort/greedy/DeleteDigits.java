package sort.greedy;

import java.util.Arrays;
import java.util.HashMap;

/**Given string A representative a positive integer which has N digits, remove any k digits of the number, the remaining digits are arranged according to the original order to become a new positive integer.

 Find the smallest integer after remove k digits.

 N <= 240 and k <= N,

 Have you met this question in a real interview? Yes
 Example
 Given an integer A = "178542", k = 4

 return a string "12"
 * Created by K25553 on 10/20/2016.
 */
public class DeleteDigits {
    /**
     *@param A: A positive integer which has N digits, A is a string.
     *@param k: Remove k digits.
     *@return: A string
     */
    public String DeleteDigits(String A, int k) {
        // write your code here
        StringBuffer sb = new StringBuffer(A);
        int i, j;
        for (i = 0; i < k; i++) {
            for (j = 0; j < sb.length() - 1
                    && sb.charAt(j) <= sb.charAt(j + 1); j++) {
            }
            sb.delete(j, j + 1);
        }
        while (sb.length() > 1 && sb.charAt(0)=='0')
            sb.delete(0,1);
        return sb.toString();
    }
    /**
     *@param a: A positive integer which has N digits, A is a string.
     *@param k: Remove k digits.
     *@return: A string
     * Input
    254193, 1
    Output
    25413
    Expected
    24193
     */
    public String DeleteDigits1(String a, int k) {
        int remain = a.length()-k;
        HashMap<Character, Integer> map= new HashMap<>();
        if(a==null||remain<0){
            return "";
        }
        char [] dic = a.toCharArray();
        int ct =0;
        for(char i : dic){
            if(!map.containsKey(i)){
                map.put(i,ct);
            }
            ct++;
        }
        Arrays.sort(dic);
        char [] res = new char[remain];
        int [] resIndex= new int[remain];
        for(int i=0; i< remain; i++){
            resIndex[i] = map.get(dic[i]);
        }
        Arrays.sort(resIndex);
        for(int i=0; i< remain; i++){
            res[i] = a.charAt(resIndex[i]);
        }
        return new String(res);
    }
}
