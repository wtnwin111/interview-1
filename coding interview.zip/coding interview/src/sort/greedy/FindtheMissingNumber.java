package sort.greedy;

import java.util.Arrays;

/**Given an array contains N numbers of 0 .. N, find which number doesn't exist in the array.

 Have you met this question in a real interview? Yes
 Example
 Given N = 3 and the array [0, 1, 3], return 2.

 Challenge
 Do it in-place with O(1) extra memory and O(n) time.
 * Created by K25553 on 9/20/2016.
 */
public class FindtheMissingNumber {
    /**
     * @param nums: an array of integers
     * @return: an integer
     */
    public int findMissing(int[] nums) {
        // write your code here
        int n = nums.length, i = 0;
        while (i<n) {
            while (nums[i]!=i && nums[i]<n) {//find missing num
                int t = nums[i];
                nums[i] = nums[t];//swap
                nums[t] = t;//put the num in corresponding place
            }
            ++i;
        }
        for (i=0; i<n; ++i)
            if (nums[i]!=i) return i;
        return n;
    }
    public int findMissing2(int[] nums) {
        int res = 0;
        for (int i = 0; i < nums.length; ++i) {
            res ^= (i + 1) ^ nums[i];
        }
        return res;
    }

    public int findMissing1(int[] nums) {
        Arrays.sort(nums);
        int l= 0, r = nums.length-1;
        while(l+1<r){
            int mid = l + (r-l)/2;
            if(nums[mid]>mid){
                r=mid;
            }else {
                l=mid;
            }
        }
        if(nums[l]>l){
            return l;
        }else if(nums[r]>r){
            return r;
        }else{
            return r+1;
        }
    }

    public static void main(String [] args){
        FindtheMissingNumber a = new FindtheMissingNumber();
        int b [] = new int[] {0,1,2,4,5,6,7,8,9};
        System.out.println(a.findMissing1(b));
    }
}
