package sort.greedy;

/**Given an array contains N numbers of 0 .. N, find which number doesn't exist in the array.

 Have you met this question in a real interview? Yes
 Example
 Given N = 3 and the array [0, 1, 3], return 2.

 Challenge
 Do it in-place with O(1) extra memory and O(n) time.
 * Created by K25553 on 9/20/2016.
 */
public class FindtheMissingNumber {
    /**
     * @param nums: an array of integers
     * @return: an integer
     */
    public int findMissing(int[] nums) {
        // write your code here
        int n = nums.length, i = 0;
        while (i<n) {
            while (nums[i]!=i && nums[i]<n) {//find missing num
                int t = nums[i];
                nums[i] = nums[t];//swap
                nums[t] = t;//put the num in corresponding place
            }
            ++i;
        }
        for (i=0; i<n; ++i)
            if (nums[i]!=i) return i;
        return n;
    }

    public int findMissing1(int[] nums) {
        int len = nums.length;
        if(nums==null||len==0){
            return 0;
        }
        for(int i =0; i<len; i++){
            while(nums[i]<len&&i!=nums[i]){
                //swap nums[nums[i]] and nums[i] to put nums[i] into correct place
                int temp = nums[i];
                nums[i]=nums[temp];
                nums[temp]=temp;

            }
        }
        for(int i =0; i<len; i++){
            if(nums[i]!=i)
            return i;
        }
        return len;
    }
}
