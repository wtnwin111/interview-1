package sort.greedy;

/**
 * Giving a string with number from 1-n in random order, but miss 1 number.Find that number.
 * <p>
 * Notice
 * <p>
 * n <= 30
 * <p>
 * Have you met this question in a real interview? Yes
 * Example
 * Given n = 20, str = 19201234567891011121314151618
 * <p>
 * return 17
 * Created by K25553 on 10/20/2016.
 * analysis:
 * we do not know we should choose 1 digit or2 then
 * then we dfs choose both 1 digit dfs and then 2 digits dfs
 * recursion dfs to record visted[]: if ! visited  makeed visisted and then increase index/pos to recursion
 * if visisted then return to uppper (do nothing )
 * increase index/pos of current digit until index>s.len
 * this means one of the traverse is finished, at this point, we should verify if this this traverse is valied
 * use visited[] for each num,
 */
public class FindtheMissingNumberII {
    /**
     * @param n an integer
     * @param str a string with number from 1-n
     * in random order and miss one number
     * @return an integer
     */

    public int res = -1;
    public boolean found = false;
    public int findMissing2(int n, String str) {
        boolean[] visited = new boolean[n + 1];
        dfs(0, n, str, visited);
        return res;
    }

    private void dfs(int i, int n, String s, boolean[] visited) {
        if (i >= s.length()) {
            int ct =0;
            for (int k = 1; k <= n; k++) {
                if (!visited[k]) {
                    ct++;
                    res = k;
                }
            }
            if(ct>1||ct<1){
                res=-1;
                return;
            }else{
                found=true;
                return ;
            }
        }
        if(found==true){
            return;
        }
        int crt = s.charAt(i) - '0';
        //single digit is not visited, visited, then dfs
        if (crt < 1) {
            return;
        }
        while (crt <= n) {
            if (!visited[crt]) {
                visited[crt] = true;
                dfs(i+1, n, s, visited);
                visited[crt] = false;
            }
            i++;
            if (i >= s.length()) {
                return;
            }
            crt = crt * 10 + (s.charAt(i) - '0');
        }

    }
}
