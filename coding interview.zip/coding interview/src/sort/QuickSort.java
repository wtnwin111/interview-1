package sort;

import java.util.Arrays;

public class QuickSort {
	private static final int SIZE = 100;

	public static void quickSort(int[] arr, int start, int end) {
		int i = start;
		int j = end;
		int pivot = arr[start + (end - start) / 2];
		while (i < j) {
			while (arr[i] < pivot) {
				i++;
			}
			while (arr[j] > pivot) {
				j--;
			}
			if (i <= j) {
				swap(arr, i, j);
				i++;
				j--;
			}
		}
		if (j > start) {
			quickSort(arr, start, j);
		}
		if (i < end) {
			quickSort(arr, i, end);
		}
	}

	public static void swap(int[] arr, int i, int j) {
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}

	public static void main(String args[]) {
		// int[] array = new int[SIZE];
		//
		// for (int i = 0; i < SIZE; i++) {
		// // array[i] = rand.nextInt();
		// array[i] = SIZE - i;
		// }

		// int[] array = {3, 4, 6, 1, 7, 8, 6};

		// reversely ordered
		/*
		 * for(int i=0;i<SIZE; i++) array[i] = SIZE - i;
		 */

		// quickSort(array, 0, SIZE - 1);
		//
		// System.out.println(Arrays.toString(array));
		// printArray(array);

		String[] strings = { "VW_AAUDIT_ROLE","VW_ACATS_ROLE","VW_CCOWNER_ROLE","VW_CDIP_ROLE","VW_COBRA_ROLE","VW_COIC_ADMIN_ROLE","VW_CORPFIN_ROLE","VW_CSTMR_BAL_SMMRY_FORM_ROLE",
				"VW_DSH_ADMIN_ROLE","VW_DSH_ODS_ROLE","VW_DSH_RFRNC_ROLE","VW_EET_ROLE","VW_EET_ROLE","VW_ETATS_ROLE","VW_EXAM_ROLE","VW_FNNCL_ARGNT_INFO_ROLE",
				"VW_FOCUS_ROLE","VW_FOCUS3_ROLE","VW_FOCUSFLG_ROLE","VW_FOGS_ROLE","VW_FORM_17A_FLNG_ROLE","VW_FORM_407A_FLNG_ROLE","VW_FORM_CLRG_ARGNT_FLNG_ROLE",
				"VW_FORM_INVTR_CMPLN_ROLE","VW_FORM_MAP_ROLE","VW_FORM_SFAS157_ROLE","VW_FPRFL_ADMIN_ROLE","VW_FSF_ROLE","VW_IFDF_ROLE","VW_MDR_ROLE","VW_MERIT_ROLE",
				"VW_MRDT_ROLE","VW_MRT_ROLE","VW_NASDESK_ROLE","VW_NEPSURV_ROLE","VW_NYSE_EXAM_ROLE","VW_NYSE_MBRSP_ROLE","VW_OATS_ROLE","VW_OFAC_ROLE",
				"VW_PRFMC_ERP_ROLE","VW_RDMS_ROLE","VW_REGT_ROLE","VW_RULE134_ROLE","VW_SEC_ROLE","VW_SEC_FORM_D_ROLE","VW_SHORTS_ROLE","VW_SHREDDER_ROLE",
				"VW_STARREP_ROLE","VW_SURV_ROLE","VW_TAF_ROLE","VW_WATCHLIST_ROLE","VW_FCS_ROLE","VW_RAWRKSP_ROLE","VW_STAR_ADMIN_ROLE","VW_STAR_ADMIN_XCLD_FP_ROLE" };

//		String[] tgtStrings = "VW_AAUDIT_ROLE	VW_ACATS_ROLE	VW_CCOWNER_ROLE	VW_CDIP_ROLE	VW_COBRA_ROLE	VW_COIC_ADMIN_ROLE	VW_CORPFIN_ROLE	VW_CSTMR_BAL_SMMRY_FORM_ROLE	VW_DSH_ADMIN_ROLE	VW_DSH_ODS_ROLE	VW_DSH_RFRNC_ROLE	VW_EET_ROLE	VW_ETATS_ROLE	VW_EXAM_ROLE	VW_FCS_ROLE	VW_FNNCL_ARGNT_INFO_ROLE	VW_FOCUS3_ROLE	VW_FOCUSFLG_ROLE	VW_FOCUS_ROLE	VW_FOGS_ROLE	VW_FORM_17A_FLNG_ROLE	VW_FORM_407A_FLNG_ROLE	VW_FORM_CLRG_ARGNT_FLNG_ROLE	VW_FORM_INVTR_CMPLN_ROLE	VW_FORM_MAP_ROLE	VW_FORM_SFAS157_ROLE	VW_FPRFL_ADMIN_ROLE	VW_FSF_ROLE	VW_IFDF_ROLE	VW_MDR_ROLE	VW_MERIT_ROLE	VW_MRDT_ROLE	VW_MRT_ROLE	VW_NASDESK_ROLE	VW_NEPSURV_ROLE	VW_NYSE_EXAM_ROLE	VW_NYSE_MBRSP_ROLE	VW_OATS_ROLE	VW_OFAC_ROLE	VW_PRFMC_ERP_ROLE	VW_RAWRKSP_ROLE	VW_RDMS_ROLE	VW_REGT_ROLE	VW_RULE134_ROLE	VW_SEC_FORM_D_ROLE	VW_SEC_ROLE	VW_SHORTS_ROLE	VW_SHREDDER_ROLE	VW_STARREP_ROLE	VW_STAR_ADMIN_ROLE	VW_STAR_ADMIN_XCLD_FP_ROLE	VW_SURV_ROLE	VW_TAF_ROLE	VW_WATCHLIST_ROLE"
//				.split("\\s+");
//		Arrays.sort(strings);
//		Arrays.sort(tgtStrings);
//		for (int i = 0; i < strings.length; i++) {
//			System.out.println(strings[i]);
			// if (tgtStrings[i] != strings[i]) {
			// System.err.println(tgtStrings[i]);
			// break;
			// }
//		}
		System.out.print(strings.length);
	}
}
