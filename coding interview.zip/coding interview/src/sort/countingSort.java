/**
 * 
 */
package sort;

import java.util.Arrays;

/**
 * @author Tiannan
 *
 */
public class countingSort {
	public static int[] sort(int [] a){
		int max = Integer.MIN_VALUE;
		for(int i=0;i<a.length;i++){//�ҳ��������������������С��Ԫ��
			if(a[i]>max){
				max=a[i];
			}
			
		}
		//*������max+1����Ϊ ֵ��index��0-max�� 
		int [] temp= new int [max+1];
		int [] res= new int [a.length];
		//place the value in 
		for(int i:a){
			temp[i]++;
		}
		for (int i=1; i< temp.length;i++){
			temp[i]+= temp[i-1];
		}
		for (int i=a.length-1; i>-1 ;i--){
			temp[a[i]]--;
			res[temp[a[i]]]= a[i];
			
		}
		
		return res;
		
	}
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a []= new int[]{
				2,27,22,8,28,1,30,8,29,28,15,16,25,28,23,16,24,23,17,11,4,2,2,22,23,8,29,16,29,28
		};
		int b[]=new int []{
				2,5,3,0,2,3,0,3
		};
		int c[]=new int []{
				28,29
		};
		System.out.println(Arrays.toString(sort(a)));
		System.out.println(Arrays.toString(sort(b)));
		System.out.println(Arrays.toString(sort(c)));
	}

}
