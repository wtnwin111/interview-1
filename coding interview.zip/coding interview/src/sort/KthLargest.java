/**
 *
 */
package sort;

import java.util.ArrayList;

/**
 * Find K-th largest element in an array.
 *
 * Note
 * You can swap elements in the array
 *
 * Example
 * In array [9,3,2,4,8], the 3th largest element is 4
 *
 * Challenge
 * O(n) time, O(1) space
 *
 * @author Tiannan
 *         ʱ�临�Ӷȣ�������������������飺1��2��3��4��5��Ȼ����ÿһ��ȡ��ߵĵ�pivot��
 *         �ͻ�ﵽ���ʱ�临�Ӷȡ�Ҳ����O(N2)
 */
public class KthLargest {
	// param k : description of k
	// param numbers : array of numbers
	// return: description of return
	public int kthLargestElement(int k, ArrayList<Integer> numbers) {
		// write your code here
		if (k < 1 || numbers == null) {
			return 0;
		}

		return getKth(numbers.size() - k + 1, numbers, 0, numbers.size() - 1);
	}

	//
	public int getKth(int k, ArrayList<Integer> numbers, int start, int end) {
		// Choose the last one as the pivot
		int pivot = numbers.get(end);

		int left = start;
		int right = end;

		while (true) {
			while (numbers.get(left) < pivot && left < right) {
				left++;
			}

			while (numbers.get(right) >= pivot && right > left) {
				right--;
			}

			if (left == right) {
				break;
			}

			swap(numbers, left, right);
		}

		// left: the first one which is bigger than pivot.
		// at very beginning we skip the num[end] since
		swap(numbers, left, end);

		if (k == left + 1) {
			return pivot;
			// Try to find the element from the left side.
		} else if (k < left + 1) {
			return getKth(k, numbers, start, left - 1);
		} else {
			// Try to find the element from the right side.
			return getKth(k, numbers, left + 1, end);
		}
	}

	/*
	 * Swap the two nodes.
	 */
	public void swap(ArrayList<Integer> numbers, int n1, int n2) {
		int tmp = numbers.get(n1);
		numbers.set(n1, numbers.get(n2));
		numbers.set(n2, tmp);
	}

	/*
	 * @param k : description of k
	 * 
	 * @param nums : array of nums
	 * 
	 * @return: description of return
	 */
	public int kthLargestElement1(int k, int[] nums) {
		return findK(nums, nums.length - k, 0, nums.length - 1);
	}

	private int findK(int[] nums, int k, int i, int j) {
		if (i >= j) {
			return nums[i];
		}
		int m = partition(nums, i, j);
		if (m == k) {
			return nums[m];
		} else if (m < k) {
			return findK(nums, k, m + 1, j);
		} else {
			return findK(nums, k, i, m - 1);
		}
	}

	private int partition(int[] nums, int l, int r) {
		// use the first ele as pivot
		// 2 pointer: current next,
		// roll over current and next ele: if next < pivot; swap next and
		// ++current
		// swap pivot and current.
		int pivot = nums[l];
		int current = l;
		int next = l + 1;

		while (next <= r) {
			if (nums[next] < pivot) {
				swap(nums, ++current, next);
			}
			++next;
		}
		swap(nums, l, current);
		return current;
	}

	private void swap(int[] nums, int i, int j) {
		int temp = nums[i];
		nums[i] = nums[j];
		nums[j] = temp;
	}
}
