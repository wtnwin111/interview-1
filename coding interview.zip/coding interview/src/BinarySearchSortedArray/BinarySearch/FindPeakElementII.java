/**
 * 
 */
package BinarySearchSortedArray.BinarySearch;

import java.util.ArrayList;
import java.util.List;

/**一个整数矩阵有如下一些特性：

相邻的整数都是不同的
矩阵有 n 行 m 列。
对于所有的 i < m, 都有 A[0][i] < A[1][i] && A[n - 2][i] > A[n - 1][i].
对于所有的 j < n, 都有 A[j][0] < A[j][1] && A[j][m - 2] > A[j][m - 1].
我们定义一个位置 P 是一个峰，如果有 A[j][i] > A[j+1][i] && A[j][i] > A[j-1][i] && A[j][i] > A[j][i+1] && A[j][i] > A[j][i-1]。

找出该矩阵的一个峰值元素，返回他的坐标。

样例
给一个矩阵：

[
  [1 ,2 ,3 ,4 ,5],
  [16,41,23,22,6],
  [15,17,24,21,7],
  [14,18,19,20,8],
  [13,12,11,10,9]
]
返回 41 的坐标[1,1], 或者 24 的坐标[2,2]。

注意
可能会存在多个峰值，返回任意一个即可。

挑战
使用 O(n) 的时间复杂度。

如果你想出了一个O(nlogn)的算法，能否证明他的复杂度其实是O(n)的？或者能不能想一个类似的算法但是复杂度是O(n)？

 * @author Tiannan
 *对于所有的 i < m, 都有 A[0][i] < A[1][i] && A[n - 2][i] > A[n - 1][i].
对于所有的 j < n, 都有 A[j][0] < A[j][1] && A[j][m - 2] > A[j][m - 1].
which means horizentally or vertically there is at least a peak ele
binary search vertically 
if a mid < a start
 */
public class FindPeakElementII {
    /**
     * @param a: An integer matrix
     * @return: The index of the peak
     */
    public List<Integer> findPeakII(int[][] a) {
        List<Integer> res = new ArrayList<Integer>();
        int l = 1, r = a.length-2;
        while(l + 1 <r){
            int mid = l+(r-l) / 2;
            int col = find(mid, a);// find the peak ele of the mid th row

            if(a[mid][col]<a[mid-1][col]){
                r= mid;
            }else if (a[mid][col]<a[mid+1][col]){
                l= mid;
            }else {
                res.add(mid);
                res.add(col);
                return res;
            }
        }
        int coll = find(l, a);
        int colr= find(r, a);
        if(a[l][coll]<a[l+1][coll]){
            res.add(r);
            res.add(colr);
            return res;
        }
        res.add(l);
        res.add(coll);
        return res;
    }

    int find(int row, int [][]a) {
//        int col = 0;
//        for(int i = 0; i < A[row].length; i++) {
//            if(A[row][i] > A[row][col]) {
//                col = i;
//            }
//        }
//        return col;

        int l=0, r= a[row].length-1;
        while(l+1<r){
            int mid = l+ (r-l)/2;
            if(a[row][mid]< a[row][mid+1]){
                l=mid;
            }else if(a[row][mid]< a[row][mid-1]){
                r=mid;
            }else{
                r=mid;
            }
        }
        if(a[row][l]< a[row][r]){
            return r;
        }else{
            return l;
        }
    }


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [][] a= new int[][] {{1,3,2},{4,6,5},{7,9,8},{13,15,14},{10,12,11}};
        FindPeakElementII b = new FindPeakElementII();

		System.out.println(b.findPeakII(a).toString());
	}

}
