package BinarySearchSortedArray.BinarySearch;

/**Given a mountain sequence of n integers which increase firstly and then decrease, find the mountain top.

 Have you met this question in a real interview? Yes
 Example
 Given nums = [1, 2, 4, 8, 6, 3] return 8
 Given nums = [10, 9, 8, 7], return 10
 * Created by K25553 on 11/2/2016.
 */
public class MaximumNumberinMountainSequence {
    public int mountainSequence(int[] nums) {
        // Write your code here
        int left = 0, right = nums.length - 1;
        while (left + 1 < right) {
            int m1 = left + (right - left) / 2;
            int m2 = right - (right - m1) / 2;
            if (nums[m1] < nums[m2]) {
                left = m1 + 1;
            } else if (nums[m1] > nums[m2]) {
                right = m2 - 1;
            } else {
                left = m1;
                right = m2;
            }
        }
        return nums[left] > nums[right] ? nums[left] : nums[right];
    }
    /**
     * @param nums a mountain sequence which increase firstly and then decrease
     * @return then mountain top
     */
    public static int mountainSequence1(int[] nums) {
        if(nums==null||nums.length==0){
            return -1;
        }
        if(nums.length==1){
            return nums[0];
        }
        int l=0, r =nums.length-1;
        while(l+1<r){
            int mid = l+ (r-l)/2;
            if(nums[mid]<nums[mid+1]){
                l=mid;
            }else if(nums[mid]<nums[mid-1]){
                r=mid;
            }else{
                r=mid;
            }
        }
        if(nums[l]<nums[r]){
            return nums[r];
        }else {
            return nums[l];
        }
    }
    public static void main (String [] args){
        int a[] = new int[]{
                1,2,4,8,6,3
        };
        System.out.println(mountainSequence1(a));
    }
}
