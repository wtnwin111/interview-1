/**
 * 
 */
package BinarySearchSortedArray.BinarySearch;

/**
 * @author Tiannan
 *anlysis:
 *binary search 
 *current>start 
 */
public class FindPeakElement {
    /**There is an integer array which has the following features:

    * The numbers in adjacent positions are different. 

    * A[0] < A[1] && A[A.length - 2] > A[A.length - 1].

We define a position P is a peek if A[P] > A[P-1] && A[P] > A[P+1].

Find a peak element in this array. Return the index of the peak.

Example 

[1, 2, 1, 3, 4, 5, 7, 6]

return index 1 (which is number 2)  or 6 (which is number 7)

Note 

The array may contains multiple peeks, find any of them.

Challenge 

Time complexity O(logN)

     * @param A: An integers array.
     * @return: return any of peek positions.
     */
    public static int findPeak(int[] a) {
        // write your code here
    	int s=0, e=a.length-1, m;
    	while(s+1<e){
    		m=s+(e-s)/2;
    		if(a[m]>a[m-1]&&a[m]>a[m+1]){
    			return m;
    		}
    		if(a[m]<a[m-1]){
    		s=m+1;	
    		}else{
    		e=m-1;
    		}
    	}
    	return -1;
    }
    /**
     * @param A: An integers array.
     * @return: return any of peek positions.
     */
    public int findPeak1(int[] A) {
        // write your code here
        int start = 1, end = A.length-2; //
        while(start + 1 <  end) {
            int mid = (start + end) / 2;
            if(A[mid] < A[mid - 1]) {
                end = mid;
            } else if(A[mid] < A[mid + 1]) {
                start = mid;
            } else {
                end = mid;
            }
        }
        if(A[start] < A[end]) {
            return end;
        } else { 
            return start;
        }
    }

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a= {1, 2, 1, 3, 4, 5, 7, 6};
		System.out.println(findPeak(a));
	}

}
