package BinarySearchSortedArray;

/**Given a 2D grid, each cell is either an house 1 or empty 0 (the number zero, one), find the place to build a post office, the distance that post office to all the house sum is smallest. Return the smallest distance. Return -1 if it is not possible.

 Notice

 You can pass through house and empty.
 You only build post office on an empty.
 Have you met this question in a real interview? Yes
 Example
 Given a grid:

 0 1 0 0
 1 0 1 1
 0 1 0 0
 return 6. (Placing a post office at (1,1), the distance that post office to all the house sum is smallest.)

 Tags
 Binary Search Sort
 * Created by K25553 on 9/19/2016.
 */
public class BuildPostOffice {
    /**
     * @param grid a 2D grid
     * @return an integer
     */
    public int shortestDistance(int[][] grid) {
        int len = grid.length;
        int len1= grid[0].length;
        if(len==0||len1==0){
            return -1;
        }

    }
}
