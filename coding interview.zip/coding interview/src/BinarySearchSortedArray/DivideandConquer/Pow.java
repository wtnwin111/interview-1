package BinarySearchSortedArray.DivideandConquer;

/**
 * Created by K25553 on 9/16/2016.
 */
public class Pow {
    /**
     * @param x the base number
     * @param n the power number
     * @return the result
     */
    public double myPow(double x, int n) {
       if(n==0){
           return 1;
       }else if (n==1){
           return x;
       }
        boolean negative = false;
        if(n<0){
            negative=true;
            n*=-1;
        }
        int r=n/2, l=n%2;
        double t1= myPow(x,r);
        double t2=myPow(x,l);
        if(negative){
            return 1/(t1*t1*t2);
        }
        return (t1*t1*t2);
    }
}
