/**
 * 
 */
package BinarySearchSortedArray;

/**Given a target number, a non-negative integer k and an integer array A sorted in ascending order, 
 * find the k closest numbers to target in A, sorted in ascending order by the difference between the number and target. 
 * Otherwise, sorted in ascending order by number if the difference is same.
 * Example
Given A = [1, 2, 3], target = 2 and k = 3, return [2, 1, 3].

Given A = [1, 4, 6, 8], target = 3 and k = 3, return [4, 1, 6].

Challenge
O(logn + k) time complexity.
 * @author K25553
 *
 */
public class KClosestNumbersInSortedArray {
	 /**
     * @param A an integer array
     * @param target an integer
     * @param k a non-negative integer
     * @return an integer array
     */
    public int[] kClosestNumbers(int[] nums, int target, int k) {
    	int res[] = new int[k];
        //write your code here
    	if(nums.length==0){
    		return res;
    	}
    	int start=0, end=nums.length-1, mid;
    	while(start+1<end){
    		mid= start+(end-start)/2;
    		if(nums[mid]==target){
    			
    			end=mid;
    		}else if(nums[mid]<target){
    			start=mid;
    		}else{
    			end=mid;
    		}
    	}
    	int head=-1;
    	if(nums[start]==target){
    		head=start;
    	}else if(nums[end]==target){
    		head=end;
    	}
    	
    	int start1=0, end1=nums.length-1, mid1;
    	while(start1+1<end1){
    		mid1= start1+(end1-start1)/2;
    		if(nums[mid1]==target){
    			
    			start1=mid1;
    		}else if(nums[mid1]<target){
    			start1=mid1;
    		}else{
    			end1=mid1;
    		}
    	}
    	int tail=-1;
    	if(nums[end1]==target){
    		tail=end1;
    	}else if(nums[start1]==target){
    		tail=start1;
    	}
    	int ct=0;
    	if(head==-1||tail==-1){
    		if(nums[0]>=target){
        		for(int i=0; i<k;i++){
        			res[i]=nums[i];
        		}
        	}else if(nums[nums.length-1]<=target){
        	    int j= nums.length-1;
        		for(int i=0; i<k;i++){
        			res[i]=nums[j];
        			j--;
        		}
        	}else {
        		while (start >= 0 &&end < nums.length && ct < k)
        	    {
        	        if (target - nums[start] <= nums[end] - target){
        	        	res[ct]=nums[start];
        	        	start--;
        	        	ct++;
        	        }
        	            
        	        else{
        	        	res[ct]=nums[end];
        	        	end++;
        	        	ct++;
        	        }
        	           
        	    }
        		while(start >= 0 &&ct<k){
        			res[ct]=nums[start];
        			start--; ct++;
        		}
        		while(end< nums.length &&ct<k){
        			res[ct]=nums[end];
        			end++;ct++;
        		}
			}
    	}else {
    		int i=0; int l= head;
    		for( ;i<tail-head+1&&i<k;i++){
    			res[i]=nums[l];
    			l++;

    		} 
    		head--; tail++;
    		while ((head >= 0 &&tail < nums.length) &&i<k)
    	    {
    	        if (target - nums[head] <= nums[tail] - target){
    	        	res[i]=nums[head];
    	        	head--;
    	        	i++;
    	        }
    	            
    	        else{
    	        	res[i]=nums[tail];
    	        	tail++;
    	        	i++;
    	        }
    	           
    	    }
    		while(head >= 0 &&i<k){
    			res[i]=nums[head];
    			head--;
    			i++;
    		}
    		while(tail < nums.length &&i<k){
    			res[i]=nums[tail];
    			tail++;i++;
    		}
    	}
    	
    	
    	return res;
    
    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
