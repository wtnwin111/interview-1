/**
 * 
 */
package BinarySearchSortedArray;

/**Given a target number and an integer array sorted in ascending order. 
 * Find the total number of occurrences of target in the array.
 * @author K25553
 *
 */
public class TotalOccurrenceofTarget {
	 /**
     * @param A an integer array sorted in ascending order
     * @param target an integer
     * @return an integer
     */
    public int totalOccurrence(int[] nums, int target) {

    	if(nums.length==0){
    		return 0;
    	}
    	int start=0, end=nums.length-1, mid;
    	while(start+1<end){
    		mid= start+(end-start)/2;
    		if(nums[mid]==target){
    			
    			end=mid;
    		}else if(nums[mid]<target){
    			start=mid;
    		}else{
    			end=mid;
    		}
    	}
    	int head=-1;
    	if(nums[start]==target){
    		head=start;
    	}else if(nums[end]==target){
    		head=end;
    	}
    	
    	int start1=0, end1=nums.length-1, mid1;
    	while(start1+1<end1){
    		mid1= start1+(end1-start1)/2;
    		if(nums[mid1]==target){
    			
    			start1=mid1;
    		}else if(nums[mid1]<target){
    			start1=mid1;
    		}else{
    			end1=mid1;
    		}
    	}
    	int tail=-1;
    	if(nums[end1]==target){
    		tail=end1;
    	}else if(nums[start1]==target){
    		tail=start1;
    	}
    	
    	if(head==-1||tail==-1){
    		return 0;
    	}else {
    		return tail-head+1;
    	}
    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
