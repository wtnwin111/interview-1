/**
 * 
 */
package base;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * @author Tiannan
 *
 */
public class section {
	private List<product> a;
	
	public section(List<product> a) {
		super();
		this.a = a;
	}
	public int getScore(){
		int sum=0;
		for(product c: a){
			sum=+c.getScore();
		}
		return sum;
	}
	
	public List<section> sortByScore(List<section> input){
		Comparator <section> com= new Comparator<section>(){

			@Override
			public int compare(section o1, section o2) {
				// TODO Auto-generated method stub
				return o2.getScore()-o1.getScore();
			}
			
		};
		Collections.sort(input,com);
		return input;
	}
	public static Comparator<section> ComparatorByScore = new Comparator<section>() {
		
		@Override
		public int compare(section o1, section o2) {
			// TODO Auto-generated method stub
			return o2.getScore()-o1.getScore();
		}
	}; 
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
