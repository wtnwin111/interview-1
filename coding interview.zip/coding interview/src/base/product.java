/**
 * 
 */
package base;

/**
 * @author Tiannan
 *
 */
public class product {
	private int user;
	private int relevancy;
	public product(int user, int relevancy) {
		super();
		this.user = user;
		this.relevancy = relevancy;
	}
	public int getScore() {
		return user*relevancy;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
