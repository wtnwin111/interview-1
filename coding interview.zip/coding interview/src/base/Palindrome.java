/**
 * 
 */
package base;

/**
 * @author Tiannan
 *
 */
public class Palindrome {
	class Solution {
		public boolean isPalindrome(int x) {
		        if (x < 0) return false;
		        if (x < 10) return true;
		        int m = 1; // long long m = 1
		        while (x / m >= 10) { //x / m > 0
		            m *= 10;
		        }
		        //m /= 10;
		        int l, r;
		        while (m > 1) {
		            l = x / m;
		            x = x % m;
		            m /= 100;
		            r = x % 10;
		            x = x / 10;
		            if (l != r) return false;
		        }
		        
		        return true;
		    }
		};
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
