package list;

/**Find the nth to last element of a singly linked list.

 The minimum number of nodes in list is n.

 Have you met this question in a real interview? Yes
 Example
 Given a List  3->2->1->5->null and n = 2, return node  whose value is 1.
 * Created by K25553 on 10/12/2016.
 */
public class NthtoLastNodeinList {
    ListNode nthToLast(ListNode head, int n) {
        ListNode p1, p2;
        p1=p2=head;
        int ct=0;//n-1 is the distance btw last and last Nth
        //n is distance btw null and Nth last;
        while(p1!=null&& ct!=n){
            p1=p1.next;
            ct++;
        }
        while(p1!=null){
            p1=p1.next;
            p2=p2.next;
        }
        return p2;
    }
    /**
     * @param head: The first node of linked list.
     * @param n: An integer.
     * @return: Nth to last node of a singly linked list.
     */
    ListNode nthToLast1(ListNode head, int n) {
        int ct =0;
        ListNode dummy = head;
        while(dummy!=null){
            ct++;
            dummy=dummy.next;
        }
        int n1 = ct-n;
        if(n1<0){
            return null;
        }else{

            while(head!=null&&n1!=0){
                head= head.next;
                n1--;
            }
            return head;
        }
    }
}
