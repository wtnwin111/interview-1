/**
 * 
 */
package list;

/**
 *Given a sorted linked list, delete all nodes that have duplicate numbers,
 * leaving only distinct numbers from the original list. 
 *For example, Given 1->2->3->3->4->4->5, return 1->2->5. 
 *Given 1->1->1->2->3, return 2->3.
 * @author Tiannan
 *
 */
public class RemoveDuplicatesfromSortedListII {

	 public ListNode deleteDuplicates(ListNode head) {
	        if(head == null || head.next == null)
	            return head;
	        
	        ListNode dummy = new ListNode(0);
	        dummy.next = head;
	        head = dummy;
	        //head.next is cur, head is pre,since we need to jump all the ele to non dulplicated, 
	        //pre will jump to the non duplicated current
	        //if dulicated, record cur.val, while val==cur.next.value, update cur= cure.next,
	        //else head= head.next
	        while (head.next != null && head.next.next != null) {
	            if (head.next.val == head.next.next.val) {
	                int val = head.next.val;
	                while (head.next != null && head.next.val == val) {
	                    head.next = head.next.next;
	                }            
	            } else {
	                head = head.next;
	            }
	        }
	        
	        return dummy.next;
	    }
	  
	/**
	 *
	 * @param args
	 */
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		

	}

}
