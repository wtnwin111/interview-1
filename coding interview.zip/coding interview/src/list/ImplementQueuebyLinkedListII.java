package list;

/**Implement a Queue by linked list. Provide the following basic methods:

 push_front(item). Add a new item to the front of queue.
 push_back(item). Add a new item to the back of the queue.
 pop_front(). Move the first item out of the queue, return it.
 pop_back(). Move the last item out of the queue, return it.
 Have you met this question in a real interview? Yes
 Example
 push_front(1)
 push_back(2)
 pop_back() // return 2
 pop_back() // return 1
 push_back(3)
 push_back(4)
 pop_front() // return 3
 pop_front() // return 4
 * Created by K25553 on 10/12/2016.
 */
public class ImplementQueuebyLinkedListII {
    class ListNode{
        public int val;
        public ListNode prev, next;
        public ListNode(int val){
            this.val = val;
            prev=next=null;
        }
    }
    public ListNode l,r;
    public ImplementQueuebyLinkedListII() { //Dequeue
        l=r=null;
    }

    public void push_front(int item) {
        ListNode crt= new ListNode(item);
        if(l==null){
            r=l=crt;
        }
        else{
            l.prev=crt;
            crt.next=l;
            l=l.prev;
        }
    }

    public void push_back(int item) {
        ListNode crt= new ListNode(item);
       if(r==null){
           l=r=crt;
       }else{
           r.next=crt;
           crt.prev=r;
           r= r.next;
       }
    }

    public int pop_front() {
        if(l==null){
            return -1;
        }else{
            int res= l.val;
            l=l.next;
            //imp: after move node, check crt l,r pointer
            if(l==null){
                r=null;
            }else{
                l.prev=null;
            }
            return res;
        }
    }

    public int pop_back() {
        if(r==null){
            return -1;
        }else{
            int res = r.val;
            r= r.prev;
            if(r==null){
                l=null;
            }else{
                r.next=null;
            }
            return res;
        }
    }
}
