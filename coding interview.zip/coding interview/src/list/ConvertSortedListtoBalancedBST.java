/**
 * 
 */
package list;

import tree.TreeNode;

/**
 * Given a singly linked list where elements are sorted in ascending 
 * order, convert it to a height balanced BST.
 * @author K25553
 *              2
1->2->3  =>   / \
             1   3
 *
 */
public class ConvertSortedListtoBalancedBST {
	  private ListNode current;
	  //ȡ����
	    private int getListLength(ListNode head) {
	        int size = 0;

	        while (head != null) {
	            size++;
	            head = head.next;
	        }

	        return size;
	    }
	    
	    public TreeNode sortedListToBST(ListNode head) {
	        int size;

	        current = head;
	        size = getListLength(head);

	        return sortedListToBSTHelper(size);
	    }

	    public TreeNode sortedListToBSTHelper(int size) {
	        if (size <= 0) {
	            return null;
	        }

	        TreeNode left = sortedListToBSTHelper(size / 2);
	        TreeNode root = new TreeNode(current.val);
	        current = current.next;
	        TreeNode right = sortedListToBSTHelper(size - 1 - size / 2);

	        root.left = left;
	        root.right = right;

	        return root;
	    }
//	    ��������Ƚϱ�����ÿ�α�����ǰlist,�ҵ��м�Ľڵ㣬���� root,�ֱ�ʹ�õݹ齨�������Լ���������������������root֮�¡�������㷨�Ḵ�ӶȺܸߡ�
//	    ����root����ΪN��ÿ�α������N�Σ��ΪNƽ����ʵ�ʲ�����ô�ࣩ
    
	    public TreeNode sortedListToBST1(ListNode head) {
	        ListNode fast = head;
	        ListNode slow = head;
	        
	        ListNode pre = head;
	        
	        if (head == null) {
	            return null;
	        }
	        
	        TreeNode root = null;
	        if (head.next == null) {
	            root = new TreeNode(head.val);
	            root.left = null;
	            root.right = null;
	            return root;
	        }
	        
	        // get the middle node.
	        while (fast != null && fast.next != null) {
	            fast = fast.next.next;
	            
	            // record the node before the SLOW.
	            pre = slow;
	            slow = slow.next;
	        }
	        
	        // cut the list to two parts.
	        pre.next = null;
	        TreeNode left = sortedListToBST1(head);
	        TreeNode right = sortedListToBST1(slow.next);
	        
	        root = new TreeNode(slow.val);
	        root.left = left;
	        root.right = right;
	        
	        return root;
	    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
