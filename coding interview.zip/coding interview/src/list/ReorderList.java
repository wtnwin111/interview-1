/**
 * 
 */
package list;

/**
 * @author K25553
 *Given a singly linked list L: L0��L1������Ln-1��Ln, reorder it to:
 * L0��Ln��L1��Ln-1��L2��Ln-2���� You must do this in-place without altering 
 * the nodes' values. For example, Given {1,2,3,4}, reorder it to {1,4,2,3}.
 *
 *solution:
 *find mid
 *reverse the mid to end,
 *merge head with mid link
 *
 *attn: use newhead=null
 * temp= head.next
 * head.next=new haead
 * newhead= head;
 * head=temp
 */
/**
 * Definition for ListNode.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int val) {
 *         this.val = val;
 *         this.next = null;
 *     }
 * }
 */ 
public class ReorderList {
    /**
     * @param head: The head of linked list.
     * @return: void
     */
    public void reorderList(ListNode head) {  
        if (head == null || head.next == null) {
            return;
        }
        // write your code here
        ListNode mid = findMid(head);
        ListNode head2= reverseList(mid);
        mid.next = null;
        mergeTwo(head, head2);
    }
    
    public ListNode findMid(ListNode head){
       
        ListNode  slow= head, fast= head.next;
        
        while(fast!= null&&fast.next!=null){
            slow= slow.next;
            fast= fast.next.next;
            
        }
         return slow;    
    }
    
    public ListNode reverseList(ListNode head){
        ListNode newhead = null;
        while (head != null){
            ListNode temp= head.next;
            head.next=newhead;
            newhead= head;
            head= temp;
        }
        
        return newhead;
    }
    
    public void mergeTwo(ListNode head1, ListNode head2){
         int index = 0;
        ListNode dummy = new ListNode(0);
        while (head1 != null && head2 != null) {
            if (index % 2 == 0) {
                dummy.next = head1;
                head1 = head1.next;
            } else {
                dummy.next = head2;
                head2 = head2.next;
            }
            dummy = dummy.next;
            index ++;
        }
        if (head1 != null) {
            dummy.next = head1;
        } else {
            dummy.next = head2;
        }
    }
}

