package list;



public class ListNode {
	public  int val;
	public  ListNode next, random;
	public  ListNode(int val) {
        this.val = val;
      this.next = this.random= null;
   }}