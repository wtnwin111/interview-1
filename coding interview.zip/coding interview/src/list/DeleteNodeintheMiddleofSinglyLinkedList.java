package list;

/**Implement an algorithm to delete a node in the middle of a singly linked list, given only access to that node.

 Have you met this question in a real interview? Yes
 Example
 Given 1->2->3->4, and node 3. return 1->2->4
 * Created by K25553 on 10/12/2016.
 */
public class DeleteNodeintheMiddleofSinglyLinkedList {
    /**
     * @param node: the node in the list should be deleted
     * @return: nothing
     */
    public void deleteNode(ListNode node) {
        if(node==null||node.next==null){
            return;
        }
        ListNode next = node.next;
        node.val=next.val;
        node.next=next.next;

    }
    /**
     * @param node: the node in the list should be deleted
     * @return: nothing
     */
    public void deleteNode1(ListNode node) {
        ListNode node1, node2, node3;

        ListNode dummy = new ListNode(0);
        dummy.next= node;
        node1=node2=node;
        node3=dummy;
        while(node2!=null||node2.next!=null){
            node2=node2.next.next;
            node1=node1.next;
            dummy=dummy.next;
        }
        dummy.next=node1.next;

    }
}
