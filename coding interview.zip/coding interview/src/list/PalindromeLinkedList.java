package list;

/**Implement a function to check if a linked list is a palindrome.

 Have you met this question in a real interview? Yes
 Example
 Given 1->2->1, return true
 * Created by K25553 on 10/13/2016.
 */
public class PalindromeLinkedList {
    /**
     * @param head a ListNode
     * @return a boolean
     */
    public boolean isPalindrome(ListNode head) {
        if (head == null || head.next == null) {
            return true;
        }
        //find middle(slow.next)
        ListNode slow = head, fast = head.next;
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }
        //reverse mid to end
        ListNode postLast = null;
        ListNode Middle = slow.next;
        while (Middle != null) {
            ListNode temp = Middle;
            Middle = Middle.next;
            temp.next = postLast;
            postLast = temp;
        }

        while(postLast!=null&& head!=null&&postLast.val==head.val){
            postLast=postLast.next;
            head= head.next;
        }
        return postLast==null;
    }
}
