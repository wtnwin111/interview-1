package list;

/**Sort a linked list using insertion sort.

 Have you met this question in a real interview? Yes
 Example
 Given 1->3->2->0->null, return 0->1->2->3->null.
 * Created by K25553 on 10/12/2016.
 */
public class InsertionSortList {
    /**
     * @param head: The first node of linked list.
     * @return: The head of linked list.
     */
    public ListNode insertionSortList(ListNode head) {
        ListNode dummy = new ListNode(0);
        while(head!=null){
            //new list head
            ListNode h1 = dummy;
            while(h1.next != null&& h1.next.val< head.val){
                h1= h1.next;
            }
            ListNode temp = h1.next;
            h1.next = head;
            head= head.next;
            h1.next .next =temp;
        }
        return dummy .next;
    }
}
