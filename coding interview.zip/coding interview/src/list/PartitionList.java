/**
 * 
 */
package list;

import java.util.List;

/**
 * Given a linked list and a value x, partition it such that all nodes less than x come before nodes greater than or equal to x.

You should preserve the original relative order of the nodes in each of the two partitions.

For example,
Given 1->4->3->2->5->2->null and x = 3,
return 1->2->2->4->3->5->null.
 * @author Tiannan
 *use left to store smaller
 *use right to store bigger
 */
public class PartitionList {
	 /**
     * @param head: The first node of linked list.
     * @param x: an integer
     * @return: a ListNode 
     */
    public ListNode partition(ListNode head, int x) {
        // write your code here
    	 if (head == null) {
             return null;
         }
    	ListNode left= new  ListNode(0);
    	ListNode right= new ListNode(0);
    	ListNode dl=left;
    	ListNode dr=right;
    	ListNode dummy=head;
    	while(dummy!=null){
    		if(dummy.val<x){
    			dl.next=dummy;
    			dl=dl.next;
    		}else{
    			dr.next=dummy;
    			dr=dr.next;
    		}
    		dummy=dummy.next;
    	}
    	dl.next=right.next;
    	dr.next=null;
    	return left.next;
    	
    }
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
