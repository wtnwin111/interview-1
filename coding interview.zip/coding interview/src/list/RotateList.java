package list;

/**Given a list, rotate the list to the right by k places, where k is non-negative.

 Have you met this question in a real interview? Yes
 Example
 Given 1->2->3->4->5 and k = 2, return 4->5->1->2->3.

 * Created by K25553 on 10/13/2016.
 */
public class RotateList {
    private int getLength(ListNode head) {
        int length = 0;
        while (head != null) {
            length ++;
            head = head.next;
        }
        return length;
    }

    /**
     * @param head: the List
     * @param k: rotate to the right k places
     * @return: the list after rotation
     */
    public ListNode rotateRight(ListNode head, int k) {
        if(head==null||head.next==null||k==0){
            return head;
        }
        int length = getLength(head);
        k = k % length;
        ListNode dummy = new ListNode(0);
        dummy.next= head;
        head =dummy;
        int ct= 0;
        while(head.next!=null&&ct<k){
            head=head.next;
            ct++;
        }
        ListNode head1 = dummy;
        while(head.next!=null){
            head1 = head1.next;
            head= head.next;
        }
        head.next=dummy.next;
        dummy.next = head1.next;
        head1.next=null;
        return dummy.next;
    }
}
