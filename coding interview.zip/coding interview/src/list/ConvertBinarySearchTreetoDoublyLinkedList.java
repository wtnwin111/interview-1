package list;

import tree.TreeNode;

/**
 * Convert a binary search tree to doubly linked list with in-order traversal.
 * <p>
 * Have you met this question in a real interview? Yes
 * Example
 * Given a binary search tree:
 * <p>
 *      4
 *      / \
 *     2   5
 *    / \
 *   1   3
 * return 1<->2<->3<->4<->5
 * <p>
 * Created by K25553 on 10/13/2016.
 */
public class ConvertBinarySearchTreetoDoublyLinkedList {
    public class DoublyListNode {
        int val;
        DoublyListNode next, prev;

        DoublyListNode(int val) {
            this.val = val;
            this.next = this.prev = null;
        }
    }
    /**
     * @param root: The root of tree
     * @return: the head of doubly list node
     */
    public DoublyListNode bstToDoublyList(TreeNode root) {
        DoublyListNode dummy = new DoublyListNode(0);
        DoublyListNode tail = dummy;
        dfs(root, tail);
        return dummy.next;
    }

    private DoublyListNode dfs(TreeNode root, DoublyListNode tail) {
        if (root==null){
            return tail;
        }
        if(root.left==null&&root.right==null){
            DoublyListNode crt = new DoublyListNode(root.val);
            tail.next = crt;
            crt.prev=tail;
            return crt;
        }
        DoublyListNode l = dfs(root.left, tail);
        DoublyListNode crt = new DoublyListNode(root.val);
        l.next = crt;
        crt.prev=l;
        DoublyListNode r = dfs(root.right, crt);
        return r;
    }
}
