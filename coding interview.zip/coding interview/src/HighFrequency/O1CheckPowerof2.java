/**
 *
 */
package HighFrequency;

/**
 * Using O(1) time to check whether an integer n is a power of 2.
 * 
 * Example
 * For n=4, return true;
 * 
 * For n=5, return false;
 * 
 * Challenge
 * O(1) time
 * 
 * @author Tiannan
 *         analysis; if a decimal is a num power of 2: 2 4 8 the bit: 10 100
 *         1000...so n-1 is 1 11 111 then & : 0&1= 0 to test
 */
public class O1CheckPowerof2 {
	/*
	 * @param n: An integer
	 * 
	 * @return: True or false
	 */
	public boolean checkPowerOf2(int n) {
		// write your code here

		if (((n & (n - 1)) == 0) && (n > 0)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
