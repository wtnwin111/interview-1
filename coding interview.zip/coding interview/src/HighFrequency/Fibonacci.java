/**
 * 
 */
package HighFrequency;

import java.util.ArrayList;

/**
 * @author Tiannan
 *
 */
public class Fibonacci {
	public static int fib(int start, int pre, int index){
		
		 if (index==0){
			return start;
		}
		System.out.println(start);
		return fib(start+pre, start, index-1);
	}
	public static int fib(int index){
		
		 if (index<=2){
			return 1;
		}
	
		return fib(index-1)+fib(index-2);
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(fib(1,0,10));
		System.out.println(fib(9));
	}

}
