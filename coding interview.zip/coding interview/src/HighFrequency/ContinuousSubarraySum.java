/**
 *
 */
package HighFrequency;

import java.util.ArrayList;

/**
 * Given an integer array, find a continuous subarray where the sum of numbers
 * is the biggest. Your code should return the index of the first number and the
 * index of the last number. (If their are duplicate answer, return anyone)
 * Example
 * Give [-3, 1, 3, -3, 4], return [1,4].
 *
 * @author K25553
 *
 */
public class ContinuousSubarraySum {
	/**
	 * @param A
	 *            an integer array
	 * @return A list of integers includes the index of the first number and the
	 *         index of the last number
	 */
	public ArrayList<Integer> continuousSubarraySum(int[] A) {
		ArrayList<Integer> result = new ArrayList<Integer>();
		result.add(0);
		result.add(0);

		int len = A.length;
		int l = 0, r = 0;
		int sum = 0;
		int max = Integer.MIN_VALUE;
		for (int i = 0; i < len; ++i) {
			if (sum < 0) {
				sum = 0 + A[i];
				l = r = i;
			} else if (sum >= 0) {
				sum += A[i];
				r = i;
			}
			if (sum >= max) {
				max = sum;
				result.set(0, l);
				result.set(1, r);
			}
		}
		return result;
	}

	public static ArrayList<Integer> continuousSubarraySum1(int[] A) {
		// Write your code here
		ArrayList<Integer> result = new ArrayList<Integer>();
		result.add(0);
		result.add(0);

		int len = A.length;
		int start = 0, end = 0;
		int sum = 0;
		int ans = -0x7fffffff;
		for (int i = 0; i < len; ++i) {
			if (sum < 0) {
				sum = A[i];
				start = end = i;
			} else {
				sum += A[i];
				end = i;
			}
			if (sum >= ans) {
				ans = sum;
				result.set(0, start);
				result.set(1, end);
			}
		}
		return result;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int[] a = { -3, 1, 3, -3, 4 };
		System.out.println(continuousSubarraySum1(a).toString());

	}

}
