/**
 * 
 */
package HighFrequency;

/**
 * @author Tiannan
 *analysis: 
 *	sum:sliding window
 *	add the cur to sum
 *	if sum less than 0, slide left window to cur
 *	else move right window to the next
 *
 *sum2: cutting scope 
 *��������е�ֵΪ ������������в�����ֵ��
 *�ۻ����0����ǰi���ܺ�sum��Ȼ��sum��ȥ��0��ʼ����ǰi֮ǰĳһλj����Сsumֵ��Ȼ����sum��ȥ�����Сsumֵ������һ���ܵ����ֵ��
 *
 *sum3 dp[]
 *init dp[0]=a[0] max= dp[0]
 *fun dp[i]=max(a[i], a[i]+dp[i-1]); max=max (max, dp[i])
 *dp[i]
 *
 *res max 
 */
public class MaximumSubarray {
	// sliding window:
	//if
	//
	public static int sum(int[] a){
		if(a==null&&a.length==0){
			return 0;
		}
		int max= Integer.MIN_VALUE;
		int sum=0;
		for(int i=0;i<a.length; i++){
			sum+=a[i];
			
			max=Math.max(max, sum);
			sum=Math.max(sum, 0);
			System.out.println(sum);
			System.out.println(max);
		} 
		return max;
	}
	
	//c
	public static int sum1(int[] a){
		if(a==null&&a.length==0){
			return 0;
		}
		int minsum=0,sum=0;
		int max= Integer.MIN_VALUE;
		
		for(int i=0;i<a.length; i++){
			sum+=a[i];
			max=Math.max(max, sum-minsum);
			minsum=Math.min(sum, minsum);
			sum=Math.max(sum, 0);
		}
		return max;
	}
	
	public static int sum3(int [] a){
		if(a==null&&a.length==0){
			return 0;
		}
		int dp[] = new int [a.length];
		int  max=dp[0]=a[0];
		for (int i=1;i<a.length;i++){
			dp[i]= Math.max(a[i],dp[i-1]+a[i]);
			max=Math.max(dp[i], max); 
			System.out.println(dp[i]);
			System.out.println(max);
		}
		
		return max;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(sum(new int[]{-2,1,-3,4,-1,2,1,-5,4}));
		System.out.println(sum3(new int[]{-2,1,-3,4,-1,2,1,-5,4}));
	}

}
