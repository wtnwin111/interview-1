/**
 * 
 */
package HighFrequency;

/**
 * Given an array with positive and negative integers. 
 * Re-range it to interleaving with positive and negative integers.

Example
Given [-1, -2, -3, 4, 5, 6], after re-range, it will be [-1, 5, -2, 4, -3, 6] or any other reasonable answer.
 * @author Tiannan
 *
 */
public class InterleavingPositiveandNegativeNumbers {
	 /**
     * @param A: An integer array.
     * @return: void
     */
	/*
	   Solution 4:
	   ��reverse�Ĳ������һ��
	   */
	   public static int[] rerange(int[] A) {
	        // write your code here
	        
	        // Check the input parameter.
	        if (A == null || A.length <= 2) {
	            return A;
	        }
	        
	        int len = A.length;
	        
	        int cntPositive = 0;
	        
	        // store the positive numbers index.
	        int i1 = 0;
	        
	        for (int i2 = 0; i2 < len; i2++) {
	            if (A[i2] > 0) {
	                cntPositive++;
	                
	                // Put all the positive numbers at in the left part.
	                swap(A, i1++, i2);
	            }
	        }
	        
	        // If positive numbers are more than negative numbers,
	        // Put the positive numbers at first.
	        int posPointer = 1;
	        int negPointer = 0;
	        
	        if (cntPositive > A.length / 2) {
	            // Have more Positive numbers;
	            posPointer = 0;
	            negPointer = 1;
	            
	            // Reverse the array.
	            int left = 0;
	            int right = len -1;
	            while (right >= cntPositive) {
	                swap(A, left, right);
	                left++;
	                right--;
	            }
	        }
	        
	        // Reorder the negative and the positive numbers.
	        while (true) {
	            // Should move if it is in the range.
	            while (posPointer < len && A[posPointer] > 0) {
	                posPointer += 2;
	            }
	            
	            // Should move if it is in the range.
	            while (negPointer < len && A[negPointer] < 0) {
	                negPointer += 2;
	            }
	            
	            if (posPointer >= len || negPointer >= len) {
	                break;
	            }
	            
	            swap(A, posPointer, negPointer);
	        }
	        
	        return A;
	   }
	private static void swap(int[] a, int i, int i2) {
		// TODO Auto-generated method stub
		int temp=a[i];
		a[i]=a[i2];
		a[i2]=temp;
		
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
