/**
 *
 */
package twoPoint;

import java.util.Arrays;
import java.util.HashSet;

/**
 * Given a string, find the length of the longest substring without repeating
 * characters.
 *
 * Example
 * For example, the longest substring without repeating letters for "abcabcbb"
 * is "abc", which the length is 3.
 *
 * For "bbbbb" the longest substring is "b", with the length of 1.
 *
 * @author Tiannan
 *         analysis:use 2 pointer i j to find the max longest substring,
 *         use set or hashmap to check if it is duplicated
 *         if so, left side i ++, and remove ai from set until remove the
 *         duplicated or i> j
 *         else is not duplicated, then j++ , add to set, update max
 */
public class LongestSubstringWithoutRepeatingCharacters {
	public int lengthOfLongestSubstring(String s) {
		if (s == null || s.length() == 0) {
			return 0;
		}

		HashSet<Character> set = new HashSet<Character>();

		int leftBound = 0, max = 0;
		for (int i = 0; i < s.length(); i++) {
			if (set.contains(s.charAt(i))) {
				while (leftBound < i && s.charAt(leftBound) != s.charAt(i)) {
					set.remove(s.charAt(leftBound));
					leftBound++;
				}
				leftBound++;
			} else {
				set.add(s.charAt(i));
				max = Math.max(max, i - leftBound + 1);
			}
		}

		return max;
	}

	/**
	 * @param s
	 *            : a string
	 * @return: an integer
	 */
	// ����һ��
	public int lengthOfLongestSubstring1(String s) {
		int[] map = new int[256]; // map from character's ASCII to its last
		// occured index
		Arrays.fill(map, -1);

		int slow = 0;
		int fast = 0;
		int ans = 0;
		for (fast = 0; fast < s.length(); fast++) {
			int ch = s.charAt(fast);
			while (map[ch] != -1 && slow < fast) {
				int temp = s.charAt(slow);
				map[temp] = -1;
				slow++;
			}
			map[ch] = 0;
			ans = Math.max(ans, fast - slow + 1);
		}

		return ans;
	}

	// ����һ��
	public static int lengthOfLongestSubstring12(String s) {
		if (s == null || s.length() == 0) {
			return 0;
		}
		int[] map = new int[256]; // map from character's ASCII to its last
		// occured index
		Arrays.fill(map, -3);
		int len = s.length();
		int slow = 0;
		int fast = 1;
		int ans = 1;
		for (; slow < len; slow++) {
			int char1 = s.charAt(slow);
			map[char1] = slow;
			while (fast < len) {
				int char2 = s.charAt(fast);
				if (char2 == char1) {
					ans = Math.max(ans, fast - map[char1]);
					map[char2] = fast;
					fast++;
					break;
				} else if (map[char2] > -1 && map[char2] > slow) {

					ans = Math.max(ans, fast - map[char1]);
					slow = map[char2];
					map[char2] = fast;
					fast++;
					break;
				} else {

					ans = Math.max(ans, fast - map[char1] + 1);
					map[char2] = fast;
					fast++;
				}
			}
		}

		return ans;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = "-".charAt(0);
		System.out
		.println(lengthOfLongestSubstring12("crdghfrgrgyanjclxgzuomlqxfgeqguuaxdjcuruapwpbzbyhau"));
	}

}
