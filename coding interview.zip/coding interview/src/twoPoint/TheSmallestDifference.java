/**
 * 
 */
package twoPoint;

import java.util.Arrays;

/**
 * Given two array of integers(the first array is array A, the second array is array B), now we are going to find a element in array A which is A[i], and another element in array B which is B[j], so that the difference between A[i] and B[j] (|A[i] - B[j]|) is as small as possible, return their smallest difference. 


Example 

For example, given array A = [3,6,7,4], B = [2,8,9,3], return 0

Challenge 

O(n log n) time
Tags  Expand    



 * @author Tiannan
 *analysis: abs difference min is to update min with each ele difference from a,
 *once a and b sorted, find first b+1 ele > than a ele, so min for current a=min Math.abs(B[idB]- A[idA]) Math.abs(B[idB+1]- A[idA])
 *then move forward to a and b to the end, update each min to find min;
 */
public class TheSmallestDifference {
	/**
     * @param A, B: Two integer arrays.
     * @return: Their smallest difference.
     */
    public int smallestDifference(int[] A, int[] B) {
        // write your code here
        Arrays.sort(A);
        Arrays.sort(B);
        
        int idA = 0, idB = 0; 
        int ans = Integer.MAX_VALUE;
        for(idA = 0; idA < A.length && idB < B.length; idA++) {
            while(idB + 1 < B.length) {
                if(B[idB + 1] > A[idA]) {
                    break;
                }
                idB++;
            }
            if(idB < B.length) {
                ans = Math.min(ans, Math.abs(B[idB]- A[idA]));
            }
            if(idB + 1 < B.length) {
                ans = Math.min(ans, Math.abs(B[idB + 1]- A[idA]));
            }
        }
        
        return ans;
    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
