package array;

/**For an array A, if i < j, and A [i] > A [j], called (A [i], A [j]) is a reverse pair.
 return total of reverse pairs in A.

 Have you met this question in a real interview? Yes
 Example
 Given A = [2, 4, 1, 3, 5] , (2, 1), (4, 1), (4, 3) are reverse pairs. return 3
 * Created by K25553 on 10/18/2016.
 */
public class ReversePairs {
    /**
     * @param A an array
     * @return total of reverse pairs
     */
    public long reversePairs(int[] a) {
        int ct = 0;
        int [] temp = new int[a.length];
        return mergesort(a, temp, 0, a.length-1);
    }

    private long mergesort(int[] a, int[] temp, int l, int r) {
        if(l>=r){
            return 0;
        }
        int sum =0;
        int mid = l+ (r-l)/2;
        sum += mergesort( a, temp, l,mid);
        sum += mergesort( a, temp, mid+1, r);
        sum += merge(a, temp, l, r, mid);
        return sum;
    }

    private int merge(int[] a, int[] temp, int start, int end, int mid) {
        int index= start;
        int l= start;
        int r= mid+1;
        int sum = 0;
        while(l<=mid&&r<=end){
            if(a[l]<=a[r]){
                temp[index++]=a[l++];
            }else{
                temp[index++]=a[r++];
                // impz:
                // 20, mid 2, then 0 2
                //sum mid -l +1
                // since division of conque, partition l to mid and mid +1 to end are sorted
                // if(a[l]>=a[r]) then crt l to mid > a[r];
                sum += mid-l+1;

            }
        }
        while(l <= mid){
            temp[index++]=a[l++];
        }
        while(r <= end){
            temp[index++] = a[r++];
        }
        for( int i = start; i<=end;i++){
            a[i]=temp[i];
        }
        return sum;
    }


}
