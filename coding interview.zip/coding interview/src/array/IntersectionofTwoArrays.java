/**
 *
 */
package array;

import java.util.Arrays;
import java.util.HashSet;

/**
 * Given two arrays, write a function to compute their intersection.
 *
 * Notice
 *
 * Each element in the result must be unique.
 * The result can be in any order.
 * Have you met this question in a real interview? Yes
 * Example
 * Given nums1 = [1, 2, 2, 1], nums2 = [2, 2], return [2].
 *
 * @author K25553
 *
 */
public class IntersectionofTwoArrays {
	/**
	 * @param nums1
	 *            an integer array
	 * @param nums2
	 *            an integer array
	 * @return an integer array
	 */
	public int[] intersection1(int[] nums1, int[] nums2) {
		Arrays.sort(nums1);
		Arrays.sort(nums2);
		// 2 pointer, temp [] for intersection, res[ct]: copy temp to res
		int i = 0, j = 0, ct = 0;
		int[] temp = new int[nums1.length];
		while (i < nums1.length && j < nums2.length) {
			if (nums1[i] == nums2[j]) {
				if (ct == 0 || temp[ct - 1] < nums1[i]) {
					temp[ct++] = nums1[i];
				}
				i++;
				j++;
			} else if (nums1[i] < nums2[j]) {
				i++;
			} else if (nums1[i] > nums2[j]) {
				j++;
			}
		}
		int[] res = new int[ct];
		for (int i1 = 0; i1 < ct; i1++) {
			res[i1] = temp[i1];
		}
		return res;
	}

	// hash set
	public int[] intersection(int[] nums1, int[] nums2) {
		HashSet<Integer> nums = new HashSet<Integer>();
		// nums.addAll(new ArrayList(Arrays.asList(nums1)));
		for (int i : nums1) {
			nums.add(i);
		}
		HashSet<Integer> res = new HashSet<Integer>();
		// nums map the intersection, res stores resul
		// imp: once adding ele, check intersecion and res has already stored
		// the ele
		for (int i = 0; i < nums2.length; i++) {
			if (nums.contains(nums2[i]) && !res.contains(nums2[i])) {
				res.add(nums2[i]);
			}
		}
		int k = 0;
		int[] ans = new int[res.size()];
		for (Integer j : res) {
			ans[k++] = j;
		}
		return ans;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
