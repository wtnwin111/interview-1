package array.Matrix;

import java.util.Arrays;

/**Determine whether a Sudoku is valid.

 The Sudoku board could be partially filled, where empty cells are filled with the character ..
 * Created by K25553 on 9/20/2016.
 */
public class ValidSudoku {
    /**
     * @param board: the board
     @return: wether the Sudoku is valid
     */
    public boolean isValidSudoku(char[][] board) {
        boolean [] dic = new boolean[9];
        int x = board.length;
        int y = board[0].length;
        //row
        for(int i=0; i<x;i++){
            Arrays.fill(dic,false);
            for(int j=0; j<y; j++){
                if(!process(dic, board[i][j])){
                   return false;
                }
            }
        }
        //col
        for(int j=0; j<y; j++){
            Arrays.fill(dic,false);
            for(int i=0; i<x;i++){
                if(!process(dic, board[i][j])){
                    return false;
                }
            }
        }
        //sub
        for(int i=0; i<x;i+=3){
            for(int j=0; j<y; j+=3){
                Arrays.fill(dic,false);
                for(int k=0; k<3;k++){
                    for(int l=0; l<3;l++){
                        if(!process(dic, board[i+k][j+l])){
                            return false;
                        }
                    }
                }

            }
        }
        return true;
    }

    private boolean process(boolean[] dic, char b) {
        if(b=='.'){
            return true;
        }
        int num = b-'0';
        if(num>=1&&num<=9&&!dic[num-1]){
            dic[num-1] = true;
            return true;
        }
        return false;
    }
}
