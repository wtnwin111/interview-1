package array.Matrix;

/**
 * Created by K25553 on 10/17/2016.
 */
public class SpiralMatrixII {
    /**
     * @param n an integer
     * @return a square matrix
     */
    public int[][] generateMatrix(int n) {
        if (n < 0) {
            return null;
        }
        int [][]res = new int[n][n];
        if(n== 0){
            return res;
        }else if(n==1){
            res[0][0]=1;
            return res;
        }
        int ct=1;
        int top=0;
        int bottom = n-1;
        int left =0;
        int right = n-1;
        while(ct<=n*n){
            //top row
            for(int i =left; ct<=n*n&&i<=right;i++){
                res[top][i] = ct;
                ct++;
            }
            top++;
            //right col
            for(int i=top; ct<=n*n&&i<=bottom;i++){
                res[i][right]= ct;
                ct++;
            }
            right--;
            //bottom row
            for ( int i = right;ct<=n*n&&i>=left;i--){
                res[bottom][i]=ct;
                ct++;
            }
            bottom--;
            //left col
            for(int i = bottom; ct<=n*n&&i>=top;i--){
                res[i][left] = ct;
                ct++;
            }
            left++;
        }
        return res;
    }
}
