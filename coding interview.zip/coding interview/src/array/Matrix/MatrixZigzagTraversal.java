package array.Matrix;

/**Given a matrix of m x n elements (m rows, n columns), return all elements of the matrix in ZigZag-order.

 Have you met this question in a real interview? Yes
 Example
 Given a matrix:

 [
 [1, 2,  3,  4],
 [5, 6,  7,  8],
 [9,10, 11, 12]
 ]
 return [1, 2, 5, 9, 6, 3, 4, 7, 10, 11, 8, 12]

 * Created by K25553 on 10/14/2016.
 *
 *-
 */
public class MatrixZigzagTraversal {
    /**
     * @param matrix: a matrix of integers
     * @return: an array of integers
     */
    public static int[] printZMatrix(int[][] matrix) {
        int x = matrix.length;
        int y = matrix[0].length;
        if(x<=1){
            return matrix[0];
        }else if(y<=1){
            int [] res= new int[x];
            for(int i=0; i<x;i++){
                res[i]=matrix[i][0];
            }
            return res;
        }


        int ct=0;
        int[] res = new int[x*y];
        int i=0,j=0;//mapping xy
        boolean direct = true;
        boolean up =true;
        while(ct<x*y){
            res[ct]=matrix[i][j];
            ct++;
            if(i==0){
               if(direct){
                   direct= false;
                   if(j==y-1){
                       i++;
                   }else{
                       j++;
                   }
               }else{
                   direct= true;
                   i++;
                   j--;
                   up=!up;
                }
                continue;
            }else if(j==0){
                if(direct){
                    direct= false;
                    if(i==x-1){
                        j++;
                    }else{
                        i++;
                    }
                }else{
                    direct= true;
                    i--;
                    j++;
                    up=!up;
                }
                continue;
            }else if(j==y-1){
                if(direct){
                    direct= false;
                    if(i==x-1){
                        break;
                    }else{
                        i++;
                    }
                }else{
                    direct= true;
                    i++;
                    j--;
                    up=!up;
                }
                continue;
            }else if(i==x-1){
                if(direct){
                    direct= false;
                    if(j==y-1){
                        break;
                    }else{
                        j++;
                    }
                }else{
                    direct= true;
                    i--;
                    j++;
                    up=!up;
                }
                continue;
            }else if(up){
                i--;
                j++;
                continue;
            }else{
                i++;
                j--;
                continue;
            }
        }
        return res;
    }
    /**
     * @param matrix: a matrix of integers
     * @return: an array of integers
     */
    public int[] printZMatrix1(int[][] matrix) {
        // write your code here
        int x, y, dx, dy, count, m, n;
        x = y = 0;
        count = 1;
        dx = -1; dy = 1;
        m = matrix.length;
        n = matrix[0].length;
        int[] z = new int[m*n];
        z[0] = matrix[0][0];
        while (count<m*n) {
            if (x+dx>=0 && y+dy>=0 && x+dx<m && y+dy<n) {
                x += dx; y += dy;
            }
            else
            if (dx==-1 && dy ==1) {
                if (y+1<n) ++y; else ++x;
                dx = 1; dy = -1;
            }
            else {
                if (x+1<m) ++x; else ++y;
                dx = -1; dy = 1;
            }
            z[count] = matrix[x][y]; ++count;
        }
        return z;
    }
    public static void main(String[]args){
        int [][]res = new int[][]{
            {1, 2,  3,  4},
            {5, 6,  7,  8},
            {9,10, 11, 12}
        };
        System.out.println(printZMatrix(res));
    }
}
