package array.Matrix;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by K25553 on 10/14/2016.
 */
public class SpiralMatrix {
    /**
     * @param matrix a matrix of m x n elements
     * @return an integer list
     */
    public List<Integer> spiralOrder(int[][] matrix) {
        List<Integer> res = new ArrayList<>();
        //imp chech matrix.lenght firs, corner case: [] means matrix length =0 and mtr[0] == null
        if(matrix==null|| matrix.length == 0||matrix[0] == null || matrix[0].length == 0)return res;
        int row =matrix.length;
        int col = matrix[0].length;
        int top=0;
        int bottom = row-1;
        int left = 0;
        int right = col-1;
        int ct=0;


        while(ct<row*col){
            //top row
            for(int i = left; ct<row*col&&i<= right; i ++ ){
                res.add(matrix[top][i]);
                ct++;
            }
            top++;

            //right col
            for(int i = top; ct<row*col&&i<= bottom; i ++ ){
                res.add(matrix[i][right]);
                ct++;
            }
            right--;
            //buttom row
            for(int i = right; ct<row*col&&i>=left; i -- ){
                res.add(matrix[bottom][i]);
                ct++;
            }
            bottom--;
            //left col
            for(int i = bottom; ct<row*col&&i>=top; i -- ){
                res.add(matrix[i][left]);
                ct++;
            }
            left++;
        }
        return res;
    }
}
