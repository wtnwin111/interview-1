package array.Matrix;

/**You are given an n x n 2D matrix representing an image.
 Rotate the image by 90 degrees (clockwise).

 Have you met this question in a real interview? Yes
 Example
 Given a matrix

 [
 [1,2],
 [3,4]
 ]
 rotate it by 90 degrees (clockwise), return

 [
 [3,1],
 [4,2]
 ]
 Challenge
 Do it in-place.
 * Created by K25553 on 10/14/2016.
 */
public class RotateImage {
    public void rotate(int[][] matrix) {
        if (matrix == null || matrix.length == 0 || matrix[0].length == 0) {
            return;
        }

        int length = matrix.length;

        for (int i = 0; i < length / 2; i++) {
            for (int j = 0; j < (length + 1) / 2; j++){
                int tmp = matrix[i][j];
                matrix[i][j] = matrix[length - j - 1][i];
                matrix[length -j - 1][i] = matrix[length - i - 1][length - j - 1];
                matrix[length - i - 1][length - j - 1] = matrix[j][length - i - 1];
                matrix[j][length - i - 1] = tmp;
            }
        }
    }
    //˼·�����Դ�ֱ��Ϊ����ˮƽ��ת��������Խ���Ϊ����б��ת��
    public void rotate1(int[][] matrix) {
        if(null == matrix || matrix.length == 0 || matrix[0].length == 0) return;
        int row = matrix.length;
        int col = matrix[0].length;
        if(row != col) return;
        for(int i = 0; i < row; i++) {
            for(int j = 0; j <= (col-1)/2; j++) {
                int temp = matrix[i][j];
                matrix[i][j] = matrix[i][col-1-j];
                matrix[i][col-1-j] = temp;
            }
        }
        for(int i = 0; i < row; i++) {
            for(int j = 0; j < row-i-1; j++) {
                int temp = matrix[i][j];
                matrix[i][j] = matrix[row-j-1][row-i-1];
                matrix[row-j-1][row-i-1] = temp;
            }
        }
    }
}
