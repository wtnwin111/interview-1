/**
 *
 */
package array.permutation;

/**Given a list of integers, which denote a permutation.

 Find the next permutation in ascending order.
 * @author K25553
 *Example
 * http://blog.csdn.net/m6830098/article/details/17291259
For [1,3,2,3], the next permutation is [1,3,3,2]

For [4,3,2,1], the next permutation is [1,2,3,4]
1,2,3 �� 1,3,2
3,2,1 �� 1,2,3
1,1,5 �� 1,5,1
 observation:
12345	6
1234    65
1235	46
1235	64
1236	45
 left     right
 		increasing
 */
public class NextPermutation {
	/**
	 * @param nums: an array of integers
	 * @return: return nothing (void), do not return anything, modify nums in-place instead
	 */
	public int[] nextPermutation(int[] nums) {
		if(nums==null||nums.length<2){
            return nums;
        }
        int change;
        for(int i= nums.length-2; i>-1;i-- ){
            if(nums[i]<nums[i+1]){

                for(int j= nums.length-1; j>i;j--){
                    if(nums[j]>nums[i]){
                        swap(nums, i, j);
                        break;
                    }
                }
                reverse (i+1,nums.length-1, nums);
                return nums;
            }
        }
        reverse (0,nums.length-1, nums);
        return nums;
	}

    private void reverse(int i, int j, int [] nums) {
        while (i<j){
            swap(nums,i,j);
            i++;
            j--;
        }
    }

    private void swap(int[] nums, int i, int j) {
        int temp= nums[i];
        nums[i]= nums[j];
        nums[j]=temp;
    }


    /**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
