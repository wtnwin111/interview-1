package array.permutation;

import java.util.HashMap;
import java.util.Map;

/**Given a permutation which may contain repeated numbers, find its index in all the permutations of these numbers, which are ordered in lexicographical order. The index begins at 1.
 * Example
 Given the permutation [1, 4, 2, 2], return 3.
 * Created by K25553 on 8/15/2016.
 * http://algorithm.yuanbin.me/zh-hans/exhaustive_search/permutation_index_ii.html
 * �� Permutation Index ����չ��������Ҫ�����ظ�Ԫ�أ������ظ�Ԫ��������������ԭ����1!, 2!, 3!...����Ҫ�����ظ�Ԫ�ظ����Ľ׳ˣ����е��������������ζ����
 * ��¼�ظ�Ԫ�ظ���ͬ����Ҫ��̬���£������ϣ��������ܵĹ��߽�Ϊ���㡣
 */
public class PermutationIndexII {
    /**
     * @param A an integer array
     * @return a long integer
     */
    public long permutationIndexII2(int[] A) {
        if (A == null || A.length == 0) return 0L;
        //a[i], cout of a i
        Map<Integer, Integer> hashmap = new HashMap<Integer, Integer>();
        long index = 1, fact = 1, multiFact = 1;
        for (int i = A.length - 1; i >= 0; i--) {
            // collect its repeated times and update multiFact
            if (hashmap.containsKey(A[i])) {
                //22 2*1/2  222 3*2*1/3*2*1 221 3*2*1/2*1
                hashmap.put(A[i], hashmap.get(A[i]) + 1);
                multiFact *= hashmap.get(A[i]);
            } else {
                hashmap.put(A[i], 1);
            }
            // get rank every turns
            int rank = 0;
            for (int j = i + 1; j < A.length; j++) {
                if (A[i] > A[j]) rank++;
            }
            // do divide by multiFact
            index += rank * fact / multiFact;
            fact *= (A.length - i);
        }

        return index;
    }

    public long permutationIndexII(int[] a) {
       if(a==null||a.length==0){
           return 0;
       }
        Map<Integer,Integer> hm = new HashMap<>();
        int fact=1,index=1,duplicate=1;
        for(int i=a.length;i>-1;i--){
            if(hm.containsKey(a[i])){
                hm.put(a[i],hm.get(a[i])+1);
                duplicate*= hm.get(a[i]);
            }else {
                hm.put(a[i],1);
            }
            int rank=0;
            for(int j=i+1;j<a.length;j++){
                if(a[j]<a[i]){
                    rank++;
                }
            }
            index +=index*rank*fact/duplicate;
            fact*=(a.length-i);
        }
        return index;
    }
}
