package array.Enumeration;

import java.util.ArrayList;

/**Given a dictionary, find all of the longest words in the dictionary.
 * Example
 Given

 {
 "dog",
 "google",
 "facebook",
 "internationalization",
 "blabla"
 }
 the longest words are(is) ["internationalization"].

 Given

 {
 "like",
 "love",
 "hate",
 "yes"
 }
 the longest words are ["like", "love", "hate"].
 * Created by K25553 on 9/15/2016.
 */
public class LongestWords {
    /**
     * @param dictionary: an array of strings
     * @return: an arraylist of strings
     */
    ArrayList<String> longestWords(String[] dictionary) {
       ArrayList<String> res = new ArrayList<>();
        if(dictionary==null||dictionary.length==0){
            return res;
        }
        int len =0;
        for (String string:dictionary){
            len = Math.max(len, string.length());
        }
        for (String string: dictionary){
             if(string.length()==len){
                 res.add(string);
             }
        }
        return res;
    }
}
