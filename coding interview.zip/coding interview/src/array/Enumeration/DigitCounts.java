package array.Enumeration;

/**Count the number of k's between 0 and n. k can be 0 - 9.
 * Example
 if n = 12, k = 1 in

 [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
 we have FIVE 1's (1, 10, 11, 12)

 Tags
 Enumeration
 * Created by K25553 on 9/15/2016.
 */
public class DigitCounts {
    /*
    * param k : As description.
    * param n : As description.
    * return: An integer denote the count of digit k in 1..n
    */
    public static int digitCounts(int k, int n) {
        int ct=0;
        for(int i=k; i<n+1;i++){
            int current = i;
            if(current==0&&k==0){
                ct++;
            }

            while(current>0){

                if( current%10==k){
                    ct++;
                }
                current= current/10;
            }
        }
        return ct;
    }
    public static void main ( String [] arg){
        System.out.println(digitCounts(1,1));
    }
}
