/**
 *
 */
package array;

/**
 * Given n and k, return the k-th permutation sequence.
 * For n = 3, all permutations are listed as follows:
 * 
 * "123"
 * "132"
 * "213"
 * "231"
 * "312"
 * "321"
 * If k = 4, the fourth permutation is "231"
 * 
 * @author K25553
 *
 */
public class PermutationSequence {
	/**
	 * @param n
	 *            : n
	 * @param k
	 *            : the kth permutation
	 * @return: return the k-th permutation
	 */

	int ct = 0;

	public String getPermutation(int n, int k) {

		int[] visited = new int[n];
		int[] dic = new int[n];
		for (int i = 0; i < n; i++) {
			dic[i] = i + 1;
		}

		StringBuilder tempString = new StringBuilder();
		dfs(dic, k, tempString, visited);
		return tempString.toString();

	}

	private void dfs(int[] dic, int k, StringBuilder tempString, int[] visited) {

		if (tempString.length() == dic.length) {
			ct++;

			return;
		}

		for (int i = 0; i < dic.length; i++) {
			if (visited[i] == 1) {
				continue;
			}
			visited[i] = 1;
			tempString.append(dic[i]);
			dfs(dic, k, tempString, visited);
			if (ct == k) {
				break;
			}
			visited[i] = 0;
			tempString.deleteCharAt(tempString.length() - 1);
		}
	}

	public int factorial(int N) {
		if (N == 1) {
			return 1;
		}
		return N * factorial(N - 1);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
