/**
 * 
 */
package array;

/**Merge two given sorted integer array A and B into a new sorted integer array.
 * @author K25553
 *imp: while {while{}} causes exceeds the time limit
 */
public class MergeSortedArrayII {
	  /**
     * @param A and B: sorted integer array A and B.
     * @return: A new sorted integer array
     */
    public int[] mergeSortedArray(int[] a, int[] b) {

        if(a.length==0||a==null){
            return b;
        }
        if(b.length==0||b==null){
            return a;
        }
        int i=0, j=0, index=0;
        int []c = new int [a.length+b.length];
        while(i < a.length && j< b.length){
            if(a[i]<=b[j])
            { c[index++]=a[i++];
                
            }else
            {
            	c[index++]=b[j++];
            }
        }
       
        	 while(i < a.length){
        		 c[index++]=a[i++];
        	 }
        	 while(j < b.length){
        		 c[index++]=b[j++];
        	 }
        
        
        return c;
    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
