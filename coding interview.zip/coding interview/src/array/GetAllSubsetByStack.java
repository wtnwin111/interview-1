package array;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Stack;

public class GetAllSubsetByStack {

	/** Set a value for target sum */
	public static final int TARGET_SUM = 15;

	private Stack<Integer> stack = new Stack<Integer>();

	/** Store the sum of current elements stored in stack */
	private int sumInStack = 0;

	public void populateSubset(final int[] data, int fromIndex, int endIndex) {

		if (sumInStack >= TARGET_SUM) {
			if (sumInStack == TARGET_SUM) {
				print(stack);
			}
			// there is no need to continue when we have an answer
			// because nothing we add from here on in will make it
			// add to anything less than what we have...
			return;
		}

		for (int currentIndex = fromIndex; currentIndex < endIndex; currentIndex++) {

			if (sumInStack + data[currentIndex] <= TARGET_SUM) {
				stack.push(data[currentIndex]);
				sumInStack += data[currentIndex];

				/*
				 * Make the currentIndex +1, and then use recursion to proceed
				 * further.
				 */
				populateSubset(data, currentIndex + 1, endIndex);
				sumInStack -= stack.pop();
			}
		}
	}

	List<ArrayList<Integer>> subset(int target, int[] dic) {
		ArrayList<ArrayList<Integer>> res = new ArrayList<ArrayList<Integer>>();
		if (dic == null || dic.length == 0) {
			return res;
		}
		Arrays.sort(dic);
		ArrayList<Integer> temp = new ArrayList<Integer>();
		int sum = 0;
		subsetHelper(target, dic, 0, res, temp, sum);
		return res;
	}

	private void subsetHelper(int target, int[] dic, int pos,
			ArrayList<ArrayList<Integer>> res, ArrayList<Integer> temp, int sum) {
		if (sum >= target) {
			if (sum == target) {
				res.add(new ArrayList<Integer>(temp));
			}
			return;
		}

		for (int i = pos; i < dic.length; i++) {
			temp.add(dic[i]);
			sum += dic[i];
			subsetHelper(target, dic, i + 1, res, temp, sum);
			sum -= temp.get(temp.size() - 1);
			temp.remove(temp.size() - 1);

		}

	}

	/**
	 * Print satisfied result. i.e. 15 = 4+6+5
	 */

	private void print(Stack<Integer> stack) {
		StringBuilder sb = new StringBuilder();
		sb.append(TARGET_SUM).append(" = ");
		for (Integer i : stack) {
			sb.append(i).append("+");
		}
		System.out.println(sb.deleteCharAt(sb.length() - 1).toString());
	}

	private static final int[] DATA = { 1, 3, 4, 5, 6, 2, 7, 8, 9, 10, 11, 13,
		14, 15 };

	public static void main(String[] args) {
		GetAllSubsetByStack example = new GetAllSubsetByStack();
		example.populateSubset(DATA, 0, DATA.length);
		List<ArrayList<Integer>> res = example.subset(15, DATA);
		System.out.println(res.size());
		System.out.println(res.toString());
	}
}