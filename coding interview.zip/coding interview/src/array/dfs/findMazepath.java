package array.dfs;

import java.util.LinkedList;

/**
 * Created by K25553 on 11/16/2016.
 */
public class findMazepath {
    public  class Node{
        int x;
        int y;
        int val;
        Node(int x, int y, int val){
            this.x=x;
            this.y =y;
            this.val = val;
        }
    }

    private  boolean bfs(int[][] maze, int startx, int starty) {
        // TODO Auto-generated method stub
        if(maze == null)
            return false;
        if(maze.length == 0 || maze[0].length == 0)
            return false;
        LinkedList<Node> queue = new LinkedList<Node>();
        int[][] Direction = {{-1,0}, {0, -1}, {1, 0}, {0, 1}}; //������������
        Node n1 = new Node(0, 0, maze[0][0]);
        queue.offer(n1);

        int M = maze.length;
        int N = maze[0].length;

        while (!queue.isEmpty()) {
            Node node = queue.poll();
            if (node.val == 9) {
                return true;
            }
            for(int i = 0; i < 4; i++){
                int x = node.x + Direction[i][0];
                int y = node.y + Direction[i][1];
                //bfs
                if(x >= 0 && x < M && y >= 0 && y < N && maze[x][y] > 0){
                    Node newNode = new Node(x, y, maze[x][y]);
                    queue.offer(newNode);
                    maze[x][y] = -1;
                }
            }
        }
        return false;
    }
}
