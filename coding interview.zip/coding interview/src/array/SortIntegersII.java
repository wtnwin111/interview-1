package array;

/**Given an integer array, sort it in ascending order. Use quick sort, merge sort, heap sort or any O(nlogn) algorithm.
 * Created by K25553 on 10/18/2016.
 */
public class SortIntegersII {
    /**
     * @param a an integer array
     * @return void
     */
    public void sortIntegers2(int[] a) {
        int[] mergeCash = new int[a.length];
        mergeSort(a,0, a.length-1, mergeCash);
        quickSort(a,0, a.length-1);
    }

    private void quickSort(int[] a, int l, int r) {
        if(l>=r){
            return;
        }
        int pivot = a[l];
        int crt = l;
        int next = l+1;
        while (next<=r){
            if(a[next]<=pivot){
                crt++;
                swap(a, crt, next);
            }
            next++;
        }
        swap(a,crt,l);
        //imp  crt is final pos for pivot, so only sort l, crt-1 and crt+1, r
        quickSort(a, l, crt-1);
        quickSort(a, crt+1, r);

    }

    private void swap(int[] a, int crt, int next) {
        int temp = a[crt];
        a[crt] = a[next];
        a[next] = temp;
    }

    private void mergeSort(int[] a, int l, int r, int[] mergeCash) {
        if(l>=r){
            return;
        }
        int mid = l+ (r-l)/2;
        mergeSort(a,l, mid, mergeCash);
        mergeSort(a,mid+1, r , mergeCash);
        merge(a, l, r , mid,  mergeCash);
    }

    private void merge(int[] a, int start, int end, int mid, int[] mergeCash) {
        int l=start;
        int r=mid+1;
        int index =l;
        while ( l<= mid&&r<=end){
            if(a[l]>a[r]){
                mergeCash[index++]=a[r++];
            }else{
                mergeCash[index++]=a[l++];
            }
        }
        while(l<=mid){
            mergeCash[index++]= a[l++];
        }
        while(r<=end){
            mergeCash[index++]= a[r++];
        }

        for(int i = start; i<=end; i++){
            a[i]=mergeCash[i];
        }
    }

}
