/**
 *
 */
package heap;

import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.Queue;

/**
 * ��Ŀ��
 * <p>
 * Write a program to find the n-th ugly number.
 * <p>
 * Ugly numbers are positive numbers whose prime factors only include 2, 3, 5.
 * For example, 1, 2, 3, 4, 5, 6, 8, 9, 10, 12 is the sequence of the first 10 ugly numbers.
 * <p>
 * Note that 1 is typically treated as an ugly number.
 * <p>
 * ��⣺
 * �����
 * <p>
 * 1 * 2�� 2* 2�� 3* 2�� .....
 * <p>
 * 1* 3�� 2* 3�� 3*3��......
 * <p>
 * 1* 5�� 2 * 5�� 3 * 5�� .......
 * <p>
 * ����ugly number��������ugly number * 2, *3, *5�õ����������������У���һ��ugly numberΪ�������������е�ǰ��С��Ԫ�ء������ظ�Ԫ��ʱ��Ҫ�ƶ����ָ�롣
 *
 * @author K25553
 */
public class UglyNumberII {
    // version 2 O(nlogn) HashMap + Heap
    public int nthUglyNumber(int n) {
        Queue<Long> queue = new PriorityQueue<>( );
        HashSet<Long> set = new HashSet<>();
        Long [] dic = new Long[3];
        queue.add(1l);
        set.add(1l);
        for ( int i = 0; i < n; i++){
            Long crt = queue.poll();
            if(i==n-1){
                return crt.intValue();
            }
            if (!set.contains(crt*2)){
                queue.add(crt*2);
                set.add(crt*2);
            }
            if (!set.contains(crt*3)){
                queue.add(crt*3);
                set.add(crt*3);
            }
            if (!set.contains(crt*5)){
                queue.add(crt*5);
                set.add(crt*5);
            }
        }
        return -1;
    }
    // version 1: O(n) scan
    public int nthUglyNumber1(int n) {
        int[] ugly = new int[n];
        ugly[0] = 1;
        int i2 = 0, i3 = 0, i5 = 0;
        for (int i = 1; i < n; i++) {
            int current = Math.min(ugly[i2] * 2, Math.min(ugly[i3] * 3, ugly[i5] * 5));
            ugly[i] = current;
            if (current == ugly[i2] * 2)
                i2++;
            if (current == ugly[i3] * 3)
                i3++;
            if (current == ugly[i5] * 5)
                i5++;
        }
        return ugly[n - 1];
    }


    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub

    }

}
