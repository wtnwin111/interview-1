package heap;


import java.util.Comparator;
import java.util.PriorityQueue;

public class MaxTicketProfit {
/*	There are �n� ticket windows in the railway station. ith window has ai tickets available. Price of a ticket is equal to the number of tickets remaining in that window at that time. When �m� tickets have been sold, what�s the maximum amount of money the railway station can earn? example: n=2, m=4 in 2 window available tickets are : 2 , 5 from 2nd wicket sold 4 tickets so 5+4+3+2=14. n<=100000 & m<= a1 + a2 + a3 +... + an & ai<=100000.

			Algorithm I have used : heapify given tickets at each window.
			heapify the given array of tickets.
			add array[0] to answer for for every iteration upto m iterations.
			decrement array[0] by 1.
			again call heapify at array[0].
*/
    public int maxProfit(int[] tickets, int M){
        Comparator<Integer> comparator = new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                return o2 - o1;
            }
        };
        PriorityQueue<Integer> prices = new PriorityQueue<>(tickets.length, comparator);
        for(int i = 0; i < tickets.length; i++) prices.add(tickets[i]);
        int profit = 0;
        for(int i = 0; i < M && !prices.isEmpty(); i++){
            int maxPrice = prices.poll();
            profit += maxPrice;
            if(maxPrice - 1 > 0) prices.add(maxPrice - 1);
        }
        return profit;
    }

    public static void main(String[] args){
        MaxTicketProfit seller = new MaxTicketProfit();
        int[] tickets = new int[]{2,5};
        System.out.println(seller.maxProfit(tickets, 4));  //14
        System.out.println(seller.maxProfit(tickets, 9));  //18
    }
}