package heap;

import java.util.Arrays;
import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.Queue;

/**Write a program to find the nth super ugly number.

 Super ugly numbers are positive numbers whose all prime factors are in the given prime list primes of size k.
 For example, [1, 2, 4, 7, 8, 13, 14, 16, 19, 26, 28, 32] is the sequence of the first 12 super ugly numbers
 given primes = [2, 7, 13, 19] of size 4.

 Notice

 1 is a super ugly number for any given primes.
 The given numbers in primes are in ascending order.
 0 < k �� 100, 0 < n �� 10^6, 0 < primes[i] < 1000
 Have you met this question in a real interview? Yes
 Example
 Given n = 6, primes = [2, 7, 13, 19] return 13

 Tags
 * Created by K25553 on 10/19/2016.
 */
public class SuperUglyNumber {
    /**
     * @param n a positive integer
     * @param primes the given prime list
     * @return the nth super ugly number
     */
    public int nthSuperUglyNumber(int n, int[] primes) {
        int[] times = new int[primes.length];
        int[] uglys = new int[n];
        uglys[0] = 1;

        for (int i = 1; i < n; i++) {
            int min = Integer.MAX_VALUE;
            for (int j = 0; j < primes.length; j++) {
                min = Math.min(min, primes[j] * uglys[times[j]]);
            }
            uglys[i] = min;

            for (int j = 0; j < times.length; j++) {
                if (uglys[times[j]] * primes[j] == min) {
                    times[j]++;
                }
            }
        }
        return uglys[n - 1];
    }
    /**
     * @param n a positive integer
     * @param primes the given prime list
     * @return the nth super ugly number
     */
    public static int nthSuperUglyNumberMethodFromTianNan(int n, int[] primes) {
        if (n < 1 || primes == null || primes.length == 0)
            return 1;

        Arrays.sort(primes);
        Queue<Long> minHeap = new PriorityQueue<Long>(n);
        HashSet<Long> set = new HashSet<Long>();

        minHeap.add(1L);
        set.add(1L);

        for (int i = 0; i < n; i++) {
            long crt = minHeap.poll();
            if (i == n - 1) {
                return (int)crt;
            }
            for (int j : primes) {
                if ((!set.contains(crt * j))) {
                    minHeap.add(crt * j);
                    set.add(crt * j);
                }
            }
        }
        return -1;
    }

}
