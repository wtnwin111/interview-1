/**
 * 
 */
package string;

/**
 * @author Tiannan
 *
 */
public class LongestCommonSubstring {

	/**
	 * @param args
	 * Given two strings, find the longest common substring.

Return the length of it.

Example 

Given A="ABCD", B="CBCE", return 2.
string consist of chars, identified as 26 char array, hash the array,   
common substring, 2loop 2pinters, check all combo, 
counter records lcs len, 
each combo check lcs if char at each is common, 
move pointer by using pinter+(++counter)
	 */
	public static int  longestCommonSubstring(String a, String b) {
        int counter=0;
        for(int i=0; i<a.length();i++){
        	for (int j=0; j<a.length();j++){
        		int len=0;
        		while(i+len<a.length()&&j+len<b.length()&&a.charAt(i+len)==b.charAt(j+len)){
        			len++;
        			if(len>counter){
        				counter=len;
        			}
        		}
        	}
        }
        
        return counter;
    }
	public static void main(String[] args) {
	 System.out.println(longestCommonSubstring("ABCD",""));

	}

}
