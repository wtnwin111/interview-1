package string;



public class StringReversalWithRecursion {

	public String reverseString(String s) {
		if (s.isEmpty())
			return s;
// ��ÿ��ĵ�һ�����ַŵ���� �ٴ������ٴ�recursionֱ���ַ���Ϊ�վͷ���
		return reverseString(s.substring(1)) + s.charAt(0);
	}
	public String reverseString1(String s) {
		StringBuilder reversed = new StringBuilder();
		int j = s.length();
		for (int i = s.length() - 1; i >= 0; i--) {
		if (s.charAt(i) == ' ') {
		j = i;
		} else if (i == 0 || s.charAt(i - 1) == ' ') {
		if (reversed.length() != 0) {
		reversed.append(' ');
		}
		reversed.append(s.substring(i, j));
		}
		}
		return reversed.toString();

	}
	  public String reverseString3(String str){
	        String reverse=""; 
	        if(str.length() == 1){
	            return str;
	        } else {
	            reverse += str.charAt(str.length()-1)
	                    +reverseString(str.substring(0,str.length()-1));
	            return reverse;
	        }
	    }
	  
	  public char[] reverseString4(String str){
		  char[] rev= str.toCharArray();
		  int left=0, right= str.length()-1;
		  while (left<=right){
			  char temp= str.charAt(right);
			  rev[right]=str.charAt(left);
			  rev[left]=temp;
			  right--;
			  left++;
		  }return rev;
	  }
	public static void main(String[] args) {
		StringReversalWithRecursion test = new StringReversalWithRecursion();
		System.out.println(test.reverseString("hello world"));
		System.out.println(test.reverseString4("1 2 3 4 5 fg h g h"));
		/*Double expense = 323.567; 
		NumberFormat currency = NumberFormat.getCurrencyInstance(); 
		String expenseString = currency.format(expense);*/
/*		double x = 11.0;double y = 4.4;
				double answer = x / y;
		System.out.println( answer);*/
	}}