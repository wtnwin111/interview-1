/**
 * 
 */
package string;

/**
 * @author Tiannan
 *
 */
public class CompareStrings {
	public static boolean anagram3(String s, String t){
		if(s.length()<t.length()){
			return false;
		}
		if (t==""){
			return true;
		}
		int[]c = new int[128];
		char[] a= s.toCharArray();
		int num_unique_chars = 0;
		int num_completed_t = 0;
		for(char b: a){
			
			c[b]++;
		}
		for(int i=0; i<t.length();i++){
			int f= t.charAt(i);
			
			if (--c[f]<0){
				return false;
			}
			
		}
		
		return true;

	}
	public static void main(String arg[]){
		String[][] pairs = {{"apple", "papel"}, {"carrot", "tarroc"}, {"hello", "llloh"},{"asd","dsa"}};
		for (String[] pair : pairs) {
			String word1 = pair[0];
			String word2 = pair[1];

			boolean anagram2 = anagram3(word1, word2);

			System.out.println(word1 + ", " + word2 + ": " + anagram2);
			
		}
	}

}
