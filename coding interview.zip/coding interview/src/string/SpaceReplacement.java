package string;

/**
 * Write a method to replace all spaces in a string with %20. The string is given in a characters array, you can assume it has enough space for replacement and you are given the true length of the string.

 You code should also return the new length of the string after replacement.

 Notice

 If you are using Java or Python��please use characters array instead of string.

 Have you met this question in a real interview? Yes
 Example
 Given "Mr John Smith", length = 13.

 The string after replacement should be "Mr%20John%20Smith", you need to change the string in-place and return the new length 17.
 * Created by K25553 on 9/16/2016.
 */
public class SpaceReplacement {
    /**
     * @param string: An array of Char
     * @param length: The true length of the string
     * @return: The true length of new string
     */
    public int replaceBlank(char[] string, int length) {
        if(0==length) return 0;
        int num = 0;
        for(int i=0;i<length;i++){
            if(string[i] == ' ') num++;
        }

        int newLen = length + num*2;
        string[newLen] = 0;
        int j = 1;
        for(int i=length-1;i>=0;i--){
            if(string[i] != ' '){
                string[newLen - j] = string[i];
                j++;
            }
            else{
                string[newLen - j] = '0';
                j++;
                string[newLen - j] = '2';
                j++;
                string[newLen - j] = '%';
                j++;
            }
        }
        return newLen;
    }
}
