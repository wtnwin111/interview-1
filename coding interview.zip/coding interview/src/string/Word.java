/**
 * 
 */
package string;

/**
 * @author Tiannan
 *
 */
import java.util.Scanner;

public class Word {
 public static void main(String[] arg) {
  String[] words = {"abstract", "baby", "cat", "dog", "elephant", "fan", "gallow", "hail", "ice", "jack", "kill", "lamp", "moon", "nod", "orange", "person", "quest", "rust", "stain", "total", "unification", "violet", "weaver", "xenophone", "yatch", "zero"};
  Scanner scan = new Scanner(System.in);
  String s=null;
  do {
   s = scan.nextLine();
   int index = s.charAt(s.length()-1)-'a';
   int a='a';
   System.out.println(a);
   System.out.println(index);
   
   if(index>=0&&index<words.length){
	   System.out.println(words.length+"  as"+words[index]);
	   
   }
    
   else break;
  }
  while(s!="");
 }
}