package string;

import java.util.HashSet;
import java.util.Set;

public class UniqueCharacters {
	public static boolean isUniqueChars(String str){
		if (str.length()>256) return false;
		boolean[]char_set= new boolean[256];
		for(int i=0;i<str.length();i++){
			int val= str.charAt(i);
			if(char_set[val]){
				return false;
			}
			char_set[val]=true;
		}
		return true;
	}
	
	/**
	 * Extra Data Structure Solution
	 * unique --> Set
	 */
	public static boolean isUniqueChars2(String str){
		if (str == null) {
			return false;
		}
		
		Set<Character> set = new HashSet<Character>();
		char[] arr = str.toCharArray();
		
		for (int i = 0; i < str.length(); i++) {
			if(set.contains(arr[i])) {
				return false;
			} else {
				set.add(arr[i]);
			}
		}
		
		return true;
	}
	
	/**
	 * brute force solution
	 * No extra data structure and space but time complexity increase   
	 */
	public static boolean isUniqueChars3(String str) {
		if (str == null) {
			return false;
		}
		char[] arr = str.toCharArray();
		for (int i=0; i<arr.length; i++) {
			for (int j=i+1; j<arr.length; j++) {
				if (arr[i] == arr[j]) {
					return false;
				}
			}
		}
		return true;
	}
	
	public static void main(String[] args) {
		if(isUniqueChars("adsf")){
			System.out.println("this is truly unique");
		}
		else{System.out.println("this is not truly unique");}

	}
	

}
