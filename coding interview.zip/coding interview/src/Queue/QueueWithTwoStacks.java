package Queue;

import java.util.NoSuchElementException;
import java.util.Stack;

public class QueueWithTwoStacks<T> {
	private Stack<T> stack1, stack2;     // back of queue

	// front of queue

	// create an empty queue
	public QueueWithTwoStacks() {
		stack1 = new Stack<T>();
		stack2 = new Stack<T>();
	}

	// move all Ts from stack1 to stack2
	private void moveStack1ToStack2() {
		while (!stack1.isEmpty()) {
			stack2.push(stack1.pop());
		}
	}

	// is the queue empty?
	public boolean isEmpty() {
		return stack1.isEmpty() && stack2.isEmpty();
	}

	// return the number of Ts in the queue.
	public int size() {
		return stack1.size() + stack2.size();
	}

	// return the T least recently added to the queue.
	public T peek() {
		if (isEmpty()) {
			throw new NoSuchElementException("Queue underflow");
		}
		if (stack2.isEmpty()) {
			moveStack1ToStack2();
		}
		return stack2.peek();
	}

	// add the T to the queue
	public void enqueue(T a) {
		stack1.push(a);
	}

	// remove and return the T on the queue least recently added
	public T dequeue() {
		if (isEmpty()) {
			throw new NoSuchElementException("Queue underflow");
		}
		if (stack2.isEmpty()) {
			moveStack1ToStack2();
		}
		return stack2.pop();
	}

	// a test client
	public static void main(String[] args) {
		QueueWithTwoStacks<Integer> q = new QueueWithTwoStacks<Integer>();
		q.enqueue(10);
	}
}
