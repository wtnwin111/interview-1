/**
 *
 */
package Queue;

import java.util.Arrays;
import java.util.Stack;

/**
 * ������n���Ǹ�������ʾÿ��ֱ��ͼ�ĸ߶ȣ�ÿ��ֱ��ͼ�Ŀ���Ϊ1����ֱ��ͼ���ҵ����ľ��������
 * ����ֱ��ͼ��Ϊ1���߶�Ϊ[2,1,5,6,2,3]��
 *
 * �����������ͼ��Ӱ������ʾ������10��λ
 *
 * ����
 * ���� height = [2,1,5,6,2,3]������ 10
 *
 * @author Tiannan
 *
 */
public class LargestRectangleinHistogram {
	public int largestRectangleArea(int[] height) {
		if (height == null || height.length == 0) {
			return 0;
		}

		Stack<Integer> stack = new Stack<Integer>();
		int max = 0;
		for (int i = 0; i <= height.length; i++) {
			int curt = (i == height.length) ? -1 : height[i];
			while (!stack.isEmpty() && curt <= height[stack.peek()]) {
				int h = height[stack.pop()];
				int w = stack.isEmpty() ? i : i - stack.peek() - 1;
				max = Math.max(max, h * w);
			}
			stack.push(i);
		}

		return max;
	}

	/**
	 * @param height
	 *            : A list of integer
	 * @return: The area of largest rectangle in the histogram
	 */
	public int largestRectangleArea1(int[] height) {
		if (height == null || height.length == 0) {
			return 0;
		}
		Stack<Integer> st = new Stack<>();
		int max = 0, len = height.length;
		for (int i = 0; i < len; i++) {
			int current = height[i];
			while (!st.isEmpty() && current <= height[st.peek()]) {
				int index = st.pop();
				int h = height[index];
				int w;
				if (st.isEmpty()) {
					w = i;
				} else {
					w = i - st.peek() - 1;
				}
				max = Math.max(max, w * h);
			}
			st.push(i);
		}
		while (!st.isEmpty()) {
			int index = st.pop();
			int h = height[index];
			int w;
			if (st.isEmpty()) {
				w = len;
			} else {
				w = len - 1 - st.peek();
			}
			max = Math.max(max, w * h);
		}
		return max;
	}

	/**
	 * @param args
	 */
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String a = "AAUDIT_DSH_LINK.FINRA.ORG   ACATS_DSH_LINK.FINRA.ORG	CDIP_DSH_LINK.FINRA.ORG	COBRA_DSH_LINK.FINRA.ORG	COIC_DSH_LINK.FINRA.ORG	DATAMGR_DSH_LINK.FINRA.ORG	DSH1Q_LINK.FINRA.ORG	DSH2Q_DSH_LINK.FINRA.ORG	DSH2Q_LINK.FINRA.ORG	DSHI_DSH_LINK.FINRA.ORG	DSHT_DSH_LINK.FINRA.ORG	DSH_ACMS_CDC_LINK.FINRA.ORG	DSH_CCOWNER_CDC_LINK.FINRA.ORG	DSH_CHECK_LINK.FINRA.ORG	DSH_MATRICS_CDC_LINK.FINRA.ORG	DSH_STAR_ADMIN_CDC_LINK.FINRA.ORG	DSH_WEBCRD_CDC_LINK.FINRA.ORG	EET_DSH_LINK.FINRA.ORG	EFOCUS_DSH_LINK.FINRA.ORG	EMS_DSH_LINK.FINRA.ORG	EWS_DSH_LINK.FINRA.ORG	EXAM_DSH_LINK.FINRA.ORG	FCS_DSH_LINK.FINRA.ORG	FFCCS_DSH_LINK.FINRA.ORG	FOCUS_DSH_LINK.FINRA.ORG	FOGS_DSH_LINK.FINRA.ORG	FOPS_DSH_LINK.FINRA.ORG	FORM17AFLNG_DSH_LINK.FINRA.ORG	FORM407AFLNG_DSH_LINK.FINRA.ORG	FORMD_DSH_LINK.FINRA.ORG	FORM_CLRNG_DSH_LINK.FINRA.ORG	FPRFL_ADMIN_DSH_LINK.FINRA.ORG	FSF_DSH_LINK.FINRA.ORG	IFDF_DSH_LINK.FINRA.ORG	MATRICS_DSH_LINK.FINRA.ORG	MBDM_DSH_LINK.FINRA.ORG	MDF_DSH_LINK.FINRA.ORG	MDR_DSH_LINK.FINRA.ORG	MRDT_DSH_LINK.FINRA.ORG	NCS_DSH_LINK.FINRA.ORG	NEPSURV_DSH_LINK.FINRA.ORG	NMA_DSH_LINK.FINRA.ORG	OATS_DSH_LINK.FINRA.ORG	PROCTOR_DSH_LINK.FINRA.ORG	PSFIS_DSH_LINK.FINRA.ORG	PSHRIS_DSH_LINK.FINRA.ORG	PSTAF_DSH_LINK.FINRA.ORG	QC_DEV_LINK.FINRA.ORG	QC_PROD_LINK.FINRA.ORG	RAW_DSH_LINK.FINRA.ORG	REG_T_DSH_LINK.FINRA.ORG	SHORTS_DSH_LINK.FINRA.ORG	SHRED_DSH_LINK.FINRA.ORG	STAR_10MIN_DSH_LINK.FINRA.ORG	STAR_DSH_LINK.FINRA.ORG	STAR_STREAM_DSH_LINK.FINRA.ORG	SUBLOANS_DSH_LINK.FINRA.ORG	SURV_DSH_LINK.FINRA.ORG	WATCHLIST_DSH_LINK.FINRA.ORG	WEBCRD_DSH_LINK.FINRA.ORG";
		selectFromWhereString(a);
	}

	public static void addNewline(String a) {
		String[] aString = a.split("\\s+");
		// String[] aString = a.split(", ");
		Arrays.sort(aString);
		System.out.println(aString.length);

		int ct = 0;
		for (int i = 0; i < aString.length; i++) {

			System.out.print(aString[i] + ", ");
			i++;
			ct++;
		}
		System.out.println(ct);
	}

	public static void addPerenphsis(String a) {
		String[] aString = a.split("\\s+");
		// String[] aString = a.split(", ");
		Arrays.sort(aString);
		System.out.println(aString.length);

		int ct = 0;
		for (int i = 0; i < aString.length; i++) {
			String name = "\'" + aString[i] + "_BK\',";

			System.out.print(name);
			ct++;
		}
		System.out.println(ct);
	}

	public static void selectFromWhereString(String a) {
		String[] aString = a.split("\\s+");
		// String[] aString = a.split(", ");
		Arrays.sort(aString);
		System.out.println(aString.length);
		int ct = 0;
		for (int i = 0; i < aString.length; i++) {

				String sql = "SELECT  value FROM NLS_DATABASE_PARAMETERS@" + aString[i]
						+ " where PARAMETER in ('NLS_NCHAR_CHARACTERSET'); commit;" ;
				//+ "\';";

				System.out.println(sql);



			ct++;

		}
		System.out.println(ct);
	}

	public static void selectFromListSchemaTable(String a, String b1) {
		String[] aString = a.split("\\s+");
		System.out.println(aString.length);
		String[] bString = b1.split("\\s+");
		System.out.println(bString.length);
		int ct = 0;
		for (int i = 0; i < aString.length; i++) {
			String name = aString[i] + "." + bString[i];
			String d = "(select \'" + name + "\' AS DECRIPTION, op_ts from "
					+ name + ") union ";
			String c = "(select * from " + name + ") union ";
			System.out.println(c);
			ct++;
		}
		System.out.println(ct);
	}

}
