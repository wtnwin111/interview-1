/**
 *
 */
package Queue;

import java.util.Arrays;
import java.util.Stack;

/**
 * ������n���Ǹ�������ʾÿ��ֱ��ͼ�ĸ߶ȣ�ÿ��ֱ��ͼ�Ŀ���Ϊ1����ֱ��ͼ���ҵ����ľ��������
 * ����ֱ��ͼ��Ϊ1���߶�Ϊ[2,1,5,6,2,3]��
 *
 * �����������ͼ��Ӱ������ʾ������10��λ
 *
 * ����
 * ���� height = [2,1,5,6,2,3]������ 10
 *
 * @author Tiannan
 *
 */
public class LargestRectangleinHistogram {
	public int largestRectangleArea(int[] height) {
		if (height == null || height.length == 0) {
			return 0;
		}

		Stack<Integer> stack = new Stack<Integer>();
		int max = 0;
		for (int i = 0; i <= height.length; i++) {
			int curt = (i == height.length) ? -1 : height[i];
			while (!stack.isEmpty() && curt <= height[stack.peek()]) {
				int h = height[stack.pop()];
				int w = stack.isEmpty() ? i : i - stack.peek() - 1;
				max = Math.max(max, h * w);
			}
			stack.push(i);
		}

		return max;
	}

	/**
	 * @param height
	 *            : A list of integer
	 * @return: The area of largest rectangle in the histogram
	 */
	public int largestRectangleArea1(int[] height) {
		if (height == null || height.length == 0) {
			return 0;
		}
		Stack<Integer> st = new Stack<>();
		int max = 0, len = height.length;
		for (int i = 0; i < len; i++) {
			int current = height[i];
			while (!st.isEmpty() && current <= height[st.peek()]) {
				int index = st.pop();
				int h = height[index];
				int w;
				if (st.isEmpty()) {
					w = i;
				} else {
					w = i - st.peek() - 1;
				}
				max = Math.max(max, w * h);
			}
			st.push(i);
		}
		while (!st.isEmpty()) {
			int index = st.pop();
			int h = height[index];
			int w;
			if (st.isEmpty()) {
				w = len;
			} else {
				w = len - 1 - st.peek();
			}
			max = Math.max(max, w * h);
		}
		return max;
	}

	/**
	 * @param args
	 */
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String a = "AAUDIT_DSH_LINK.FINRA.ORG\tACATS_DSH_LINK.FINRA.ORG\tCDIP_DSH_LINK.FINRA.ORG\tCOBRA_DSH_LINK.FINRA.ORG\tCOIC_DSH_LINK.FINRA.ORG\tDATAMGR_DSH_LINK.FINRA.ORG\tDSH1Q_LINK.FINRA.ORG\tDSH2Q_DSH_LINK.FINRA.ORG\tDSH_ACMS_CDC_LINK.FINRA.ORG\tDSH_CCOWNER_CDC_LINK.FINRA.ORG\tDSH_MATRICS_CDC_LINK.FINRA.ORG\tDSH_STAR_ADMIN_CDC_LINK.FINRA.ORG\tDSH_WEBCRD_CDC_LINK.FINRA.ORG\tEFOCUS_DSH_LINK.FINRA.ORG\tEMS_DSH_LINK.FINRA.ORG\tEWS_DSH_LINK.FINRA.ORG\tEXAM_DSH_LINK.FINRA.ORG\tFCS_DSH_LINK.FINRA.ORG\tFFCCS_DSH_LINK.FINRA.ORG\tFOCUS_DSH_LINK.FINRA.ORG\tFOGS_DSH_LINK.FINRA.ORG\tFOPS_DSH_LINK.FINRA.ORG\tFORM17AFLNG_DSH_LINK.FINRA.ORG\tFORM407AFLNG_DSH_LINK.FINRA.ORG\tFORMD_DSH_LINK.FINRA.ORG\tFORM_CLRNG_DSH_LINK.FINRA.ORG\tFPRFL_ADMIN_DSH_LINK.FINRA.ORG\tFSF_DSH_LINK.FINRA.ORG\tIFDF_DSH_LINK.FINRA.ORG\tMATRICS_DSH_LINK.FINRA.ORG\tMBDM_DSH_LINK.FINRA.ORG\tMDR_DSH_LINK.FINRA.ORG\tMRDT_DSH_LINK.FINRA.ORG\tNCS_DSH_LINK.FINRA.ORG\tNMA_DSH_LINK.FINRA.ORG\tPROCTOR_DSH_LINK.FINRA.ORG\tPSFIS_DSH_LINK.FINRA.ORG\tPSHRIS_DSH_LINK.FINRA.ORG\tPSTAF_DSH_LINK.FINRA.ORG\tQC_PROD_LINK.FINRA.ORG\tRAW_DSH_LINK.FINRA.ORG\tSHRED_DSH_LINK.FINRA.ORG\tSTAR_10MIN_DSH_LINK.FINRA.ORG\tSTAR_DSH_LINK.FINRA.ORG\tSTAR_STREAM_DSH_LINK.FINRA.ORG\tSUBLOANS_DSH_LINK.FINRA.ORG\tWATCHLIST_DSH_LINK.FINRA.ORG\tWEBCRD_DSH_LINK.FINRA.ORG\n";
		selectFromWhereString(a);
	}

	public static void addNewline(String a) {
		String[] aString = a.split("\\s+");
		// String[] aString = a.split(", ");
		Arrays.sort(aString);
		System.out.println(aString.length);

		int ct = 0;
		for (int i = 0; i < aString.length; i++) {

			System.out.print(aString[i] + ", ");
			i++;
			ct++;
		}
		System.out.println(ct);
	}

	public static void addPerenphsis(String a) {
		String[] aString = a.split("\\s+");
		// String[] aString = a.split(", ");
		Arrays.sort(aString);
		System.out.println(aString.length);

		int ct = 0;
		for (int i = 0; i < aString.length; i++) {
			String name = "\'" + aString[i] + "\',";

			System.out.print(name);
			ct++;
		}
		System.out.println(ct);
	}

	public static void selectFromWhereString(String a) {
		String[] aString = a.split("\\s+");
				//a.split("\\s+");
		// String[] aString = a.split(", ");
		Arrays.sort(aString);
		System.out.println(aString.length);
		int ct = 0;
		for (int i = 0; i < aString.length; i++) {

				String sql = "SELECT  value FROM NLS_DATABASE_PARAMETERS@" + aString[i]
						+ " where PARAMETER in ('NLS_NCHAR_CHARACTERSET'); commit;" ;
				//+ "\';";

				System.out.println(sql);



			ct++;

		}
		System.out.println(ct);
	}

	public static void selectFromListSchemaTable(String a, String b1) {
		String[] aString = a.split("\\s+");
		System.out.println(aString.length);
		String[] bString = b1.split("\\s+");
		System.out.println(bString.length);
		int ct = 0;
		for (int i = 0; i < aString.length; i++) {
			String name = aString[i] + "." + bString[i];
			String d = "(select \'" + name + "\' AS DECRIPTION, op_ts from "
					+ name + ") union ";
			String c = "(select * from " + name + ") union ";
			System.out.println(c);
			ct++;
		}
		System.out.println(ct);
	}

}
