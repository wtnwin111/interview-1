/**
 *
 */
package Queue;

import java.util.Arrays;
import java.util.Stack;

/**
 * ������n���Ǹ�������ʾÿ��ֱ��ͼ�ĸ߶ȣ�ÿ��ֱ��ͼ�Ŀ���Ϊ1����ֱ��ͼ���ҵ����ľ��������
 * ����ֱ��ͼ��Ϊ1���߶�Ϊ[2,1,5,6,2,3]��
 *
 * �����������ͼ��Ӱ������ʾ������10��λ
 *
 * ����
 * ���� height = [2,1,5,6,2,3]������ 10
 *
 * @author Tiannan
 *
 */
public class LargestRectangleinHistogram {
	public int largestRectangleArea(int[] height) {
		if (height == null || height.length == 0) {
			return 0;
		}

		Stack<Integer> stack = new Stack<Integer>();
		int max = 0;
		for (int i = 0; i <= height.length; i++) {
			int curt = (i == height.length) ? -1 : height[i];
			while (!stack.isEmpty() && curt <= height[stack.peek()]) {
				int h = height[stack.pop()];
				int w = stack.isEmpty() ? i : i - stack.peek() - 1;
				max = Math.max(max, h * w);
			}
			stack.push(i);
		}

		return max;
	}
	/**
	 * @param height: A list of integer
	 * @return: The area of largest rectangle in the histogram
	 */
	public int largestRectangleArea1(int[] height) {
		if(height==null ||height.length==0){
			return 0;
		}
		Stack<Integer> st = new Stack<>();
		int max =0,len=height.length;
		for(int i=0; i<len;i++){
			int current = height[i];
			while(!st.isEmpty() && current<=height[st.peek()]){
				int index = st.pop();
				int  h = height[index];
				int w;
				if(st.isEmpty()){
					w = i;
				}
				else{
					w = i-st.peek()-1;
				}
				max=Math.max(max, w*h);
			}
			st.push(i);
		}
		while(!st.isEmpty() ){
			int index = st.pop();
			int  h = height[index];
			int w;
			if(st.isEmpty()){
				w = len;
			}
			else{
				w = len-1-st.peek();
			}
			max=Math.max(max, w*h);
		}
		return max;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String a = "ACM_USER_ROLES	ALERT_ALERT_ACTIONS	ALERT_DISPLAY	ALERT_STATUS	ALERT_TYPES	CASE_MANAGMENT_VERSIONS	CM_CONFIG	CONNECTIONS	DRILL_DOWN_QUERIES	DRIVERS	DYNAMIC_FIELDS	DYNAMIC_FIELD_TYPES	DYNAMIC_OBJECTS	DYNAMIC_OBJECT_VIEWS	DYNAMIC_PARAMETERS	DYNAMIC_PARAMETER_TYPES	DYNAMIC_TAGS	DYNAMIC_VIEWS	DYNAMIC_VIEW_FIELDS	E_AUDIT_EVENTS	FIELD_TYPES	GUI_ITEMS	GUI_ITEMS_TYPES	HF_ACTIONS_HISTORY	HF_DISPLAY	HIBERNATE_UNIQUE_KEY	ICONS	METHODS	NEP_BACKUP_ACM_USERS	NEP_BACKUP_ALERT_ALERT_ACTIONS	OWNER_TYPES	PLAN_TABLE	RESOLUTIONS	SIGNS	THRESHOLDS	THRESHOLDS_HISTORY	THRESHOLD_ALERT_TYPES	THRESHOLD_FIELDS	XSL_PROCEDURES	X_ACM_MD_ACTION_GROUP_MEMBERS	X_ACM_MD_ACTION_GUI_RELATIONS	X_ACM_MD_ADMIN_PERMISSIONS	X_ACM_MD_ALERTS_PERMISSIONS	X_ACM_MD_GUI_ITEMS_PERMISSIONS	X_ACM_MD_HIERARCHY_RELATIONS	X_ACM_MD_HIGHFOCUS_PERMISSIONS	X_ACM_MD_PERMISSION_ACTIONS	X_ACM_MD_REPORTS_PERMISSIONS	X_ACM_MD_SETTINGS_PERMISSIONS	X_ACM_MD_UI_COLUMN_DEFINITION	X_ACM_MD_UI_GRID_DEFINITION	X_ACM_RPT_INST_PROVIDER_ATTR	X_NEP_ACCOUNTSHIGHFOCUS	X_NEP_ACM_ACCESS_LOG	X_NEP_ACM_MD_ADMIN_PERMISSIONS	X_NEP_ACM_MD_BUSINESS_UNITS	X_NEP_ACM_MD_HIERARCHY	X_NEP_ACM_MD_ROLES	X_NEP_ACM_MD_RPT_METADATA	X_NEP_ACM_MD_RPT_PARAMETERS	X_NEP_ACM_MD_RPT_POLICIES	X_NEP_ACM_MD_RPT_TEMPLATE	X_NEP_ACM_MD_RPT_TYPES	X_NEP_ACM_MD_UDDT	X_NEP_ACM_RPT_AUDIT_TRAIL	X_NEP_ACM_RPT_INSTANCE	X_NEP_ACM_RPT_NOTES	X_NEP_ACM_RPT_PARAMETERS_DATA	X_NEP_ACM_RPT_RESOURCES	X_NEP_ACM_USERS	X_NEP_ACM_USER_ATTRIBUTES	X_NEP_ACM_USER_GROUP_MEMBERS	X_NEP_ACM_USER_ROLES	X_NEP_ALERT_ALERT_ACTIONS	X_NEP_ALERT_DISPLAY	X_NEP_ALERT_STATUS	X_NEP_ALERT_TYPES	X_NEP_CASE_MANAGMENT_VERSIONS	X_NEP_CM_CONFIG	X_NEP_CONNECTIONS	X_NEP_DRILL_DOWN_QUERIES	X_NEP_DRIVERS	X_NEP_DYNAMIC_FIELDS	X_NEP_DYNAMIC_FIELD_TYPES	X_NEP_DYNAMIC_OBJECTS	X_NEP_DYNAMIC_OBJECT_VIEWS	X_NEP_DYNAMIC_PARAMETERS	X_NEP_DYNAMIC_PARAMETER_TYPES	X_NEP_DYNAMIC_TAGS	X_NEP_DYNAMIC_VIEWS	X_NEP_DYNAMIC_VIEW_FIELDS	X_NEP_E_AUDIT_EVENTS	X_NEP_FIELD_TYPES	X_NEP_GUI_ITEMS	X_NEP_GUI_ITEMS_TYPES	X_NEP_HF_ACTIONS_HISTORY	X_NEP_HF_DISPLAY	X_NEP_HIBERNATE_UNIQUE_KEY	X_NEP_ICONS	X_NEP_METHODS	X_NEP_OWNER_TYPES	X_NEP_RESOLUTIONS	X_NEP_SIGNS	X_NEP_THRESHOLDS	X_NEP_THRESHOLDS_HISTORY	ALERTS	DTPROPERTIES	NEP_BACKUP_ALERTS	NEP_BACKUP_XML_SOURCE	X_NEP_ALERTS	X_NEP_DTPROPERTIES	X_NEP_XML_SOURCE	X_NEP_XML_SOURCE2	XML_SOURCE	ACCOUNTSHIGHFOCUS	ACM_ACCESS_LOG	ACM_MD_ACTION_GROUP_MEMBERS	ACM_MD_ACTION_GUI_RELATIONS	ACM_MD_ADMIN_PERMISSIONS	ACM_MD_ALERTS_PERMISSIONS	ACM_MD_ALERT_TYPE_GRP_MEMBERS	ACM_MD_BUNIT_ATTRIBUTE_VALUES	ACM_MD_BUSINESS_UNITS	ACM_MD_BUSINESS_UNIT_ATTRIBUTE	ACM_MD_EXTERNAL_PERMISSIONS	ACM_MD_GUI_ITEMS_PERMISSIONS	ACM_MD_HIERARCHY	ACM_MD_HIERARCHY_RELATIONS	ACM_MD_HIGHFOCUS_PERMISSIONS	ACM_MD_PERMISSION_ACTIONS	ACM_MD_REPORTS_PERMISSIONS	ACM_MD_REP_TYPE_GROUP_MEMBERS	ACM_MD_ROLES	ACM_MD_RPT_DISPLAY_CATEGORIES	ACM_MD_RPT_INST_STATUS_OPTIONS	ACM_MD_RPT_METADATA	ACM_MD_RPT_PARAMETERS	ACM_MD_RPT_POLICIES	ACM_MD_RPT_PROVIDER_ATTRIBUTES	ACM_MD_RPT_TEMPLATE	ACM_MD_RPT_TYPES	ACM_MD_SETTINGS_PERMISSIONS	ACM_MD_UDDT	ACM_MD_UI_COLUMN_DEFINITION	ACM_MD_UI_GRID_DEFINITION	ACM_RPT_AUDIT_TRAIL	ACM_RPT_INSTANCE	ACM_RPT_INST_PROVIDER_ATTR	ACM_RPT_NOTES	ACM_RPT_PARAMETERS_DATA	ACM_RPT_RESOURCES	ACM_USERS	ACM_USER_ATTRIBUTES	ACM_USER_GROUP_MEMBERS	X_NEP_THRESHOLD_ALERT_TYPES	X_NEP_THRESHOLD_FIELDS	X_NEP_XSL_PROCEDURES	TBL_CNT	RRD_RPTD_ROE_ODS_WK_20110930	RRD_RJCTN_ODS_WK_20110930";
		addPerenphsis(a);
	}

	public static void addNewline(String a) {
		String[] aString = a.split("\\s+");
		// String[] aString = a.split(", ");
		Arrays.sort(aString);
		System.out.println(aString.length);

		int ct = 0;
		for (int i = 0; i < aString.length; i++) {

			System.out.print(aString[i] + ", ");
			i++;
			ct++;
		}
		System.out.println(ct);
	}

	public static void addPerenphsis(String a) {
		String[] aString = a.split("\\s+");
		// String[] aString = a.split(", ");
		Arrays.sort(aString);
		System.out.println(aString.length);

		int ct = 0;
		for (int i = 0; i < aString.length; i++) {
			String name = "\'" + aString[i] + "_BK\',";

			System.out.print(name);
			ct++;
		}
		System.out.println(ct);
	}

	public static void selectFromWhereString(String a) {
		String[] aString = a.split("\\s+");
		// String[] aString = a.split(", ");
		Arrays.sort(aString);
		System.out.println(aString.length);
		String[] tablesStrings = { "FILING_COUNSEL", "FILING_DEAL",
				"MEMBERBOOK", "SECURITYFEE", "BASIC_INFO" };
		int ct = 0;
		for (int i = 0; i < aString.length; i++) {
			for (int j = 0; j < 5; j++) {
				String sql = "select * from CORPFIN." + tablesStrings[0]
						+ " where FILE_ID = \'" + aString[i] + "\';";

				System.out.println(sql);
				ct++;
			}
		}
		System.out.println(ct);
	}

	public static void selectFromListSchemaTable(String a, String b1) {
		String[] aString = a.split("\\s+");
		System.out.println(aString.length);
		String[] bString = b1.split("\\s+");
		System.out.println(bString.length);
		int ct = 0;
		for (int i = 0; i < aString.length; i++) {
			String name = aString[i] + "." + bString[i];
			String d = "(select \'" + name + "\' AS DECRIPTION, op_ts from "
					+ name + ") union ";
			String c = "(select * from " + name + ") union ";
			System.out.println(c);
			ct++;
		}
		System.out.println(ct);
	}

}
