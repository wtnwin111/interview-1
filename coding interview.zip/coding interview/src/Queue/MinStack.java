/**
 * 
 */
package Queue;

import java.util.Stack;

/**Implement a stack with min() function, 
 * which will return the smallest number in the stack.

It should support push, pop and min operation all in O(1) cost.
����
���²�����push(1)��pop()��push(2)��push(3)��min()�� push(1)��min() ���� 1��2��1
 * @author Tiannan
 *analysis: since only min() requires to peek min then use 2 stack implement;
 *The first one is the regular stack.
The second one only store minimum numbers
if a smaller number comes.
 *Push(x)
 1. stack.push(x)
 2. ���<=minStack����Сֵ����ô��minStack.push(x)
Pop()
 1. stack.pop()
 2. ���==minStack.top()����ô��minStack.pop()
 */
public class MinStack {
	private Stack<Integer> stack;
    private Stack<Integer> minStack;
    public MinStack() {
        stack = new Stack<Integer>();
        minStack = new Stack<Integer>();
    }

    public void push(int number) {
        stack.push(number);
        if (minStack.empty() == true)
            minStack.push(number);
        else
        if (Integer.parseInt(minStack.peek().toString()) >= number)
            minStack.push(number);
    }

    public int pop() {
        if (stack.peek().equals(minStack.peek()) ) 
            minStack.pop();
        return stack.pop();
    }

    public int min() {
        return minStack.peek();
    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
