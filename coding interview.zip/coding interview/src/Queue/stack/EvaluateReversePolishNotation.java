package Queue.stack;

import java.util.Stack;

/**Evaluate the value of an arithmetic expression in Reverse Polish Notation.

 Valid operators are +, -, *, /. Each operand may be an integer or another expression.

 Have you met this question in a real interview? Yes
 Example
 ["2", "1", "+", "3", "*"] -> ((2 + 1) * 3) -> 9
 ["4", "13", "5", "/", "+"] -> (4 + (13 / 5)) -> 6

 * Created by K25553 on 10/25/2016.
 * 1+2 infix
 * +12 prefix   polish notation
 * 12+ postfix rpn reverse polish notation
 *
 */
public class EvaluateReversePolishNotation {
    /**
     * @param tokens The Reverse Polish Notation
     * @return the value
     */
    public int evalRPN(String[] tokens) {
        if(tokens.length==0||tokens==null){
            return 0;
        }
        Stack<Integer> stack = new Stack<>();
        for (String token: tokens){
            if(!"/*-+".contains(token)){
                stack.push(Integer.valueOf(token));
                continue;
            }
            else{
                int a = stack.pop();
                int b = stack.pop();
                switch (token){
                    case "+": stack.push(a+b);
                        break;
                    case "-": stack.push(a-b);
                        break;
                    case "*": stack.push(a*b);
                        break;
                    case "/": stack.push(a/b);
                        break;
                }
            }
        }
        return stack.pop();
    }
}
