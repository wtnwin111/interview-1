/**
 *
 */
package Queue;

/**
 * @author Tiannan
 *
 */
public class BuildingOutline {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
