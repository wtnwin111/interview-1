import java.util.*;

/**
 * Support follow & unfollow, getFollowers, getFollowings.

 Have you met this question in a real interview? Yes
 Example
 follow(1, 3)
 getFollowers(1) // return [3]
 getFollowings(3) // return [1]
 follow(2, 3)
 getFollowings(3) // return [1,2]
 unfollow(1, 3)
 getFollowings(3) // return [2]
 * Created by K25553 on 12/2/2016.
 */
public class FriendshipService {
    HashMap<Integer,Set<Integer>> follower_followee;
    HashMap<Integer, Set<Integer>> followee_follower;
    public FriendshipService() {
        // initialize your data structure here.
        follower_followee = new HashMap<>();
        followee_follower = new HashMap<>();
    }

    // @param user_id an integer
    // return all followers and sort by user_id
    public List<Integer> getFollowers(int user_id) {
        // Write your code here
        if(followee_follower.containsKey(user_id)){
            return new ArrayList<Integer>(followee_follower.get(user_id));
        }
        return new ArrayList<Integer>();
    }

    // @param user_id an integer
    // return all followings and sort by user_id
    public List<Integer>  getFollowings(int user_id) {
        if(follower_followee.containsKey(user_id)){
            return new ArrayList<Integer>(follower_followee.get(user_id));
        }
        return new ArrayList<Integer>();
    }

    // @param from_user_id an integer
    // @param to_user_id an integer
    // from user_id follows to_user_id
    public void follow(int to_user_id , int from_user_id) {
        if(followee_follower.containsKey(to_user_id)){
             followee_follower.get(to_user_id).add(from_user_id);
        }else{
            TreeSet<Integer> list = new TreeSet<>();list.add(from_user_id);
            followee_follower.put(to_user_id,list);
        }
        if(follower_followee.containsKey(from_user_id)){
            follower_followee.get(from_user_id).add(to_user_id);
        }else{
            TreeSet<Integer> list = new TreeSet<>();list.add(to_user_id);
            follower_followee.put(from_user_id,list);
        }
    }

    // @param from_user_id an integer
    // @param to_user_id an integer
    // from user_id unfollows to_user_id
    public void unfollow(int to_user_id, int from_user_id ) {
        if(followee_follower.containsKey(to_user_id)){
            followee_follower.get(to_user_id).remove(from_user_id);
        }
        if(follower_followee.containsKey(from_user_id)){
            follower_followee.get(from_user_id).remove(to_user_id);
        }
    }
}
