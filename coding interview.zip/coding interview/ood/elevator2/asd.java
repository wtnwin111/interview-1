package elevator2;

import java.util.ArrayList;
import java.util.List;

public class Elevator{
    private int currentFloor;
    private int targetFloor;
    private int status;
    private static  Elevator instance = null;

    private Elevator() {
        this.currentFloor = 0;
        this.targetFloor = 0;
        this.status = 0;
    }

    public static Elevator getInstance() {
        if (instance == null) {
                    instance = new Elevator();
        }

        return instance;
    }

    public int getCurrentFloor() {
        return currentFloor;
    }


    public int getStatus() {
        return status;
    }

    public void moveToFloor(int targetFloor) {
        while (currentFloor < targetFloor) {
            moveUp();
        }
        while (currentFloor > targetFloor) {
            moveDown();
        }

        status = 0;
    }

    private void moveUp() {
        status = 1;
        currentFloor += 1;
    }

    private void moveDown() {
        status = -1;
        currentFloor -= 1;
    }


    public class RequestHandler {
        List<Request> requests;
        private static RequestHandler instance = null;

        public static RequestHandler getInstance() {
            if (instance == null) {
                instance = new RequestHandler();
            }

            return instance;
        }

        private RequestHandler() {
            requests = new ArrayList<>();
        }


        public void addRequest(Request req) {

            requests.add(req);

        }

        private Request getNextRequest() {
            int curentFloor = Elevator.getInstance().getCurrentFloor();
            int shortestdistance = Integer.MAX_VALUE;
            Request next = null;

            for (Request req: requests) {
                if (Math.abs(req.getTargetFloor() - Elevator.getInstance().getCurrentFloor()) < shortestdistance) {
                    next = req;
                }
            }

            return next;
        }

        public void processRequest() {

            while (true) {
                Request req = getNextRequest();
                if (req != null) {
                    while (Elevator.getInstance().getStatus() != 0);
                    Elevator.getInstance().moveToFloor(req.getTargetFloor());
                    requests.remove(req);
                }
            }

        }
    }


    public class Request {

        private int targetFloor;
        Request (int targetFloor) {
            this.targetFloor = targetFloor;
        }

        public int getTargetFloor() {
            return targetFloor;
        }
    }


    public class User{
        public void generateRequset(int targetFloor) {
            RequestHandler.getInstance().addRequest(new Request(targetFloor));
        }
    }
}



