import java.util.ArrayList;

/**Design a parking lot.

 see CC150 OO Design for details.
 1) n levels, each level has m rows of spots and each row has k spots.So each level has m x k spots.
 2) The parking lot can park motorcycles, cars and buses
 3) The parking lot has motorcycle spots, compact spots, and large spots
 4) Each row, motorcycle spots id is in range [0,k/4)(0 is included, k/4 is not included), compact spots id is in range [k/4,k/4*3) and large spots id is in range [k/4*3,k).
 5) A motorcycle can park in any spot
 6) A car park in single compact spot or large spot
 7) A bus can park in five large spots that are consecutive and within same row. it can not park in small spots

 Have you met this question in a real interview? Yes
 Example
 level=1, num_rows=1, spots_per_row=11
 parkVehicle("Motorcycle_1") // return true
 parkVehicle("Car_1") // return true
 parkVehicle("Car_2") // return true
 parkVehicle("Car_3") // return true
 parkVehicle("Car_4") // return true
 parkVehicle("Car_5") // return true
 parkVehicle("Bus_1") // return false
 unParkVehicle("Car_5")
 11/4 = min 2 middle 4 large 5
 parkVehicle("Bus_1") // return true
 * Created by K25553 on 11/28/2016.
 * Analysis:
 */
public class ParkingLots1 {
    // enum type for Vehicle
    enum VehicleSize {
        Motorcycle,
        Compact,
        Large,
    }

    abstract class Vehicle {
       protected VehicleSize type;
        protected int NumOfLots;
        protected ArrayList<ParkingSpot> parked = new ArrayList<>();
        public void parkIn(ParkingSpot crt){
            parked.add(crt);
        }
        public void cleanSpots(){
            for(int i =0; i<parked.size();i++ ){
                parked.get(i).emptyVehicle();
            }
            parked.clear();
        }
        //this need to be implement in subclass
        public abstract boolean canFitInSpot(ParkingSpot spot);

        public int getNumOfLots() {
            return NumOfLots;
        }
        // public abstract void print();
    }

    class Motorcycle extends Vehicle {
        public Motorcycle(){
            this.type= VehicleSize.Motorcycle;
            this.NumOfLots = 1;
        }

        @Override //compare only if size fitin
        public boolean canFitInSpot(ParkingSpot spot) {
            return true;
        }
    }

    class Car extends Vehicle {
        public Car(){
            this.type= VehicleSize.Compact;
            this.NumOfLots = 1;
        }

        @Override //compare only if size fitin
        public boolean canFitInSpot(ParkingSpot spot) {
            return spot.getType()!=VehicleSize.Motorcycle;
        }
    }

    class Bus extends Vehicle {
        public Bus(){
            this.type= VehicleSize.Large;
            this.NumOfLots = 5;
        }

        @Override //compare only if size fitin
        public boolean canFitInSpot(ParkingSpot spot) {
            return spot.getType()==VehicleSize.Large;
        }
    }
    class ParkingSpot{
        private Vehicle vehicle;
        private int row, col;
        private  Level level;
        private VehicleSize type;
        public ParkingSpot(Level level, int i, int j, VehicleSize type) {
            this.level = level;
            row = i;
            col = j;
            this.type = type;
        }
        /* lot is parked, car is fit in type of lots */
        public boolean parkCar(Vehicle car){
            if(this.vehicle!=null||!car.canFitInSpot(this)){
                return false;
            }
            this.vehicle = car;
            vehicle.parkIn(this);
            return true;
        }

        public void emptyVehicle() {
            this.vehicle=null;
            this.level.freeSpot();
        }

        public boolean isParkable(Vehicle vehicle) {
            return this.vehicle==null&&vehicle.canFitInSpot(this);
        }

        public VehicleSize getType() {
            return type;
        }
    }
    /* Represents a level in a parking garage
    *  abstraction level= [][]spots, spots: cartype, row, col, level, parked(vehicle)
    *  vi
    *  */
    class Level {
        private int floor, row, col;
        private ParkingSpot[][] spots;
        private int availableSpots = 0;
        public Level(int level_index, int num_rows, int spots_per_row) {
            floor= level_index;
            row = num_rows;
            col = spots_per_row;
            spots = new ParkingSpot[row][col];
            for(int i =0; i< row; i++){
                for (int j = 0; j<col; j++){
                    if(j<(col/4)){
                        spots[i][j]= new ParkingSpot(this,i, j, VehicleSize.Motorcycle);
                    } else if(j<((col/4)*3)){
                        spots[i][j]= new ParkingSpot(this,i, j, VehicleSize.Compact);
                    }else {
                        spots[i][j]= new ParkingSpot(this,i, j, VehicleSize.Large);
                    }
                }
            }
            availableSpots = num_rows *spots_per_row;
        }
        public boolean parkVehicle(Vehicle vehicle) {
            if(vehicle.getNumOfLots()> availableSpots ){
                return false;
            }
            int ct= vehicle.getNumOfLots();
            if(ct==1){
                for(int i =0; i< row; i++){
                    for (int j = 0; j<col; j++){
                        if(spots[i][j].parkCar(vehicle)){
                            availableSpots--;
                            return true;
                        }
                    }
                }

            }else {

                for(int i =0; i< row; i++){
                    int count =0;
                    for (int j = (col/4)*3-1; j<col; j++){
                        if(spots[i][j].isParkable(vehicle)){
                            count++;
                        }
                        if(count==ct){
                            boolean res = true;
                            for(int k=0; k<ct;k++){
                                res &= spots[i][j-k].parkCar(vehicle);
                            }
                            availableSpots -=ct;
                            return res;
                        }
                    }
                }

            }
            return false;
        }

        public void freeSpot() {
            availableSpots++;
        }
    }
    /*initialize 3d matrx:
    abstraction level= [][]spots, spots: cartype, row, col, level, parked(vehicle)
    * */

    public class ParkingLot {

        private Level[] levels;
        private int row, col;
        // @param n number of leves
        // @param num_rows  each level has num_rows rows of spots
        // @param spots_per_row each row has spots_per_row spots
        public ParkingLot(int n, int num_rows, int spots_per_row) {
            levels = new Level[n];
            for(int i=0; i <n; i++){
                levels[i]= new Level(i,num_rows,spots_per_row);
            }
        }



        // Park the vehicle in a spot (or multiple spots)
        // Return false if failed
        public boolean parkVehicle(Vehicle vehicle) {
            for(Level level : levels){
               if(level.parkVehicle(vehicle)){
                   return true;
               }
            }
            return false;
        }

        // unPark the vehicle
        public void unParkVehicle(Vehicle vehicle) {
            vehicle.cleanSpots();
        }
    }

    public static void main(String [] args){
        ParkingLots1 a = new ParkingLots1();
        ParkingLot pl = a.new ParkingLot(1,1,11);
        Motorcycle m = a.new Motorcycle();
        Car c1 = a.new Car();
        Car c2 = a.new Car();
        Car c3 = a.new Car();
        Car c4 = a.new Car();
        Car c5 = a.new Car();
        Bus b1 = a.new Bus();

        System.out.println(pl.parkVehicle(m));
        System.out.println(pl.parkVehicle(c1));
        System.out.println(pl.parkVehicle(c2));
        System.out.println(pl.parkVehicle(c3));
        System.out.println(pl.parkVehicle(c4));
        System.out.println(pl.parkVehicle(c5));
        System.out.println(pl.parkVehicle(b1));
        pl.unParkVehicle(c5);
        System.out.println(pl.parkVehicle(b1));

    }
}
