package WebCrawlerandTypeahead;

import java.util.*;

/**
 * Serialize and deserialize a trie (prefix tree, search on internet for more details).
 * <p>
 * You can specify your own serialization algorithm, the online judge only cares about whether you can successfully deserialize the output from your own serialize function.
 * <p>
 * Notice
 * <p>
 * You don't have to serialize like the test data, you can design your own format.
 * <p>
 * Have you met this question in a real interview? Yes
 * Example
 * str = serialize(old_trie)
 * >> str can be anything to represent a trie
 * new_trie = deserialize(str)
 * >> new_trie should have the same structure and values with old_trie
 * An example of test data: trie tree <a<b<e<>>c<>d<f<>>>>, denote the following structure:
 * <p>
 * root
 * /
 * a
 * / | \
 * b  c  d
 * /       \
 * e         f
 * Created by K25553 on 12/6/2016.
 */
public class TrieSerialization {
    public class TrieNode {
        public NavigableMap<Character, TrieNode> children;

        public TrieNode() {
            children = new TreeMap<Character, TrieNode>();
        }

        /**
         * This method will be invoked first, you should design your own algorithm
         * to serialize a trie which denote by a root node to a string which
         * can be easily deserialized by your own "deserialize" method later.
         */
        public String serialize(TrieNode root) {
            if (root == null) {
                return "";
            }
            StringBuffer sb = new StringBuffer();
            sb.append("<");
            Iterator iter = root.children.entrySet().iterator();
            while (iter.hasNext()) {
                Map.Entry entry = (Map.Entry) iter.next();
                Character key = (Character) entry.getKey();
                TrieNode child = (TrieNode) entry.getValue();
                sb.append(key);
                sb.append(serialize(child));
            }
            sb.append(">");
            return sb.toString();

        }


        /**
         * This method will be invoked second, the argument data is what exactly
         * you serialized at method "serialize", that means the data is not given by
         * system, it's given by your own serialize method. So the format of data is
         * designed by yourself, and deserialize it here as you serialize it in
         * "serialize" method.
         */
        public TrieNode deserialize(String data) {
            TrieNode root = new TrieNode();
            TrieNode crt = root;
            Stack<TrieNode> stack = new Stack<>();
            for (char i : data.toCharArray()) {
                switch (i) {
                    case '<':
                        stack.push(crt);
                        break;
                    case '>':
                        stack.pop();
                        break;
                    default:
                        crt = new TrieNode();
                        stack.peek().children.put(i, crt);
                }
            }
            return root;
        }
    }
}
