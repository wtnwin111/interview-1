package WebCrawlerandTypeahead;

import java.util.HashMap;

/**Implement a trie with insert, search, and startsWith methods.

 Notice

 You may assume that all inputs are consist of lowercase letters a-z.

 Have you met this question in a real interview? Yes
 Example
 insert("lintcode")
 search("code")
 >>> false
 startsWith("lint")
 >>> true
 startsWith("linterror")
 >>> false
 insert("linterror")
 search("lintcode)
 >>> true
 startsWith("linterror")
 >>> true
 * Created by K25553 on 12/6/2016.
 */
public class ImplementTrie {
    class TrieNode {
        boolean hasWord;
        char value;
        HashMap<Character,TrieNode> children = new HashMap<>();;
        // Initialize your data structure here.
        public TrieNode() {

        }
    }
    public class Trie {
        private TrieNode root;

        public Trie() {
            root = new TrieNode();
        }

        // Inserts a word into the trie.
        public void insert(String word) {
            char[] insert = word.toCharArray();
            TrieNode crt = this.root;
            for( char i : insert){
                if(crt.children.containsKey(i)){
                    crt= crt.children.get(i);
                }else{
                    crt.children.put(i, new TrieNode());
                    crt = crt.children.get(i);
                    crt.value=i;
                }
            }
            crt.hasWord= true;

        }

        // Returns if the word is in the trie.
        public boolean search(String word) {
            char[] chars = word.toCharArray();
            TrieNode crt = root;
            for (char i : chars){
                if(crt.children.containsKey(i)){
                    crt = crt.children.get(i);
                }else{
                    return false;
                }
            }
            return  crt.hasWord==true;
        }

        // Returns if there is any word in the trie
        // that starts with the given prefix.
        public boolean startsWith(String prefix) {
            char[] chars = prefix.toCharArray();
            TrieNode crt = root;
            for (char i : chars){
                if(crt.children.containsKey(i)){
                    crt = crt.children.get(i);
                }else{
                    return false;
                }
            }
            return  true;
        }
    }
}
