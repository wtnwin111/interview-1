package WebCrawlerandTypeahead;

import java.util.ArrayList;
import java.util.List;
import java.util.NavigableMap;
import java.util.TreeMap;

/**Build tries from a list of pairs. Save top 10 for each node.
 * Created by K25553 on 12/6/2016.
 */
public class TrieService {
    public class TrieNode {
             public NavigableMap<Character, TrieNode> children;
             public List<Integer> top10;
             public TrieNode() {
                     children = new TreeMap<Character, TrieNode>();
                     top10 = new ArrayList<Integer>();
                 }
         }
    private TrieNode root = null;

    public TrieService() {
        root = new TrieNode();
    }

    public TrieNode getRoot() {
        // Return root of trie root, and
        // lintcode will print the tree struct.
        return root;
    }

    // @param word a string
    // @param frequency an integer
    public void insert(String word, int frequency) {
        if(word==null||word.length()==0){
            return;
        }
        TrieNode crt = this.root;
        for(char i :word.toCharArray()){
            if(crt.children.containsKey(i)){
                crt= crt.children.get(i);
                updateList(frequency,crt );
            }else{
                TrieNode temp= new TrieNode();
                updateList( frequency,temp );
                crt.children.put(i,temp);
                crt=temp;
            }
        }
    }

    private void updateList(int frequency, TrieNode crt) {
        if(crt.top10.isEmpty()){
            crt.top10.add(frequency);
        }else {
            List<Integer> list =crt.top10;
            crt.top10.add(frequency);
            for(int i=list.size()-2; i>-1; i--){
                if(list.get(i)<list.get(i+1)){
                   int a = list.get(i);
                    int b = list.get(i+1);
                    list.set(i,b);
                    list.set(i+1,a);
                }else{
                    break;
                }
            }
            if(list.size()>10){
                list.remove(list.size()-1);
            }
        }
    }
}
