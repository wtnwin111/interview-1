package epic;

/*
 * There is a security keypad at the entrance of a building. It has 9 
 * numbers 1 - 9 in a 3x3 matrix format
 * 1 2 3 
 * 4 5 6 
 * 7 8 9 
 * The security has decided to allow one digit error for a person but 
 * that digit should be horizontal or vertical. Example: for 5 the user 
 * is allowed to enter 2, 4, 6, 8 or for 4 the user is allowed to 
 * enter 1, 5, 7. IF the security codeto enter is 1478 and if the user 
 * enters 1178 he should be allowed. Write a function to take security 
 * code from the user and print out if he should be allowed or not.
 */

public class securityKeypad{
	public static void main(String[] args){
		check("1478","1178");
	}

	public static void check(String code, String input){
		int count = 0;
		char error = '0';
		char right = '0';
		if(code.length()!=input.length()) {System.out.println("Fail!");return;}
		for(int i=0;i<code.length();i++){
			if(code.charAt(i) != input.charAt(i)){
				int wrong = Character.getNumericValue(input.charAt(i));
				int cool = Character.getNumericValue(code.charAt(i));
				if(Math.abs(wrong-cool)==3)
				 continue;
				if(cool %3 ==1&& wrong==cool+1)
					continue;
				if(cool %3 ==0&& wrong==cool-1)
					continue;
				if(cool %3 ==2&& Math.abs(wrong-cool)==1)
					continue;
				count++;
				
			}
		}
		if(count>1) {System.out.println("Fail!");return;}
		
	}
}