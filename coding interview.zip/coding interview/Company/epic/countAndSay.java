package epic;

import java.util.*;
/*
 * First,let user input a number, say 1. Then, the function will 
 * generate the next 10 numbers which satisfy this condition: 
 * 1,11,21,1211,111221,312211... 
 * explanation: first number 1, second number is one 1, so 11. 
 * Third number is two1(previous number), so 21. next number one 
 * 2 one 1, so 1211 and so on...
 */

public class countAndSay{

	public static void main(String[] args){
		count("2");count(10);
	}

	public static void count(String number){
		String num = String.valueOf(number);
		List<String> res = new ArrayList<String>();
		res.add(num);
		String currs = "";
		char curr = num.charAt(0);
		for(int k=0;k<9;k++){
			curr = num.charAt(0);
			int count = 1;
			for(int i=1;i<num.length();i++){
				if(num.charAt(i)==curr){
					count++;
				}else{
					currs = currs+count+curr;
					curr = num.charAt(i);
					count = 1;
				}
			}
			currs = currs+count+curr;
			res.add(currs);
			num = currs;
			currs = "";
		}
		System.out.println(res);
	}
	public static void count(int n) {
		if (n <= 0)
			System.out.println(-1);

		String result = "2";
		int i = 1;

		while (i < n) {
			StringBuilder sb = new StringBuilder();
			int count = 1;
			for (int j = 1; j < result.length(); j++) {
				if (result.charAt(j) == result.charAt(j - 1)) {
					count++;
				} else {
					sb.append(count);
					sb.append(result.charAt(j - 1));
					count = 1;
				}
			}

			sb.append(count);
			sb.append(result.charAt(result.length() - 1));
			result = sb.toString();
			i++;
		}

		System.out.println(result);
	}
}