/**
 * 
 */
package google;

/** �����ַ�����ͬ���ַ���,����ͬ���ַ��������ڡ�����
AABBCC �����ABACBC

Given a string and a positive integer d. Some characters may be repeated in the given string. Rearrange characters of the given string such that the same characters become d distance away from each other. Note that there can be many possible rearrangements, the output should be one of the possible rearrangements. If no such arrangement is possible, that should also be reported.
Expected time complexity is O(n) where n is length of input string.

Examples:
Input:  "abb", d = 2
Output: "bab"

Input:  "aacbbc", d = 3
Output: "abcabc"

Input: "geeksforgeeks", d = 3
Output: egkegkesfesor

Input:  "aaa",  d = 2
Output: Cannot be rearranged
 * @author K25553
 *��Ƶsort�������Ƶ��a=5, b=4, c=3,��ô������Ƶa��Ȼ����swap����ȷλ��,b=4,a=4,c=3��Ȼ���ٷ�b��Ȼ��swap (b,a) ���a=4,b=3,c=3������������heapifyһ����
 *reference RearrangeDuplicateCharsdDistanceAway
 *abd ab ab ac
 *not abcd ab a a 
 */


import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;

/**
 * http://www.geeksforgeeks.org/rearrange-a-string-so-that-all-same-characters-become-at-least-d-distance-away/
 * 
 */
public class RearrangeDuplicateCharsdDistanceAway {
	public static String rearrange(String str, int k) {
		 final Map<Character, Integer> map = new HashMap<>();
		char[] s = str.toCharArray();
		int n = s.length;
		for(int i=0; i<n; i++) {
			Integer cnt = map.get(s[i]);
			if(cnt == null) cnt = 0;
			map.put(s[i], cnt+1);
		}
		Queue<Character> queue = new PriorityQueue<>(map.size(), new Comparator<Character>(){
			public int compare(Character c1, Character c2) {
				return map.get(c2) - map.get(c1);
			}
		});
		queue.addAll(map.keySet());
		Arrays.fill(s, '\0');
		for(int i=0; i<map.size(); i++) {
			int p = i;
			while(s[p] != '\0') p++;
			char c = queue.poll();
			int cnt = map.get(c);
			for(int j=0; j<cnt; j++) {
				if(p >= n) return "Cannot be rearranged";
				s[p] = c;
				p += k;
			}
		}
		return new String(s);
	}

    public static void main(String args[]){
        
        
    }
    
}

