/**
 * 
 */
package Amazon1;

import java.util.Arrays;

/**
 * @author Tiannan
 *
 */
public class SortNinScopeNsquare {
	public static int [] search(int []a, int n ){
	    int [] sort= new int[n*n]; 
	  
	    for(int i=0; i<n; i++){
	        sort[a[i]]++;
	    }
	    int j=0;
	    for(int i=0; i<n*n;i++){
	      while(sort[i]>0){
	    	  a[j++]= i;
	    	  sort[i]--;
	      }
	    }	    
	    return a;	    
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print(Arrays.toString(search(new int [] {1,1,3,24,0},5)));
	}

}
