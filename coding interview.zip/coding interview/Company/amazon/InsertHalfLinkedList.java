/**
 * 
 */
package amazon;

import java.util.Scanner;

import list.ListNode;


/**
 * ��һ��LinkedList, �Ѻ���reverse 1,2,3,4,5,6 -> 1,2,3,6,5,4.

Challenge 

Reverse it in-place and in one-pass

 * @author Tiannan
 *use dummy node to record the head
 *use head to 
 */
public class InsertHalfLinkedList {
	
	private static class ListNode {
		public  int val;
		public  ListNode next;
		public  ListNode(int val) {
	        this.val = val;
	      this.next = null;
	   }}
	
	public static void insertHalf(ListNode head1) {
		 ListNode head=head1;
		 if (head== null || head.next == null) {
	            return;
	        }
		 	
	        ListNode fast, slow, pre = null;
	        fast = head.next;
	        slow = head;
	        
	        while (fast != null && fast.next != null) {  
	            pre=slow;
	        	fast = fast.next.next;
	            slow = slow.next;
	        
	        } 
	        ListNode insert, end;
	        if (fast==null){
	        	//odd
	        	insert=slow;
	        	//end
	        	pre.next=null;
	        	
	        }else{
	        	insert=slow.next;
	        	slow.next=null;
	        }
	        
	       
	     	while(head!=null){
	     		ListNode next1= head.next;
	     		ListNode next2= insert.next;
	     		head.next=insert;
	     		insert.next=next1;
	     		head=next1;
	     		insert=next2;
	     	}
	     	
	 }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int size= sc.nextInt(); 
		ListNode head= new ListNode(sc.nextInt());
		ListNode dummy= head;
		for(int i=1; i<size;i++){
			int temp = sc.nextInt();
			dummy.next=new ListNode( temp);
			dummy=dummy.next;
		}
			 
			
		 dummy = head;
		insertHalf( dummy);
		do{
			System.out.println(dummy.val );
			dummy=dummy.next;
		} while(dummy !=null);
		
//		ListNode head = new ListNode(1);
//		ListNode dummy = head;
//
//		for(int i=2;i<10;i++){
//			dummy.next= new ListNode(i);
//			dummy=dummy.next;
//			
//		}

//		
//		dummy = head;
//		 insertHalf( dummy);
//		do{
//			System.out.print(dummy.val+"->");
//			dummy=dummy.next;
//		} while(dummy !=null);
	}

}
