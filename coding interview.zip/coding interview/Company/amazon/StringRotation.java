/**
 * 
 */
package amazon;

/**amazon azonam is true.
 * @author Tiannan
 *
 */
public class StringRotation {
	public static boolean isRotated(String s1, String s2) {
		if (s1.length()!=s2.length())
			return false;
		int len = s1.length();

		// double String "s2";
		s2 = s2+s2;
		for (int i=0;i<len;i++) {
			if (s2.substring(i,i+len).equals(s1))
				return true;
		}

		return false;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
