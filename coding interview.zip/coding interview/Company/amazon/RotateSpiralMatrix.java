package amazon;

/*
 * Given aNXN matrix, starting from the upper right corner of the 
 * matrix start printingvalues in a counter-clockwise fashion. 
 * E.g.: Consider N = 4 
 * Matrix= {
 * 			a, b, c, d, 
 * 			e, f, g, h, 
 * 			i, j, k, l, 
 * 			m, n, o, p} 
 * Your function should output: dcbaeimnoplhgfjk
 */
 
 public class RotateSpiralMatrix{
 	
 	public static void main(String[] args){
 		char[][] matrix = {
			{'a', 'b', 'c', 'd'},
		    {'e', 'f', 'g', 'h'}, 
		    {'i', 'j', 'k', 'l'}, 
		    {'m', 'n', 'o', 'p'}
		};
		spiral(matrix);
		
		int[][] a = new int[][] {
				 { 1,2,3,4 },
				 { 5,6,7,8 },
				 { 9,0,1,2 },
				 { 3,4,5,6 }
				
				};
			for(int i=0;i<a.length;i++){
				for(int j=0;j<a[0].length;j++){
					System.out.print(a[i][j]+",");
				}
				System.out.println();
			}
			System.out.println();
			int[][]b= shift(a);
			System.out.println(b.length);
			for(int i=0;i<b.length;i++){
				for(int j=0;j<b[0].length;j++){
					System.out.print(b[i][j]+",");
				}
				System.out.println();
			}
 	}
 	public static int[][] shift(int[][] matrix) {
        int x = 0;
       int y = 0;
        int m = matrix.length;
        int n = matrix[0].length;

        while(m > 0 && n > 0) {
            int tmp = matrix[x+1][y];
            if(m==1 || n == 1)
                break;
            for(int i = 0 ; i < n - 1; i++) {
                int t = tmp;
                tmp = matrix[x][y];
                matrix[x][y] = t;
                y++;
            }
            for(int i = 0 ; i < m - 1; i++) {
                int t = tmp;
                tmp = matrix[x][y];
               matrix[x][y] = t;    
                x++;
            }
            for(int i = 0 ; i < n - 1; i++) {
                int t = tmp;
                tmp = matrix[x][y];
                matrix[x][y] = t;
               y--;
            }
            for(int i = 0 ; i < m - 1; i++) {
                int t = tmp;
                tmp = matrix[x][y];
                matrix[x][y] = t;
                x--;
            }
            x++;
            y++;
            m-=2;
            n-=2;
        }
       return matrix;
   }
 	public static void spiral(char matrix [][] ){
 		//easy, do not make silly mistake
 		int row = matrix.length;
 		int col = matrix[0].length;
 		int x = 0, y=col;
 		StringBuffer sb = new StringBuffer();
 		while(true){
 			for(int i=0;i<col;i++){
 				sb.append(matrix[x][--y]);
 			}
 			row--;
 			if(row==0) break;
 			for(int i=0;i<row;i++){
 				sb.append(matrix[++x][y]);
 			}
 			col--;
 			if(col==0) break;
 			for(int i=0;i<col;i++){
 				sb.append(matrix[x][++y]);
 			}
 			row--;
 			if(row==0)break;
 			for(int i=0;i<row;i++){
 				sb.append(matrix[--x][y]);
 			}
 			col--;
 			if(col==0) break;
 		}
 		System.out.println(sb.toString());
 	}
 	
 	
}