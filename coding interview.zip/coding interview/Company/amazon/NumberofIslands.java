/**
 * 
 */
package amazon;

import java.util.ArrayList;
import java.util.Scanner;

/**Given a boolean 2D matrix, find the number of islands.

Have you met this question in a real interview? Yes
Example
Given graph:

[
  [1, 1, 0, 0, 0],
  [0, 1, 0, 0, 1],
  [0, 0, 0, 1, 1],
  [0, 0, 0, 0, 0],
  [0, 0, 0, 0, 1]
]
return 3.
 * @author Tiannan
 *
 */
public class NumberofIslands {

	public static int numIslands(int[][] grid) {
		if(grid.length == 0)
			return 0;
		int row = grid.length;
		int col = grid[0].length;
		int count = 0;
		boolean[][] visited = new boolean[row][col];
		for(int i = 0; i < row; i++) {
			for(int j = 0; j < col; j++) {
				if(grid[i][j] == 1 && !visited[i][j]) {
					count++;
					mark(i, j, grid, visited);
				}
			}
		}
		return count;  
	}

	public static void mark(int i, int j, int[][] grid, boolean[][] visited) {
		if(i < 0 || j < 0 || i >= grid.length || j >= grid[0].length|| visited[i][j])
			return;
		if(grid[i][j] == 1) {
			visited[i][j] = true;
			mark(i+1, j, grid, visited);
			mark(i-1, j, grid, visited);
			mark(i, j+1, grid, visited);
			mark(i, j-1, grid, visited);
		}
	}
	static int[] dx = {1, 0, 0, -1};
	static int[] dy = {0, 1, -1, 0};
	private int n, m;

	private void removeIsland(char[][] grid, int x, int y) {
		grid[x][y] = '0';
		for (int i = 0; i < 4; i++) {
			int nextX = x + dx[i];
			int nextY = y + dy[i];
			if (nextX >= 0 && nextX < n && nextY >= 0 && nextY < m) {
				if (grid[nextX][nextY] == '1') {
					removeIsland(grid, nextX, nextY);
				}
			}
		}
	}

	public int numIslands(char[][] grid) {
		n = grid.length;
		if (n == 0) {
			return 0;
		}

		m = grid[0].length;
		if (m == 0) {
			return 0;
		}

		int count = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (grid[i][j] == '1') {
					removeIsland(grid, i, j);
					count++;
				}
			}
		}

		return count;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int line = input.nextInt();
		ArrayList<Integer> temp= new ArrayList<Integer>();

		while(input.hasNextInt()) {
			int a = input.nextInt();
			temp.add(a);
			System.out.println(a);
		}
		input.close();


		int count=0;
		int [][]matrix= new int[line][temp.size()/line];
		for(int i=0;i<matrix.length;i++){
			for(int j=0;j<matrix[0].length;j++){
				matrix[i][j]=temp.get(count++);
				System.out.print(matrix[i][j]+" ");
			}
			System.out.println();
		}
		System.out.println(numIslands(matrix));

		//		int a[][]= new int[][]{
		//				{1,1,1,1,0},
		//				{1,1,0,1,0},
		//				{1,1,0,0,0},
		//				{0,0,0,0,0}
		//		};
		//		int b[][]= new int[][]{
		//				{1,1,1,0,0},
		//				{1,1,0,1,0},
		//				{1,1,0,0,0},
		//				{0,0,1,0,0}
		//		};
		//		System.out.println(numIslands(a));
		//		System.out.println(numIslands(b));
	}

}
