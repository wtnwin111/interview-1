/**
 * 
 */
package amazon;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Tiannan
 *
 */
public class Anagrams {

	/**
	 * @param args
	 * Given ["lint", "intl", "inlt", "code"], return ["lint", "inlt", "intl"].

Given ["ab", "ba", "cd", "dc", "e"], return ["ab", "ba", "cd", "dc"].
Note:All inputs will be in lower-case
all strings, 
each string identifies a array of 26 letters, 
anagrams calculated by the hashcode, 
store each anagrams in hashmap,
input hashmap to the arraylist (only values >2). 
	 */
	public static int GetHashCode(int[] count){
		int b=12345;
		int c=234567;
		int res=0;
		for(int a:count){
			res=res*b+a;
			b=c*b;
		}
		return res;
	}
	public static List<String> anagrams(String[] strs) {
		ArrayList<String> result = new ArrayList<String>();
		HashMap<Integer, ArrayList<String>>m= new HashMap<Integer, ArrayList<String>>();
		for (String s:strs){
			int[] count = new int[26];
			for(int i=0;i<s.length();i++){
				count[s.charAt(i)-'a']++;	
			}
			int hash= GetHashCode(count);
			if(!m.containsKey(hash)){
				m.put(hash, new ArrayList<String>());			
			}
			m.get(hash).add(s);

		}
		for(ArrayList<String> s1: m.values()){
			if(s1.size()>1)
				result.addAll(s1);
		}
		return result;

	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a[]= {"ab", "ba", "cd", "dc", "e"};
		System.out.println(anagrams(a));

	}

}
