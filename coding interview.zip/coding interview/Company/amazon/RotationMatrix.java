/**
 * 
 */
package amazon;

/**
 * @author Tiannan
 *
 */
public class RotationMatrix {
	static int [][] rotateMatrix(int[][]a){
		int [][]b= new int [a[0].length][a.length];
		int col=a.length;int  row=a[0].length;
		for(int i=0;i<a.length;i++){
			for(int j=0;j<a[0].length;j++){
				//b[j][col-1-i]=a[i][j];
				b[row-1-j][i]=a[i][j];
			}
		}
		return b;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] a = new int[][] {
			 { 1,2,3,4 },
			 { 5,6,7,8 },
			 { 9,0,1,2 },
			 { 3,4,5,6 },
			 { 6,7,8,9 }
			};
		for(int i=0;i<a.length;i++){
			for(int j=0;j<a[0].length;j++){
				System.out.print(a[i][j]+",");
			}
			System.out.println();
		}
		System.out.println();
		int[][]b= rotateMatrix(a);
		System.out.println(b.length);
		for(int i=0;i<b.length;i++){
			for(int j=0;j<b[0].length;j++){
				System.out.print(b[i][j]+",");
			}
			System.out.println();
		}
		
	}

}
