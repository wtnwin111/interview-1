/**
 * 
 */
package amazon.onsite;

import list.ListNode;

/**
 * @author Tiannan
 *
 */
public class NthlastofLinkedList {
	public static ListNode findknode(ListNode head,int k){
		int len=0;
		ListNode temp=head;
		while(temp!=null){
			temp=temp.next;
			len++;
		}
		if(len<k){
			return null;
		}
		
		for (int i=0;i<len-k+1;i++){
			temp=temp.next;
		}
		return temp;
	}
	public static ListNode findthelastknode(ListNode head,int k){
		ListNode first = head;
		ListNode second= head;
		int count=0;
		while(count<k){
			if(first==null){
				return null;
			}
			first= head.next;
		
			count++;
		}
		
		while(first!=null){
			first=first.next;
			second=second.next;
		}
		return second;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
