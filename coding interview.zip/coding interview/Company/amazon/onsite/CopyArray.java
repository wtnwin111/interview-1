/**
 * 
 */
package amazon.onsite;

import java.util.Arrays;

/**
 * @author Tiannan
 *
 */
public class CopyArray {
	public static int[]copy (int [] a, int [] b, int start, int end, int i){
		if(end-start+1>b.length){
			return b; 
		}
		if(start>end){
			return b;
		
		}
		b[i]=a[start];
		return copy(a, b,start+1, end, i+1);
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a []= new int []{
				1,2,3,4,5,6,7,8,9
		};
		int b []= new int [9];
		System.out.println(Arrays.toString(copy ( a,  b, 0, 8, 0)));
	}

}
