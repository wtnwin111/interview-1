/**
 * 
 */
package amazon.onsite;

import java.util.Arrays;
import java.util.HashMap;

/**
 * @author Tiannan
 *
 */
public class TwoSum {
	public static int[] twotarget(int[] nums, int target){
		if(nums==null&&nums.length<2){
			return null;
		}
		HashMap<Integer,Integer> hm= new HashMap<Integer, Integer>();
		for (int i=0;i<nums.length;i++ ){
			
			if(hm.containsKey(target-nums[i])){
				int index1=i+1;
				int index2=hm.get(target-nums[i]);
				if(index1==index2)continue;
				return new int[]{ index2, index1};
			}
			hm.put(nums[i], i+1);
		}
			return new int[2];
		
	}
	
	public int[] twoSum_pointer(int[] numbers, int target) {
    	if(numbers == null || numbers.length < 2) {
    		return null;
    	}
        Arrays.sort(numbers);
        int left = 0;
        int right = numbers.length - 1;
        int[] rst = new int[2];
        
        while( left < right){
            int sum = numbers[left] +  numbers[right];
            if( sum == target){
                rst[0] = left + 1;
                rst[1] = right + 1;
                break;
            }else if( sum < target){
                left++;
            }else{
                right--;
            }
        }
        return rst;
    }

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
