/**
 * 
 */
package amazon.onsite;

import java.util.HashMap;
import java.util.Map;

import list.ListNode;

/**
 * @author Tiannan
 *
 */
public class CopyLinkedListWithRandomPointer {

	   // Actual clone method which returns head
    // reference of cloned linked list.
    public static ListNode clone(ListNode head)
    {
        // Initialize two references, one with original
        // list's head.
        ListNode origCurr = head, cloneCurr = null;
 
        // Hash map which contains ListNode to ListNode mapping of
        // original and clone linked list.
        Map<ListNode, ListNode> map = new HashMap<ListNode, ListNode>();
 
        // Traverse the original list and make a copy of that
        // in the clone linked list.
        while (origCurr != null)
        {
            cloneCurr = new ListNode(origCurr.val);
            map.put(origCurr, cloneCurr);
            origCurr = origCurr.next;
        }
 
        // Adjusting the original list reference again.
        origCurr =head;
 
        // Traversal of original list again to adjust the next
        // and random references of clone list using hash map.
        while (origCurr != null)
        {
            cloneCurr = map.get(origCurr);
            cloneCurr.next = map.get(origCurr.next);
            cloneCurr.random = map.get(origCurr.random);
            origCurr = origCurr.next;
        }
 
        //return the head reference of the clone list.
        return map.get(head);
    }

    // Main method.
    public static void main(String[] args)
    {
        // Pushing val in the linked list.
        ListNode head = new ListNode(5);
        ListNode list =head;
        list.next=new ListNode(4);list=list.next;
        list.next=new ListNode(3);list=list.next;
        list.next=new ListNode(2);list=list.next;
        list.next=new ListNode(1);
        list =head;
        // Setting up random references.
        list.random = list.next.next;
        list.next.random =
            list.next.next.next;
        list.next.next.random =
            list.next.next.next.next;
        list.next.next.next.random =
            list.next.next.next.next.next;
        list.next.next.next.next.random =
            list.next;
        list =head;
        // Making a clone of the original linked list.
        ListNode clone = clone(list);
 
        // Print the original and cloned linked list.
      
    }
}

