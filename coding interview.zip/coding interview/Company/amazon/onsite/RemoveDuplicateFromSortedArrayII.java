/**
 * 
 */
package amazon.onsite;

import java.util.Arrays;

/**
 * 
 * Given a sorted array, remove the duplicates in place such that each element appear only once and return the new length. 
 * Do not allocate extra space for another array, you must do this in place with constant memory. 
 * For example, Given input array A = [1,1,2], Your function should return length = 2, and A is now [1,2]. 
 * Follow up for "Remove Duplicates":
What if duplicates are allowed at most twice?

For example,
Given sorted array A = [1,1,1,2,2,3],

Your function should return length = 5, and A is now [1,1,2,2,3].

 * @author Tiannan
 *
 */
public class RemoveDuplicateFromSortedArrayII {
	
	public static int removeI(int []a ){
		if (a==null||a.length==0){
			return 0;
		}
		if (a.length==1){
			return 1;
		}
		int size = 0;
		for(int i= 0;i<a.length; i++){
			if(a[size]!=a[i]){
				a[++size]=a[i];
			}
		}
		return size+1;
	}
	
	/**
     * @param A: a array of integers
     * @return : return an integer
     */
    public static int removeDuplicates(int[] nums) {
        // write your code here
        if(nums == null)
            return 0;
        int cur = 0;
        int i ,j;
        for(i = 0; i < nums.length;){
            int now = nums[i];
            for( j = i; j < nums.length; j++){
                if(nums[j] != now)
                    break;
                if(j-i < 2)
                    nums[cur++] = now; 
                System.out.println(cur);
            }
            i = j;
        }
        return cur;
    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int []a = new int []{
				1,2,2,2,3,3,4,4,4,5,6,7
		};
		System.out.println(Arrays.toString(a));
		System.out.println(removeDuplicates(a));
		System.out.println(Arrays.toString(a));
	}

}
