/**
 * 
 */
package amazon.onsite;

import java.util.Stack;

import tree.TreeNode;

/**
 * Given a binary tree, determine if it is a valid binary search tree (BST).

Assume a BST is defined as follows:
•The left subtree of a node contains only nodes with keys less than the node's key.
•The right subtree of a node contains only nodes with keys greater than the node's key.
•Both the left and right subtrees must also be binary search trees.

Example 

An example:
  2
 / \
1   3
   /
  4
   \
    5


The above binary tree is serialized as {2,1,3,#,#,4,#,#,5} (in level order).

 * @author Tiannan
 *
 */
public class ValidateBinarySearchTree {
	/**
	 * Definition for binary tree
	 * public class TreeNode {
	 *     int val;
	 *     TreeNode left;
	 *     TreeNode right;
	 *     TreeNode(int x) { val = x; }
	 * }
	 */
	
	    private int lastVal = Integer.MIN_VALUE;
	    private boolean firstNode = true;
	    public boolean isValidBST(TreeNode root) {
	        if (root == null) {
	            return true;
	        }
	        if (!isValidBST(root.left)) {
	            return false;
	        }
	        if (!firstNode && lastVal >= root.val) {
	            return false;
	        }
	        firstNode = false;
	        lastVal = root.val;
	        if (!isValidBST(root.right)) {
	            return false;
	        }
	        return true;
	    }
	    /*
        SOLUTION 2: Use the recursive version.
        REF: http://blog.csdn.net/fightforyourdream/article/details/14444883
    */
    public boolean isValidBST2(TreeNode root) {
        // Just use the inOrder traversal to solve the problem.
        if (root == null) {
            return true;
        }
        
        return dfs(root, Long.MIN_VALUE, Long.MAX_VALUE);
    }
    
    public boolean dfs(TreeNode root, long low, long up) {
        if (root == null) {
            return true;
        }
        
        if (root.val >= up || root.val <= low) {
            return false;
        }
        
        return dfs(root.left, low, root.val) 
           && dfs(root.right, root.val, up);
    }
    
    public boolean isValidBST3(TreeNode root) {
        // Just use the inOrder traversal to solve the problem.
        if (root == null) {
            return true;
        }
        
        Stack<TreeNode> s = new Stack<TreeNode>();
        TreeNode cur = root;
        
        TreeNode pre = null;
        
        while(true) {
            // Push all the left node into the stack.
            while (cur != null) {
                s.push(cur);
                cur = cur.left;
            }
            
            if (s.isEmpty()) {
                break;
            }
            
            // No left node, just deal with the current node.
            cur = s.pop();
            
            if (pre != null && pre.val >= cur.val) {
                return false;
            }
            
            pre = cur;
            
            // Go to the right node.
            cur = cur.right;
        }
        
        return true;
    }
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
