package amazon;
public class RemoveVowel {
	public static boolean isVowel(char x){
		if( x == 'a' || x == 'A' ||
				x == 'e' || x == 'E' ||
				x == 'i' || x == 'I' ||
				x == 'o' || x == 'O' ||
				x == 'u' || x == 'U' ){
			return true;
		}else{
			return false;
		}
	}
	public static String removeVowel( String s){
		StringBuilder S = new StringBuilder(s);
		int Vstart = -1;
		int Vcounter = 0;
		for (int i = 0; i < S.length(); i++) {
			if (isVowel(S.charAt(i))) {
				if( Vstart == -1 ){
					Vstart = i;
				}
				Vcounter++;
			}else if( Vstart != -1 ){
				char y = S.charAt(i);
				char z = S.charAt(Vstart);
				S.setCharAt(Vstart, y);
				S.setCharAt(i, z);
				Vstart++;
			}
		}
		return S.toString().substring(0,s.length() - Vcounter);
	}
	public static String removeVowel1( String string){
		StringBuffer sb = new StringBuffer(); 
		String v = "aeiouAEIOU";
		for(int i = 0; i < string.length(); i++){
		if(v.indexOf(string.charAt(i)) > -1) continue;
		sb.append(string.charAt(i));
		}
		return sb.toString();
		
	}
	public static void main(String[] args) {
		System.out.println(removeVowel("the rain in spain is mainly from the plains."));
	}
}