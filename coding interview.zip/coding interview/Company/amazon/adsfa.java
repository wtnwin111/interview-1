/**
 * 
 */
package amazon;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author Tiannan
 *
 */
public class adsfa {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		 ArrayList<Integer> temp= new ArrayList<Integer>();
		while(input.hasNextInt()) {
			
		    temp.add(input.nextInt());
		   
		    
		    
		    
		}
		System.out.println(temp.size());
		System.out.println("The loop has been ended");
//		int[][] matrix = new int[n][n];
//		for ( int i = 0 ; i < n ; i++ )
//		{	
//			for ( int j = 0 ; j < n ; j++ )
//			{
//				matrix[i][j]= input.nextInt();
//				
//			}
//		}
//		input.close();
//
//		for(int i=0;i<n;i++){
//			for(int j=0;j<n;j++){
//				System.out.print(matrix[i][j]+" ");
//			}
//			System.out.println();
//		}
//
	}

}
