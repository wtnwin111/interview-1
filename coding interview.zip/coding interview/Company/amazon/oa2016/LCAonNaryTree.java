package amazon.oa2016;

import java.util.ArrayList;

/**
 * Created by K25553 on 11/22/2016.
 */
public class LCAonNaryTree {
    class NaryTreeNode{
        int val;
        ArrayList<NaryTreeNode> children;

        public NaryTreeNode(int val, ArrayList<NaryTreeNode> children) {
            this.val = val;
            this.children = children;
        }
    }
    NaryTreeNode LCA(NaryTreeNode a, NaryTreeNode b, NaryTreeNode root)
    {
        if(root == null || a == root || b == root)
            return root;

        int count = 0;
        NaryTreeNode temp = null;

        for(NaryTreeNode iter : root.children)
        {
            NaryTreeNode res = LCA(a, b, iter);
            if(res != null)
            {
                count++;
                temp = res;
            }
        }

        if(count == 2)
            return root;
        if(count==1){
            return temp;
        }
        return null;

    }
}

