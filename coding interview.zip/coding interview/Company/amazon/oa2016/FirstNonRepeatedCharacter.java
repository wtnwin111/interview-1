package amazon.oa2016;

/**Given a string, find the first non-repeating character in it. For example, if the input string is ��GeeksforGeeks��,
 * then output should be ��f�� and if input string is ��GeeksQuiz��, then output should be ��G��.
 * Created by K25553 on 11/21/2016.
 */
public class FirstNonRepeatedCharacter {
    /*Input string: str = geeksforgeeks
1: Construct character count array from the input string.
   ....
  count['e'] = 4
  count['f'] = 1
  count['g'] = 2
  count['k'] = 2
  ����
2: Get the first character who's count is 1 ('f').*/
    char FirstNonRepeatedCharacter(String string){
        if(string==null||string.length()==1){
            return '1';
        }
        int [] dic = new int[256];
        char [] s = string.toCharArray();
        char crt = s[1];
        for(char i: s){
            dic[s[i]]++;
        }
        for(char i: s){
           if(dic[s[i]]==1){
               return i;
           }
        }
        return '1';
    }

    char KthNonRepeatedCharacter(String string){
        if(string==null||string.length()==1){
            return '1';
        }
        int [] dic = new int[256];
        char [] s = string.toCharArray();
        char crt = s[1];
        for(char i: s){
            dic[s[i]]++;
        }
        for(char i: s){
            if(dic[s[i]]==1){
                return i;
            }
        }
        return '1';
    }

}
