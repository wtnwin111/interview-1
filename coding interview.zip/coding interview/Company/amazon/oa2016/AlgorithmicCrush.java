package amazon.oa2016;

import java.util.Scanner;

/**You are given a list of size , initialized with zeroes. You have to perform  operations on the list and output the maximum of final values of all the  elements in the list. For every operation, you are given three integers ,  and  and you have to add value  to all the elements ranging from index  to (both inclusive).

 Input Format

 First line will contain two integers  and  separated by a single space.
 Next  lines will contain three integers ,  and  separated by a single space.
 Numbers in list are numbered from  to .
 Output Format

 A single line containing maximum value in the updated list.

 Sample Input

 5 3
 1 2 100
 2 5 100
 3 4 100
 Sample Output

 200
 Explanation

 After first update list will be 100 100 0 0 0.
 After second update list will be 100 200 100 100 100.
 After third update list will be 100 200 200 200 100.
 So the required answer will be 200.


 You should verify that every value you read from the user is a valid value in your program.

 As far as complexity goes, a suffix tree with a complexity of O(NlogN)O(Nlog?N) compared to your current O(MN)O(MN) solution that adds difference to every value in the range [A,B][A,B]. With N?107N?107, an O(NlogN)O(Nlog?N) solution may still be too slow.

 For this problem, I would employ a max prefix sum scan on a difference array. To generate a set of range differences, we adjust arra+=karra+=k and arrb+1?=karrb+1?=k. Going back to your sample data, your difference array would look like this:

 #   1.......................N...N+1
 5 3      #   0     0     0     0     0     0
 1 2 100  # 100     0  -100     0     0     0
 2 5 100  # 100   100  -100     0     0  -100
 3 4 100  # 100   100     0     0  -100  -100
 To calculate the max prefix sum, accumulate the difference array to NN while taking the maximum accumulated prefix. (*) denotes new max found.

 DiffArray  100  100    0    0  -100  -100
 PrefixSum  100*
 Max = 100

 DiffArray  100  100    0    0  -100  -100
 PrefixSum       200*
 Max = 200

 DiffArray  100  100    0    0  -100  -100
 PrefixSum            200
 Max = 200

 DiffArray  100  100    0    0  -100  -100
 PrefixSum                 200
 Max = 200

 DiffArray  100  100    0    0  -100  -100
 PrefixSum                       100
 Max = 200
 Building a difference array in O(M)O(M) and finding the max prefix sum in O(N)O(N) results in a O(M+N)O(M+N) linear algorithm.
 * Created by K25553 on 11/21/2016.
 */
public class AlgorithmicCrush {
    static class Operation {
        public int a;
        public int b;
        public int k;

        public Operation(int a, int b, int k) {
            this.a = a;
            this.b = b;
            this.k = k;
        }

        public String toString() {
            return "[" + a + ", " + b + ", " + k + "]";
        }
    }

    public static long crush(int n, int m, Operation[] ops) {
        long[] crushState = new long[n+1];
        for(int i=0; i < crushState.length; i++) {
            crushState[i] = 0;
        }

        for(int i=0; i < m; i++) {
            crushState[ops[i].a-1] += ops[i].k;
            crushState[ops[i].b] -= ops[i].k;
        }

        long max = crushState[0];
        long sum = max;
        for(int i=1; i < n; i++) {
            sum += crushState[i];
            if(sum > max) {
                max = sum;
            }
        }

        return max;
    }

    public static void main(String[] args) {
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
        /* https://www.hackerrank.com/contests/w4/challenges/crush */
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int m = sc.nextInt();
        Operation[] ops = new Operation[m];

        for(int i=0; i < m; i++) {
            int a = sc.nextInt();
            int b = sc.nextInt();
            int k = sc.nextInt();
            ops[i] = new Operation(a, b, k);
        }

        long max = crush(n, m, ops);
        System.out.println(max);




    }

}
