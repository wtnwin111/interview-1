package amazon.oa2016;

import java.util.*;

/**
 * Design a simplified version of Twitter where users can post tweets, follow/unfollow another user and is able to see the 10 most recent tweets in the user's news feed. Your design should support the following methods:
 * <p>
 * postTweet(userId, tweetId): Compose a new tweet.
 * getNewsFeed(userId): Retrieve the 10 most recent tweet ids in the user's news feed. Each item in the news feed must be posted by users who the user followed or by the user herself. Tweets must be ordered from most recent to least recent.
 * follow(followerId, followeeId): Follower follows a followee.
 * unfollow(followerId, followeeId): Follower unfollows a followee.
 * Example:
 * <p>
 * Twitter twitter = new Twitter();
 * <p>
 * // User 1 posts a new tweet (id = 5).
 * twitter.postTweet(1, 5);
 * <p>
 * // User 1's news feed should return a list with 1 tweet id -> [5].
 * twitter.getNewsFeed(1);
 * <p>
 * // User 1 follows user 2.
 * twitter.follow(1, 2);
 * <p>
 * // User 2 posts a new tweet (id = 6).
 * twitter.postTweet(2, 6);
 * <p>
 * // User 1's news feed should return a list with 2 tweet ids -> [6, 5].
 * // Tweet id 6 should precede tweet id 5 because it is posted after tweet id 5.
 * twitter.getNewsFeed(1);
 * <p>
 * // User 1 unfollows user 2.
 * twitter.unfollow(1, 2);
 * <p>
 * // User 1's news feed should return a list with 1 tweet id -> [5],
 * // since user 1 is no longer following user 2.
 * twitter.getNewsFeed(1);
 * Created by K25553 on 11/23/2016.
 * ["Twitter","postTweet","getNewsFeed","follow","postTweet","getNewsFeed","unfollow","getNewsFeed"]
   [[],       [1,5],       [1],          [1,2],    [2,6],     [1],         [1,2],      [1]]
 [null,       null,         [5],         null,     null,      [6,5],          null,     [5]]
 */
public class Twitter {

    class node {
        int ct, tid, uid;

        public node(int ct, int tid, int uid) {
            this.ct = ct;
            this.tid = tid;
            this.uid= uid;
        }


    }

    private HashMap<Integer, Queue<node>> user_twitter_map;
    private HashMap<Integer, HashSet<Integer>> user_follower_map;
    int ct;

    /**
     * Initialize your data structure here.
     */
    public Twitter() {
        user_twitter_map = new HashMap<>();
        user_follower_map = new HashMap<>();
        ct = 0;
    }

    /**
     * Compose a new tweet.
     */
    public void postTweet(int userId, int tweetId) {
        ct++;
        System.out.println(ct);
        node crt = new node(ct, tweetId, userId);
        if (user_twitter_map.containsKey(userId)) {
            updateFeed(user_twitter_map.get(userId), crt);

            for (Integer follower : user_follower_map.get(userId)) {
                if (user_twitter_map.containsKey(follower)) {
                    updateFeed(user_twitter_map.get(follower), crt);
                }
            }

        } else {
            user_twitter_map.put(userId, new PriorityQueue<node>(new Comparator<node>() {
                @Override
                public int compare(node o1, node o2) {
                    return o2.ct - o1.ct;
                }
            }));
            updateFeed(user_twitter_map.get(userId), crt);
            if(user_follower_map.containsKey(userId)){
                for (Integer follower : user_follower_map.get(userId)) {
                    if (user_twitter_map.containsKey(follower)) {
                        updateFeed(user_twitter_map.get(follower), crt);
                    }
                }
            }
        }
    }

    private void updateFeed(Queue<node> queue, node crt) {
        while (queue.size() > 9) {
            queue.poll();
        }
        queue.offer(crt);
    }

    /**
     * Retrieve the 10 most recent tweet ids in the user's news feed. Each item in the news feed must be posted by users who the user followed or by the user herself.
     * Tweets must be ordered from most recent to least recent.
     */
    public List<Integer> getNewsFeed(int userId) {
        List<Integer> res = new ArrayList();
        if(user_twitter_map.containsKey(userId)){
            for(node crt :user_twitter_map.get(userId)){
                res.add(crt.tid);
            }
        }
        return res;
    }

    /**
     * Follower follows a followee. If the operation is invalid, it should be a no-op.
     */
    public void follow(int followerId, int followeeId) {
        if (user_follower_map.containsKey(followeeId) ) {
            user_follower_map.get(followeeId).add(followerId);
        }
        else {
            user_follower_map.put(followeeId,new HashSet<Integer>());
            user_follower_map.get(followeeId).add(followerId);
        }
    }

    /**
     * Follower unfollows a followee. If the operation is invalid, it should be a no-op.
     */
    public void unfollow(int followerId, int followeeId) {
        if (user_follower_map.containsKey(followeeId) && user_follower_map.get(followeeId).contains(followerId)) {
            user_follower_map.get(followeeId).remove(followerId);
            
        }
    }
}
