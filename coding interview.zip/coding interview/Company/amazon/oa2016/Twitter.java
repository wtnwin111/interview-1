package amazon.oa2016;

import java.util.*;

/**
 * Design a simplified version of Twitter where users can post tweets, follow/unfollow another user and is able to see the 10 most recent tweets in the user's news feed. Your design should support the following methods:
 * <p>
 * postTweet(userId, tweetId): Compose a new tweet.
 * getNewsFeed(userId): Retrieve the 10 most recent tweet ids in the user's news feed. Each item in the news feed must be posted by users who the user followed or by the user herself. Tweets must be ordered from most recent to least recent.
 * follow(followerId, followeeId): Follower follows a followee.
 * unfollow(followerId, followeeId): Follower unfollows a followee.
 * Example:
 * <p>
 * Twitter twitter = new Twitter();
 * <p>
 * // User 1 posts a new tweet (id = 5).
 * twitter.postTweet(1, 5);
 * <p>
 * // User 1's news feed should return a list with 1 tweet id -> [5].
 * twitter.getNewsFeed(1);
 * <p>
 * // User 1 follows user 2.
 * twitter.follow(1, 2);
 * <p>
 * // User 2 posts a new tweet (id = 6).
 * twitter.postTweet(2, 6);
 * <p>
 * // User 1's news feed should return a list with 2 tweet ids -> [6, 5].
 * // Tweet id 6 should precede tweet id 5 because it is posted after tweet id 5.
 * twitter.getNewsFeed(1);
 * <p>
 * // User 1 unfollows user 2.
 * twitter.unfollow(1, 2);
 * <p>
 * // User 1's news feed should return a list with 1 tweet id -> [5],
 * // since user 1 is no longer following user 2.
 * twitter.getNewsFeed(1);
 * Created by K25553 on 11/23/2016.
 * ["Twitter();  a.postTweet();  a.getNewsFeed();  a.follow();  a.postTweet();  a.getNewsFeed();  a.unfollow();  a.getNewsFeed"]
 * [[],       [1,5],       [1],          [1,2],    [2,6],     [1],         [1,2],      [1]]
 * [null,       null,         [5],         null,     null,      [6,5],          null,     [5]]
 */
public class Twitter {

    class node {
        int ct, tid, uid;
        node next;

        public node(int ct, int tid, int uid) {
            this.ct = ct;
            this.tid = tid;
            this.uid = uid;
        }


    }

    private HashMap<Integer, ArrayList<node>> user_twitter_map;
    private HashMap<Integer, HashSet<Integer>> user_follower_map;
    int ct;

    /**
     * Initialize your data structure here.
     */
    public Twitter() {
        user_twitter_map = new HashMap<>();
        user_follower_map = new HashMap<>();
        ct = 0;
    }

    /**
     * Compose a new tweet.
     */
    public void postTweet(int userId, int tweetId) {
        ct++;

        node crt = new node(ct, tweetId, userId);
        if (!user_follower_map.containsKey(userId)||!user_follower_map.get(userId).contains(userId)) {
            follow(userId, userId);
        }

        if (user_twitter_map.containsKey(userId)) {
            user_twitter_map.get(userId).add(crt);

        } else {
            user_twitter_map.put(userId, new ArrayList<node>());
            user_twitter_map.get(userId).add(crt);
        }
    }

    private ArrayList<node> get10recent(ArrayList<node> list) {
        ArrayList<node> res = new ArrayList<>();
        int crt = list.size() - 1;
        for (int i = 0; i < 10 && crt - i > -1; i++) {
            res.add(list.get(crt - i));
        }
        return res;
    }

    /**
     * Retrieve the 10 most recent tweet ids in the user's news feed. Each item in the news feed must be posted by users who the user followed or by the user herself.
     * Tweets must be ordered from most recent to least recent.
     */
    public List<Integer> getNewsFeed(int userId) {
        if (!user_follower_map.containsKey(userId)) {
            return new LinkedList<Integer>();
        }
        HashMap<Integer, Iterator<node>> followees = new HashMap<>();
        HashMap<Integer, ArrayList<node>> feeds = new HashMap<>();
        List<Integer> res = new ArrayList<>();
        PriorityQueue<node> queue = new PriorityQueue<>(new Comparator<node>() {
            @Override
            public int compare(node o1, node o2) {
                return o2.ct - o1.ct;
            }
        });
        for (Integer crt : user_follower_map.get(userId)) {
            if (user_twitter_map.containsKey(crt) && user_twitter_map.get(crt).size() > 0) {
                ArrayList<node> feed = get10recent(user_twitter_map.get(crt));
                followees.put(crt, feed.iterator());
                feeds.put(crt, feed);

            }
        }
        for (int followee : followees.keySet()) {
            Iterator<node> crt = followees.get(followee);
            if (crt.hasNext()) {
                queue.offer(crt.next());
            } else {
                followees.remove(crt);
            }
        }
        while (res.size() < 10 && queue.size() > 0) {
            node crt = queue.poll();
            res.add(crt.tid);
            Iterator<node> crt_iterator = followees.get(crt.uid);
            if (crt_iterator.hasNext()) {
                queue.offer(crt_iterator.next());
            } else {
                followees.remove(crt_iterator);
            }
        }
        return res;
    }

    /**
     * Follower follows a followee. If the operation is invalid, it should be a no-op.
     */
    public void follow(int followerId, int followeeId) {
        if (user_follower_map.containsKey(followerId)) {
            user_follower_map.get(followerId).add(followeeId);
        } else {
            user_follower_map.put(followerId, new HashSet<>());
            user_follower_map.get(followerId).add(followeeId);
        }
    }

    /**
     * Follower unfollows a followee. If the operation is invalid, it should be a no-op.
     */
    public void unfollow(int followerId, int followeeId) {

        if (user_follower_map.containsKey(followerId)&&(followeeId!=followerId)) {
            user_follower_map.get(followerId).remove(followeeId);
        }
        //System.out.println(user_follower_map.get(followerId));
    }

    public static void main(String[] args) {
        Twitter a = new Twitter();
        a.postTweet(1, 5);
        a.follow(1, 2);
        a.follow(2, 1);
        System.out.println(a.getNewsFeed(2).toString());
        a.postTweet(2, 6);
        System.out.println(a.getNewsFeed(1));
        System.out.println(a.getNewsFeed(2));
        a.unfollow(2, 1);
        System.out.println(a.getNewsFeed(1));
        System.out.println(a.getNewsFeed(2));
        a.unfollow(1, 2);
        System.out.println(a.getNewsFeed(1));
        System.out.println(a.getNewsFeed(2));
    }
}
