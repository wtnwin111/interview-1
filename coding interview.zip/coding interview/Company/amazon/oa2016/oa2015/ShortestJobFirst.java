package amazon.oa2016.oa2015;

import java.util.Comparator;
import java.util.PriorityQueue;

/** һ��������Ҫ����һ��request��һ��ֻ�ܴ���һ����������м�����ѹ�ŵ�requests��������ִ�г���ʱ��̵��Ǹ������ڳ���ʱ����ȵ�requests����ִ�����絽�ﴦ������request����ƽ��ÿ��requestҪ�ȶ�ò��ܱ�������input��requestTimes[]��ÿ��request���ﴦ������ʱ��; durations[] ÿ��requestҪ�����ĳ���ʱ�䡣 ����������һһ��Ӧ�ģ����Ѱ�requestTimes[] ��С���������

 public double CalWaitingTime(int requestTimes[], int[] durations[]){}

 ��priorityqueue����������һ������ѭ���Ĵ𰸣�û��ϸ��������round robin�Ժ���˼·�����ơ�
 ע����priorityqueueдcomparator��ʱ��Ҫ���ж����ߵ�execute time,���execute time��ͬ���򷵻�arrival time֮����Ȱ�ִ��ʱ��������ִ��ʱ����ͬ�򰴵����ʱ���š�

 �ģ�������Ժ�Ĺ���������ߣ�
 ԭ�����ӣ�http://www.jianshu.com/p/bb522c1157b0
 ����Ȩ���������У�ת������ϵ���߻����Ȩ������ע���������ߡ���
 * Created by K25553 on 11/17/2016.
 * Given an array of arriving time and an array of processing time. Calculate the average waiting time of the system using shortest job first scheduling.
 */
public class ShortestJobFirst {
    public double findAverage(int []request, int[]duration){
        if(request==null||duration==null||request.length==0||duration.length==0){
            return 0;
        }
        int n=request.length;
        int []end=new int[n];
        int curTime=0;
        for(int i=0;i<n;i++){
            if(i==0){
                    curTime=duration[0];
                end[0]=duration[0];
            }else{
                int minDuration=Integer.MAX_VALUE;
                int curProcess=0;
                for(int j=0;j<n;j++){
                    if(end[j]!=0) continue;
                    if(request[j]<=curTime){
                        if(duration[j]<minDuration){
                            minDuration=duration[j];
                            curProcess=j;
                        }
                    }else{
                        break;
                    }
                }
                if(curProcess==0){
                    curProcess=i;
                    curTime=request[curProcess];
                }
                curTime=curTime+duration[curProcess];
                end[curProcess]=curTime;
                //System.out.println(end[curProcess]+"end");
            }
        }
        int waitSum=0;
        for(int i=0;i<n;i++){
            //System.out.println(waitSum+"sum"+end[i]+"end"+request[i]+"arrive"+duration[i]+"duration");
            waitSum+=end[i]-request[i]-duration[i];

        }
        System.out.println(waitSum);
        return (double)waitSum/(double)n;
    }
    class Process {
        int processTime, arriveTime;
        Process(int arriveTime,int processTime){
            this.processTime = processTime;
            this.arriveTime = arriveTime;
        }
    }
    public double sjf1(int[] arrive, int[] execute){
        PriorityQueue<Process> pq = new PriorityQueue<Process>(arrive.length, new Comparator<Process>(){
            @Override
            public int compare(Process p1,Process p2){
//                if(p1.arriveTime!=p1.arriveTime){
//                    return p1.arriveTime -p1.arriveTime;
//                }
                return p1.processTime-p2.processTime;
            }
        });
        int i = 0;
        int waitTime = 0;
        int curTime = 0;
        while(!pq.isEmpty() || i<arrive.length){
            if(!pq.isEmpty()){
                Process p = pq.poll();
                waitTime += (curTime-p.arriveTime);
                curTime += p.processTime;
                for(;i<arrive.length;i++){
                    if(arrive[i]<=curTime){
                        pq.offer(new Process(arrive[i],execute[i]));
                    }
                    else{
                        break;
                    }
                }
            }
            else{
                pq.offer(new Process(arrive[i],execute[i]));
                curTime = arrive[i++];
            }
        }
        System.out.println(waitTime);
        return waitTime*1.0/arrive.length;
    }

    public double sjf(int[] arrive, int[] execute) {
        PriorityQueue<Process> q = new PriorityQueue<Process>(arrive.length, new Comparator<Process>() {
            @Override
            public int compare(Process p1, Process p2) {
                if(p1.arriveTime!=p2.arriveTime){
                    return p1.arriveTime -p2.arriveTime;
                }
                return p1.processTime - p2.processTime;
            }
        });
        for( int i=0; i< arrive.length; i++){
            q.offer(new Process(arrive[i], execute[i]));
        }
        int endtime = 0;
        int waitTime = 0;
        while(!q.isEmpty()){
            Process crt = q.poll();
            waitTime += Math.max(0,endtime-crt.arriveTime);

            if(endtime<crt.arriveTime){
                endtime =crt.arriveTime+ crt.processTime;
            }else{
                endtime += crt.processTime;
            }
            //System.out.println(crt.arriveTime+"crtwait"+crt.processTime+"crtdurate"+waitTime+"wait"+ endtime +"ends");
        }
        return waitTime*1.0/arrive.length;
    }
    class process {
        int exeTime, arrTime;
        process(int arriveTime,int processTime){
            this.exeTime = processTime;
            this.arrTime = arriveTime;
        }
    }
    public float Solution(int[] req, int[] dur) {
        if (req == null || dur == null || req.length != dur.length)
            return 0;
        int index = 0, length = req.length;
        int waitTime = 0, curTime = 0;
        PriorityQueue<process> pq = new PriorityQueue<process>(new Comparator<process>() {
            @Override
            public int compare(process p1, process p2) {
                if (p1.exeTime == p2.exeTime)
                    return p1.arrTime - p2.arrTime;
                return p1.exeTime - p2.exeTime;
            }
        });
        while (!pq.isEmpty() || index < length) {
            if (!pq.isEmpty()) {
                process cur = pq.poll();
                waitTime += curTime - cur.arrTime;
                curTime += cur.exeTime;
                System.out.println(waitTime+"sum"+curTime+"curTime"+cur.arrTime+"cur.arrTime"+cur.exeTime+"cur.exeTime");
                while (index < length && curTime >= req[index])
                    pq.offer(new process(req[index], dur[index++]));
            }
            else {
                pq.offer(new process(req[index], dur[index]));
                curTime = req[index++];
            }
        }
        return (float) waitTime / length;
    }
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        ShortestJobFirst solution=new ShortestJobFirst();
        int[] request={0,1,4,9};//{0,2,4,5};
        int[] duration={2,1,7,5};//{7,4,1,4};
        int[] request1={0,2,4,5};
        int[] duration1={7,4,1,4};
       // double result=solution.sjf(request, duration);//.75
        double result12=solution.findAverage(request1, duration1);
        System.out.println(result12);
        float result1=solution.Solution(request1, duration1);//4.75
        System.out.println(result1);

    }

}
