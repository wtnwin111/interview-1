package amazon.oa2016.oa2015;

import java.util.LinkedList;
import java.util.Queue;

/**Given an array of arriving time ,an array of processing time and the quantum number q.
 * Calculate the average waiting time of the system using Round Robin scheduling
 * for {0,1,3,9} {2,1,7,5},2 return 1.0
 * thr processes run in the following slots p1 initially runs for 2s p2 runs for 1 s p3 runs for 6s till
 * p4 enter cpu time slot 9th s, when it run for 2, p3 then runs for 1s followed by p4 running  for 3s.
 * the waiting time for P1234 is 0121 then avg is 1s
 * Created by K25553 on 11/17/2016.
 */
public class RoundRobin {
    public class process {
        int arriveTime;
        int excuteTime;
        process(int arr, int exc) {
            arriveTime = arr;
            excuteTime = exc;
        }
    }

    // Assume arrive is sorted.
    public double roundRobin(int[] arrive, int[] excute, int q) {
        LinkedList<process> queue = new LinkedList<>();
        int curTime = 0;
        int waitTime = 0;
        int nextProIdx = 0;
        while (!queue.isEmpty() || nextProIdx < arrive.length) {
            if (!queue.isEmpty()) {
                process cur = queue.poll();
                waitTime += curTime - cur.arriveTime;
                curTime += Math.min(cur.excuteTime, q);
                for (int i = nextProIdx; i < arrive.length; i ++) {
                    if (arrive[i] <= curTime) {
                        queue.offer(new process(arrive[i], excute[i]));
                        nextProIdx = i + 1;
                    } else {
                        break;
                    }
                }
                if (cur.excuteTime > q) {
                    queue.offer(new process(curTime, cur.excuteTime - q));
                }
            } else {
                queue.offer(new process(arrive[nextProIdx], excute[nextProIdx]));
                curTime = arrive[nextProIdx ++];
            }
        }

        return (double)waitTime / arrive.length;
    }

    public double roundRobin1(int[] arrive, int[] excute, int q) {
        if(arrive==null||excute==null||arrive.length==0||excute.length==0){
            return 0;
        }
        Queue<process> queue = new LinkedList<>();
        int i= 0, waittime=0,crttime=0;
        while( !queue.isEmpty()||i<arrive.length ){
            if(queue.isEmpty()){
                queue.offer(new process(arrive[i], excute[i]));
                crttime = arrive[i++];
            }else{
                process crt = queue.poll();
                waittime += crttime- crt.arriveTime;
                crttime += Math.min(crt.excuteTime, q);
                for (;i< arrive.length;i++){
                    if(arrive[i]<crttime){

                        queue.offer(new process(arrive[i], excute[i++]));

                    }else{
                        break;
                    }
                }
                if (crt.excuteTime>q){
                    queue.offer(new process(crttime, crt.excuteTime-q));
                }
            }
        }

        return (float) waittime/arrive.length;
    }
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        RoundRobin solution=new RoundRobin();
        int[] request={0,1,3,9};//{0,2,4,5};
        int[] duration= {2,1,7,5};//{7,4,1,4};
        int[] request1={0,2,4,5};
        int[] duration1={7,4,1,4};
        // double result=solution.sjf(request, duration);//.75
        double result12=solution.roundRobin1(request, duration,2);
        System.out.println(result12);


    }
}


