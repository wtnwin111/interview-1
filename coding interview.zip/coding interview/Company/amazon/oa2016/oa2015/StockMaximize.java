package amazon.oa2016.oa2015;

import java.io.BufferedInputStream;
import java.util.ArrayList;
import java.util.Scanner;

/**Your algorithms have become so good at predicting the market that you now know what the share price of Wooden Orange Toothpicks Inc. (WOT) will be for the next N days.

 Each day, you can either buy one share of WOT, sell any number of shares of WOT that you own, or not make any transaction at all. What is the maximum profit you can obtain with an optimum trading strategy?

 Input Format

 The first line contains the number of test cases T. T test cases follow:

 The first line of each test case contains a number N. The next line contains N integers, denoting the predicted price of WOT shares for the next N days.

 Constraints

 1 <= T <= 10
 1 <= N <= 50000
 All share prices are between 1 and 100000
 Output Format

 Output T lines, containing the maximum profit which can be obtained for the corresponding test case.

 Sample Input

 3
 3
 5 3 2
 3
 1 2 100
 4
 1 3 1 2
 Sample Output

 0
 197
 3
 Explanation

 For the first case, you cannot obtain any profit because the share price never rises.
 For the second case, you can buy one share on the first two days, and sell both of them on the third day.
 For the third case, you can buy one share on day 1, sell one on day 2, buy one share on day 3, and sell one share on day 4.
 * Created by K25553 on 11/21/2016.
 */
public class StockMaximize {
    public static int findMaxProfit(ArrayList<Integer> prices){
        if(prices==null||prices.size()==0)
        return  0;
        int profit =0; int max = Integer.MIN_VALUE;
        for(int i = prices.size()-1; i>-1; i--){
            max= Math.max(max, prices.get(i));
            profit += (max-prices.get(i));
        }
        return profit;
    }
    public static void main(String[] args) {
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
        Scanner scanner = new Scanner(System.in);
        int numOfCases = scanner.nextInt();
        ArrayList<ArrayList<Integer>> input = new ArrayList<>(numOfCases);
        for (int i =0; i< numOfCases; i++){
            int  a = scanner.nextInt();
            ArrayList<Integer> crt = new ArrayList<>();
            for ( int j =0; j< a; j++){
                crt.add(scanner.nextInt());
            }
            input.add(crt);
        }
        for (ArrayList<Integer> crt : input){
            System.out.println(findMaxProfit(crt));
        }

        Scanner in = new Scanner(new BufferedInputStream(System.in));
        int T = in.nextInt();
        while (T-- > 0) {
            int n = in.nextInt();
            int[] a = new int[50005];
            for (int i = 0; i < n; ++i) {
                a[i] = in.nextInt();
            }
            int now = a[n - 1];
            long ans = 0;
            for (int i = n - 2; i >= 0; --i) {
                now = Math.max(now, a[i]);
                ans += now - a[i];
            }
            System.out.println(ans);
        }
    }
}
