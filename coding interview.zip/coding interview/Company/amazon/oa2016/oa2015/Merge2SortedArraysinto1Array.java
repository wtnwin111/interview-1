package amazon.oa2016.oa2015;

/**There are two sorted arrays. First one is of size m+n containing only m elements. Another one is of size n and contains n elements.
 * Merge these two arrays into the first array of size m+n such that the output is sorted.
 * Created by K25553 on 11/22/2016.
 * Algorithm:
 ����sorted array����M��Ԫ�أ�����a��capacity��M�� b��capacity��2M������ǰ�a�е�Ԫ�ؼ��뵽b�У�����sorted��.
 Let first array be mPlusN[] and other array be N[]
 1) Move m elements of mPlusN[] to end.
 2) Start from nth element of mPlusN[] and 0th element of N[] and merge them
 into mPlusN[].
 */
public class Merge2SortedArraysinto1Array {

    /* Utility that prints out an array on a line */
    void printArray(int arr[], int size)
    {
        int i;
        for (i = 0; i < size; i++)
            System.out.print(arr[i] + " ");

        System.out.println("");
    }

    public static void main(String[] args)
    {
        Merge2SortedArraysinto1Array mergearray = new Merge2SortedArraysinto1Array();
        /* Initialize arrays 2 5 7 8 9 13 15 20 25*/
        int mPlusN[] = {2, 8,13, 15, 20, -1, -1, -1, -1 };
        int N[] = {5, 7, 9, 25};
        int n = N.length;
        int m = mPlusN.length - n;



        /*Merge N[] into mPlusN[] */
        mergearray.merge(mPlusN, N, m, n);

        /* Print the resultant mPlusN */
        mergearray.printArray(mPlusN, m + n);
    }

    private void merge(int[] mPlusN, int[] N, int m, int n) {
        if(N==null||mPlusN==null||mPlusN.length==0||N.length==0){
            return;
        }
        int a= m-1,  b=n-1;int crt= n+m-1;
        while(a>-1&&b>-1){
            if(mPlusN[a]<N[b]){
                mPlusN[crt--]=N[b--];
            }else{
                mPlusN[crt--]=mPlusN[a--];
            }
        }
        while (a > -1) {
            mPlusN[crt--]=mPlusN[a--];
        }
        while(b>-1){
            mPlusN[crt--]=N[b--];
        }
    }

}
