/**
 * 
 */
package amazon;

import java.util.ArrayList;
import java.util.Scanner;

/**��2:��ά���飬��һ����square�ġ�дһ�����������ÿ��Ԫ�ص�K���ڽ�Ԫ�أ�within k indices)���ǲ������ظ�Ԫ�ء����Ϊ��YES����NO��
���룺
4 ���� ����������������������ά���������
1 2 3 4
5 6 7 8
9 10 11 12. 
13 14 15 16
3 ���� K����ֵ

�����
NO

���룺
3
1 2 3 
4 5 6
5 8 9
2

�����
YES

���룺
4
1 2 3 
4 5 6
7 8 9
10 11 12


�����
NO
 * @author Tiannan
 *
 */
public class DuplicateWithinKindices {

	public static boolean searchinKindeces(int[][] grid, int k) {
		if(grid.length == 0||grid.length==1)
			return false;
		int row = grid.length;
		int col = grid[0].length;


		for(int i = 0; i < row; i++) {
			for(int j = 0; j < col; j++) {
				int val= grid[i][j];
				int x=i;int y=j;
				if(dfs(val,x,y,i+1, j, grid,k-1)||
						dfs(val,x,y,i-1, j, grid, k-1)||
						dfs(val,x,y,i, j+1, grid, k-1)||
						dfs(val,x,y, i,j-1, grid, k-1)||
						dfs(val,x,y, i-1,j-1, grid, k-1)||
						dfs(val,x,y, i+1,j+1, grid, k-1)||
						dfs(val,x,y, i-1,j+1, grid, k-1)||
						dfs(val,x,y, i+1,j-1, grid, k-1)){
				//	System.out.println(i+"[]"+j+"[]"+grid[i][j]);
					return true;

				}
			}
		}

		return false;

	}

	public static boolean dfs(int val, int x, int y, int i, int j, int[][] grid, int k) {
		if(i < 0 || j < 0 || i >= grid.length || j >= grid[0].length|| k<0)
			return false;
		if(grid[i][j] == val&& x!=i&&y!=j){
			System.out.println(i+"[]"+j+"[]"+grid[i][j]);
			return true;
		}
		
		return dfs(val,x,y,i+1, j, grid,k-1)||
				dfs(val,x,y,i-1, j, grid, k-1)||
				dfs(val,x,y,i, j+1, grid, k-1)||
				dfs(val,x,y, i,j-1, grid, k-1)||
				dfs(val,x,y, i-1,j-1, grid, k-1)||
				dfs(val,x,y, i+1,j+1, grid, k-1)||
				dfs(val,x,y, i-1,j+1, grid, k-1)||
				dfs(val,x,y,i+1,j-1, grid, k-1);
		
			//System.out.println(i+"[]"+j+"[]"+grid[i][j]);
			

		
	}


	/**
	 * @param args
	 */
	 public static void main(String[] args) {
		 Scanner input = new Scanner(System.in);
			int line = input.nextInt();
		
			ArrayList<Integer> temp= new ArrayList<Integer>();
			
			while(input.hasNextInt()) {
				
				temp.add(input.nextInt());
				
			}
			
			input.close();
			int k=temp.remove(temp.size()-1);
			int count=0;
			int [][]matrix= new int[line][temp.size()/line];
			for(int i=0;i<matrix.length;i++){
				for(int j=0;j<matrix[0].length;j++){
					matrix[i][j]=temp.get(count++);
					System.out.print(matrix[i][j]+" ");
				}
				System.out.println();
			}
			System.out.println(searchinKindeces(matrix, k));
			
//		int[][] a = new int[][] {
//				 { 1,2,3,4 },
//				 { 5,6,7,8 },
//				 { 9,0,10,12 },
//				 { 13,4,5,6 }
//				
//				};
//		
//		System.out.println(searchinKindeces(a, 4));
	 }

}
