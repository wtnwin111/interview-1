package array.colide;

/**
 * Created by K25553 on 8/31/2016.
 */
public class RemoveElement {
    public int removeElement(int[] a, int elem) {
        int i = 0;
        int j = a.length - 1;
        while(i <= j){
           if(a[i]==elem){
               a[i]=a[j];
               j--;
           }else{
               i++;
           }
        }
        return j + 1;
    }
}
