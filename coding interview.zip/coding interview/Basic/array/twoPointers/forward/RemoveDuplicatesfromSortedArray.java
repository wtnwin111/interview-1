package array.twoPointers.forward;

/**Example
 Given input array A = [1,1,2],

 Your function should return length = 2, and A is now [1,2].
 * Created by K25553 on 8/31/2016.
 */
public class RemoveDuplicatesfromSortedArray {
    /**
     * @param A: a array of integers
     * @return : return an integer
     */
    public int removeDuplicates(int[] nums) {
        if(nums==null||nums.length==0){
            return 0;
        }
        int l=0,r=0, len=nums.length;
        while(r<len ){
            while (r<len&&nums[r]==nums[l]){r++;}
            while (r<len&&nums[r]!=nums[l]){
                l++;
                int temp= nums[r];
                nums[r]=nums[l];
                nums[l]=temp;
                r++;
            }
        }
        return l+1;
    }
}
