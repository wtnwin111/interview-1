package array.twoPointers;

/**Example
 Given input array A = [1,1,2],

 Your function should return length = 2, and A is now [1,2].
 * Created by K25553 on 8/31/2016.
 */
public class RemoveDuplicatesfromSortedArray {
    /**
     * @param A: a array of integers
     * @return : return an integer
     */
    public int removeDuplicates(int[] nums) {
        // write your code here
    }
}
