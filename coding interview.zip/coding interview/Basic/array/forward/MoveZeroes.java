package array.forward;

/**Given an array nums, write a function to move all 0's to the end of it while maintaining the relative order of the non-zero elements.
 * Given nums = [0, 1, 0, 3, 12], after calling your function, nums should be [1, 3, 12, 0, 0].
 * Created by K25553 on 8/31/2016.
 */
public class MoveZeroes {
    /**
     * @param nums an integer array
     * @return nothing, do this in-place
     */
    public void moveZeroes(int[] nums) {
       int i=0,j=0,len=nums.length;
        while(i<len){
            if(nums[i]!=0){
                nums[j]=nums[i];
                        j++;
            }
            i++;
        }
        while(j<len){
            if(nums[j]!=0){
                nums[j]=0;

            }
            j++;
        }
    }
}
