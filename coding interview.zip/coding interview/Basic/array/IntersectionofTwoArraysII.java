package array;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

/**Given two arrays, write a function to compute their intersection.

 Notice

 Each element in the result must be unique.
 The result can be in any order.
 Have you met this question in a real interview? Yes
 Example
 Given nums1 = [1, 2, 2, 1], nums2 = [2, 2], return [2].
 * Created by K25553 on 8/30/2016.
 */
public class IntersectionofTwoArraysII {
    /**
     * @param nums1 an integer array
     * @param nums2 an integer array
     * @return an integer array
     */
    public int[] intersection(int[] nums1, int[] nums2) {
        if(nums1==null||nums2 ==null|| nums1.length==0||nums2.length==0){
            return new int[0] ;
        }
        ArrayList<Integer> list = new ArrayList<>();
        Arrays.sort(nums1);
        Arrays.sort(nums2);
        int index1 =0, index2=0;
        while (index1<nums1.length&&index2<nums2.length){
            if(nums1[index1]==nums2[index2]){
                list.add(nums1[index1]);
                index1++;
                index2++;
            }else if(nums1[index1]<nums2[index2]){
                index1++;
            }else{
                index2++;
            }

        }
        int [] res = new int[list.size()];int j=0;
        for(int i: list){
            res[j]=i;
            j++;
        }
        return res;
    }

    public int[] intersection1(int[] nums1, int[] nums2) {
        if(nums1==null||nums2 ==null|| nums1.length==0||nums2.length==0){
            return new int[0] ;
        }
        ArrayList<Integer> list = new ArrayList<>();
        HashMap<Integer, Integer> map = new HashMap<>();
        for(int i : nums1){
            if(map.containsKey(i)){
                map.put(i,map.get(i)+1);
            }else{
                map.put(i, 1);
            }
        }
        for (int i: nums2){
            if(map.containsKey(i)&&map.get(i)>0){
                map.put(i,map.get(i)-1);
                list.add(i);
            }
        }

        int [] res = new int[list.size()];int j=0;
        for(int i: list){
            res[j]=i;
            j++;
        }
        return res;
    }
}
