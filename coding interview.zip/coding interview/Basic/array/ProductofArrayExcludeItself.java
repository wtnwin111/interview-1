package array;

import java.util.ArrayList;

/**Given an integers array A.

 Define B[i] = A[0] * ... * A[i-1] * A[i+1] * ... * A[n-1], calculate B WITHOUT divide operation.
 * Created by K25553 on 9/15/2016.
 */
public class ProductofArrayExcludeItself {
    /**
     * @param a: Given an integers array A
     * @return: A Long array B and B[i]= A[0] * ... * A[i-1] * A[i+1] * ... * A[n-1]
     */
    public ArrayList<Long> productExcludeItself(ArrayList<Integer> a) {
        ArrayList<Long> res= new ArrayList<>();

        long prod [] = new long [a.size()] ;
        prod[a.size()-1]=a.get(a.size()-1);
        for(int i=a.size()-2; i> -1; i--){
            prod[i]= a.get(i)*prod[i+1];
        }
        long front = 1;
        for(int i=0; i< a.size(); i++ ){
            if(i+1<a.size()){
                res.add(front*prod[i+1]);
            }else{
                res.add(front);
            }
            front *= a.get(i);
        }
        return  res;
    }
}
