package array;

/**Reverse digits of an integer. Returns 0 when the reversed integer overflows (signed 32-bit integer).

 Have you met this question in a real interview? Yes
 Example
 Given x = 123, return 321

 Given x = -123, return -321
 * Created by K25553 on 10/17/2016.
 */
public class ReverseInteger {
    /**
     * @param n the integer to be reversed
     * @return the reversed integer
     */
    public int reverseInteger(int n) {

        int res= 0;
        while(n!=0){
           int temp = res*10+ n%10;
            //corner case: reverse > integer.max
            if(temp/10!=res){
                return 0;
            }
            n=n/10;
            res=temp;
        }
        return res;
    }
}
