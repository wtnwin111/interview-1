package JavaBasic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * Created by K25553 on 10/17/2016.
 */
public class LoadBalancer {

        //lkup O1 hashmap. get key
        //remove. O1: replace map. O1 find last key in list, set/update last key with removed key's index in list,
        // remove last key in map and last index in map
        private ArrayList<Integer> set;
    private Map<Integer, Integer> map;
    public LoadBalancer() {
        set = new ArrayList<>();
        map = new HashMap<>();
    }

    // @param server_id add a new server to the cluster
    // @return void
    public void add(int server_id) {
        int size = set.size();
        map.put(server_id, size);
        set.add(server_id);

    }

    // @param server_id server_id remove a bad server from the cluster
    // @return void
    public void remove(int server_id) {
        int index = map.get(server_id);
        int size = set.size();
        map.put(set.get(size - 1), index);
        set.set(index, set.get(size - 1));
        set.remove(size - 1);
        map.remove(server_id);
    }

    // @return pick a server in the cluster randomly with equal probability
    public int pick() {
        Random random = new Random();
        int m=set.size();
        int index= Math.abs(random.nextInt())%m;
        return set.get(index);

    }

}
