package JavaBasic;

import java.util.Iterator;
import java.util.List;
import java.util.Stack;

/*Given a nested list of integers, implement an iterator to flatten it.

Each element is either an integer, or a list -- whose elements may also be integers or other lists.

Have you met this question in a real interview? Yes
Example
Given the list [[1,1],2,[1,1]], By calling next repeatedly until hasNext returns false, the order of elements returned by next should be: [1,1,2,1,1].

Given the list [1,[4,[6]]], By calling next repeatedly until hasNext returns false, the order of elements returned by next should be: [1,4,6].
   Created by K25553 on 10/25/2016.

*/
public class NestedIterator implements Iterator<Integer> {

    private Stack<NestedInteger> stack ;
    public NestedIterator(List<NestedInteger> nestedList) {
        // Initialize your data structure here.
        stack = new Stack<>();
        for(int i= nestedList.size()-1; i>-1;i-- ){
            stack.push(nestedList.get(i));
        }
    }

    // @return {int} the next element in the iteration
    @Override
    public Integer next() {

        return stack.pop().getInteger();
    }

    // @return {boolean} true if the iteration has more element or false
    @Override
    public boolean hasNext() {
        //if stack does not have integer , return false;
        //else flaten the current node to make it integers and push it to stack, once stack detect top is integer reture true
        while(!stack.isEmpty()){
            if(stack.peek().isInteger()){
                return true;
            }
            List<NestedInteger> list = stack.pop().getList();
            for(int i= list.size()-1; i>-1;i-- ){
                stack.push(list.get(i));
            }
        }
        return  false;
    }

    @Override
    public void remove() {
        if(!stack.isEmpty())
        stack.pop();
    }
}
