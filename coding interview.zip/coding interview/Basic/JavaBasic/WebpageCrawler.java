package JavaBasic;

import java.util.ArrayList;
import java.util.List;

/**Implement a webpage Crawler to crawl webpages of http://www.wikipedia.org/. To simplify the question, let's use url instead of the the webpage content.

 Your crawler should:

 Call HtmlHelper.parseUrls(url) to get all urls from a webpage of given url.
 Only crawl the webpage of wikipedia.
 Do not crawl the same webpage twice.
 Start from the homepage of wikipedia: http://www.wikipedia.org/
 Notice

 You need do it with multithreading.

 Have you met this question in a real interview? Yes
 Example
 Given

 "http://www.wikipedia.org/": ["http://www.wikipedia.org/help/"]
 "http://www.wikipedia.org/help/": []
 Return ["http://www.wikipedia.org/", "http://www.wikipedia.org/help/"]

 Given:

 "http://www.wikipedia.org/": ["http://www.wikipedia.org/help/"]
 "http://www.wikipedia.org/help/": ["http://www.wikipedia.org/", "http://www.wikipedia.org/about/"]
 "http://www.wikipedia.org/about/": ["http://www.google.com/"]
 Return ["http://www.wikipedia.org/", "http://www.wikipedia.org/help/", "http://www.wikipedia.org/about/"]
 * Created by K25553 on 11/7/2016.
 */

public class WebpageCrawler {
//    public class HtmlHelper {
//        public static List<String> parseUrls(String url) {
//            return new ArrayList <String> ();
//        }
//        // Get all urls from a webpage of given url.
//    }
    public static List<String> url = new ArrayList<>();

    public class Solution {
        /**
         * @param url a url of root page
         * @return all urls
         */
//        public List<String> crawler(String url) {
//            HtmlHelper urlHelper = new HtmlHelper();
//            url=
//        }
    }
}