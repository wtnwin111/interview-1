package JavaBasic;

/**
 * Created by K25553 on 10/4/2016.
 */


public class ShapeFactory {
    /**
     * @param shapeType a string
     * @return Get object of type Shape
     */
    public Shape getShape(String shapeType) {
        if(shapeType.equals("Rectangle")){
            return new Rectangle();
        }
        if(shapeType .equals("Square")){
            return new Square();
        }
        if(shapeType.equals("Triangle")){
            return new Triangle();
        }
        return null;
    }

    interface Shape {
        void draw();
    }

    class Rectangle implements Shape {
        @Override
        public void draw() {
            System.out.println(" ---- ");
            System.out.println("|    |");
            System.out.println(" ---- ");
        }
        // Write your code here
    }

    class Square implements Shape {
        @Override
        public void draw() {
            System.out.println(" ---- ");
            System.out.println("|    |");
            System.out.println("|    |");
            System.out.println(" ---- ");
        }
        // Write your code here
    }

    class Triangle implements Shape {
        @Override
        public void draw() {
            System.out.println("  /\\");
            System.out.println(" /  \\");
            System.out.println("/____\\");
        }
        // Write your code here
    }
}