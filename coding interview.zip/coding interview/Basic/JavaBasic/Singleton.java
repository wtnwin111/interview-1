package JavaBasic;

/**Singleton is a most widely used design pattern. If a class has and only has one instance at every moment,
 * we call this design as singleton. For example, for class Mouse (not a animal mouse), we should design it in singleton.

 You job is to implement a getInstance method for given class, return the same instance of this class every time you call this method.
 * Created by K25553 on 10/5/2016.
 */
public class Singleton {
    public static Singleton instance = null;
    /**
     * @return: The same instance of this class every time
     */
    public static Singleton getInstance() {
        if (instance==null){
            instance = new Singleton();
        }
        return instance;
    }
}
