package JavaBasic;

import java.util.ArrayList;
import java.util.Iterator;

/**Follow up Zigzag Iterator: What if you are given k 1d vectors? How well can your code be extended to such cases? The "Zigzag" order is not clearly defined and is ambiguous for k > 2 cases. If "Zigzag" does not look right to you, replace "Zigzag" with "Cyclic".

 Have you met this question in a real interview? Yes
 Example
 Given k = 3 1d vectors:

 [1,2,3]
 [4,5,6,7]
 [8,9]
 Return [1,4,8,2,5,9,3,6,7].
 * Created by K25553 on 11/4/2016.
 */
public class ZigzagIterator2{
    int index;
    ArrayList<Iterator<Integer>> i;
    /**
     * @param vecs a list of 1d vectors
     */
    public ZigzagIterator2(ArrayList<ArrayList<Integer>> vecs) {
        index=0;
        i=new ArrayList<>();
        for(ArrayList<Integer> crt: vecs){
            if(crt.size()>0){
                this.i.add(crt.iterator());
            }

        }

    }

    public int next() {
        int crt = i.get(index).next();

        if(i.get(index).hasNext()){
            index= (index+1)%i.size();
        }else {
            i.remove(index);
            if(i.size()>0){
                index= (index)%i.size();
            }
        }

        return crt;
    }

    public boolean hasNext() {
        return i.size()>0;
    }
}
