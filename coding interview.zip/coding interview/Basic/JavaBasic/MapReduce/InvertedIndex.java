package JavaBasic.MapReduce;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

/**
 * Created by K25553 on 12/1/2016.
 */
public class InvertedIndex {
    // Definition of OutputCollector:
    class OutputCollector<K, V> {
        public void collect(K key, V value) {

        }
        // Adds a key/value pair to the output buffer
    }

    //Definition of Document:
    class Document {
        public int id;
        public String content;
    }

    public static class Map {
        public void map(String _, Document value,
                        OutputCollector<String, Integer> output) {
            // Write your code here
            // Output the results into output buffer.
            // Ps. output.collect(String key, int value);
            int id =value.id;
            StringTokenizer stringTokenizer = new StringTokenizer(value.content);
            while(stringTokenizer.hasMoreTokens()){
                output.collect(stringTokenizer.nextToken(),id);
            }
        }
    }

    public static class Reduce {
        //key: is keyword in the content of file, values is file index(sorted),
        public void reduce(String key, Iterator<Integer> values,
                           OutputCollector<String, List<Integer>> output) {
            // Write your code here
            // Output the results into output buffer.
            // Ps. output.collect(String key, List<Integer> value);
            int prev = -1;List<Integer> index = new ArrayList<>();
            while(values.hasNext()){
                int crt =values.next();
                if(prev!= crt){
                    index.add(crt);
                    prev = crt;
                }
            }
            output.collect(key, index);
        }
    }
}
