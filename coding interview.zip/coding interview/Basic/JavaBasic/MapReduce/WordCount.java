package JavaBasic.MapReduce;

/**
 * Example
 * chunk1: "Google Bye GoodBye Hadoop code"
 * chunk2: "lintcode code Bye"
 * <p>
 * <p>
 * Get MapReduce result:
 * Bye: 2
 * GoodBye: 1
 * Google: 1
 * Hadoop: 1
 * code: 2
 * lintcode: 1
 * Created by K25553 on 12/1/2016.
 *
 * Analysis: input split map transport reduce output
 */

import java.util.Iterator;
import java.util.StringTokenizer;

/**
 * Definition of OutputCollector:
 * class OutputCollector<K, V> {
 *     public void collect(K key, V value);
 *         // Adds a key/value pair to the output buffer
 * }
 */
public class WordCount {

    class OutputCollector<String, Integer> {
        public void collect(String key, Integer value) {
        }

        // Adds a key/value pair to the output buffer
    }

    public static class Map {
        //for map key is the address where the chunk of file reside, value is the actual content of the file
        //the result is to split the content value into words and the word with its count to output
        //do not use hashmap to summarize, too much space in mem, need to read one word in mem, and then instantly output to disc
        public void map(String key, String value, OutputCollector<String, Integer> output) {
            // Write your code here
            // Output the results into output buffer.
            // Ps. output.collect(String key, int value);
            StringTokenizer stringTokenizer = new StringTokenizer(value);// StringTokenizer is
            while(stringTokenizer.hasMoreTokens()){
                output.collect(stringTokenizer.nextToken(),1);
            }
        }
    }

    public static class Reduce {
        //for refuce: iterator will not load everything to mem, hence, to reduce mem use
        public void reduce(String key, Iterator<Integer> values,
                           OutputCollector<String, Integer> output) {
            // Write your code here
            // Output the results into output buffer.
            // Ps. output.collect(String key, int value);
            int ct =0;
            while(values.hasNext()){
                ct+=values.next();
            }
            output.collect(key,ct);

        }
    }
}
