package JavaBasic.MapReduce;

import java.util.*;

/**Use Map Reduce to find anagrams in a given list of words.

 Have you met this question in a real interview? Yes
 Example
 Given ["lint", "intl", "inlt", "code"], return ["lint", "inlt", "intl"],["code"].

 Given ["ab", "ba", "cd", "dc", "e"], return ["ab", "ba"], ["cd", "dc"], ["e"].
 * Created by K25553 on 12/1/2016.
 * scenario: lists of file of token of string, many machaine each call differernt file to map reduce,
 * reudce machine accumulate all string  by each keyword, count each anagram
 */

public class Anagram {
    //Definition of OutputCollector:
    class OutputCollector<K, V> {
        public void collect(K key, V value){}
        // Adds a key/value pair to the output buffer
    }

    public static class Map {
        public void map(String key, String value,
                        OutputCollector<String, String> output) {
            // Write your code here
            // Output the results into output buffer.
            // Ps. output.collect(String key, String value);
            StringTokenizer stringTokenizer = new StringTokenizer(value);
            while(stringTokenizer.hasMoreTokens()){
                String crt = stringTokenizer.nextToken();
                char[] soted =Arrays.copyOf(crt.toCharArray(),crt.length());
                Arrays.sort(soted);
                output.collect(new String(soted),crt);
            }
        }
    }

    public static class Reduce {
        public void reduce(String key, Iterator<String> values,
                           OutputCollector<String, List<String>> output) {
            // Write your code here
            // Output the results into output buffer.
            // Ps. output.collect(String key, List<String> value);
            List<String> res = new ArrayList<>();
            while(values.hasNext()){
                res.add(values.next());
            }
            output.collect(key, res);
        }
    }
}
