package JavaBasic.MapReduce;

import java.util.*;

/**
 * Find top k frequent words with map reduce framework.

 The mapper's key is the document id, value is the content of the document, words in a document are split by spaces.

 For reducer, the output should be at most k key-value pairs, which are the top k words and their frequencies in this reducer. The judge will take care about how to merge different reducers' results to get the global top k frequent words, so you don't need to care about that part.

 The k is given in the constructor of TopK class.

 Notice

 For the words with same frequency, rank them with alphabet.

 Have you met this question in a real interview? Yes
 Example
 Given document A =

 lintcode is the best online judge
 I love lintcode
 and document B =

 lintcode is an online judge for coding interview
 you can test your code online at lintcode
 The top 2 words and their frequencies should be

 lintcode, 4
 online, 3
 */


public class TopKFrequentWords {
    // Definition of OutputCollector:
    class OutputCollector<K, V> {
        public void collect(K key, V value) {
        }
    }
// Adds a key/value pair to the output buffer
class Pair {
    int ct ;
    String key;
    public Pair(String key, int ct) {
        this.ct=ct;
        this.key =key;
    }
}

//Definition of Document:
class Document {
    public int id;
    public String content;
}
    public static class Map {
        public void map(String _, Document value,
                        OutputCollector<String, Integer> output) {
            // Write your code here
            // Output the results into output buffer.
            // Ps. output.collect(String key, int value);
            StringTokenizer stringTokenizer = new StringTokenizer(value.content);
            while (stringTokenizer.hasMoreTokens()){
                output.collect(stringTokenizer.nextToken(), 1);
            }
        }
    }

    public  class Reduce {
        PriorityQueue<Pair> queue =null;
        int k;
        private Comparator<Pair> pairComparator = new Comparator<Pair>() {
            public int compare(Pair left, Pair right) {
                if (left.ct != right.ct) {
                    return left.ct - right.ct;
                }
                return right.key.compareTo(left.key);
            }
        };

        public void setup(int k) {
            // initialize your data structure here
            queue = new PriorityQueue<Pair>(k, pairComparator);
            this.k=k;
        }

        public void reduce(String key, Iterator<Integer> values) {
            int ct=0;
            while(values.hasNext()){
                ct+=values.next();
            }
            Pair crt = new Pair(key, ct);
            if(queue.size()>=k){
                if(pairComparator.compare(crt,queue.peek())>0){
                    queue.poll();
                    queue.add(crt);
                }
            }else{
                queue.add(crt);
            }
        }

        public void cleanup(OutputCollector<String, Integer> output) {
            // Output the top k pairs <word, times> into output buffer.
            // Ps. output.collect(String key, Integer value);
            List<Pair> pairs = new ArrayList<Pair>();
            while (!queue.isEmpty()) {
                pairs.add(queue.poll());
            }

            // reverse result
            int n = pairs.size();
            for (int i = n - 1; i >= 0; --i) {
                Pair pair = pairs.get(i);
                output.collect(pair.key, pair.ct);
            }
        }
    }
}
