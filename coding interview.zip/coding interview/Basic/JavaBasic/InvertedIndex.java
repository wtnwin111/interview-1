package JavaBasic;

import java.util.*;

/**Example
 Given a list of documents with id and content. (class Document)

 [
 {
 "id": 1,
 "content": "This is the content of document 1 it is very short"
 },
 {
 "id": 2,
 "content": "This is the content of document 2 it is very long bilabial bilabial heheh hahaha ..."
 },
 ]
 Return an inverted index (HashMap with key is the word and value is a list of document ids).

 {
 "This": [1, 2],
 "is": [1, 2],
 ...
 }
 * Created by K25553 on 12/1/2016.
 */
public class InvertedIndex {


     //* Definition of Document:
     class Document {
          public int id;
          public String content;
      }


        /**
         * @param docs a list of documents
         * @return an inverted index
         */
        public Map<String, List<Integer>> invertedIndex(List<Document> docs) {
            Map<String, List<Integer>> map = new HashMap<>();
            if(docs.size()==0||docs==null){
                return map;
            }
            for ( Document crt : docs){
                int id = crt.id;
                StringTokenizer stringTokenizer = new StringTokenizer(crt.content);
                while(stringTokenizer.hasMoreTokens()){
                    String crtString = stringTokenizer.nextToken();
                    if(!map.containsKey(crtString)){
                        List<Integer> list = new ArrayList<>();
                        list.add(id);
                        map.put(crtString, list);
                    }else {
                        List<Integer> crtList = map.get(crtString);
                        int size = crtList.size();
                        if(crtList.get(size-1)!=id){
                            crtList.add(id);
                        }
                    }
                }
            }
            return map;
        }

    /**
     * @param docs a list of documents
     * @return an inverted index
     */
    public Map<String, List<Integer>> invertedIndex1(List<Document> docs) {
        // Write your code here
        Map<String, List<Integer>> results = new HashMap<String, List<Integer>>();
        for (Document doc : docs) {
            int id = doc.id;
            StringBuffer temp = new StringBuffer("");
            String content = doc.content;
            int n = content.length();
            for (int i = 0; i < n; ++i) {
                if (content.charAt(i) == ' ') {
                    insert(results, temp.toString(), id);
                    temp = new StringBuffer("");
                } else
                    temp.append(content.charAt(i));
            }
            insert(results, temp.toString(), id);
        }
        return results;
    }

    public void insert(Map<String, List<Integer>> rt, String tmp, int id) {
        if (tmp.equals("") || tmp == null)
            return;
        if (!rt.containsKey(tmp))
            rt.put(tmp, new ArrayList<Integer>());

        int n = rt.get(tmp).size();
        if (n == 0 || rt.get(tmp).get(n - 1) != id)
            rt.get(tmp).add(id);
    }
}
