package JavaBasic;

/**
 * Created by K25553 on 10/4/2016.
 */
public class ToyFactory {
    interface Toy {
        void talk();
    }

    class Dog implements Toy {
        @Override
        public void talk() {
            System.out.println("Wow");
        }
        // Write your code here
    }

    class Cat implements Toy {
        @Override
        public void talk() {
            System.out.println("Meow");
        }
    }
    /**
     * @param type a string
     * @return Get object of the type
     */
    public Toy getToy(String type) {
        if(type==null){
            return null;
        }
        if(type.equals("Dog")){
            return new Dog();
        }
        if(type.equals("Cat")){
            return new Cat();
        }
        return null;
    }
}
