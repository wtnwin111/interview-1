/**
 *
 */
package List;

/**
 * @author K25553
 *
 */
public class RemoveLinkedListElements {

	public class ListNode {
		int val;
		ListNode next;

		ListNode(int x) {
			val = x;
		}
	}

	/**
	 * @param head
	 *            a ListNode
	 * @param val
	 *            an integer
	 * @return a ListNode
	 */
	public ListNode removeElements(ListNode head, int val) {
		ListNode dummy = new ListNode(0);
		dummy.next = head;
		ListNode pre = dummy;
		while (pre.next != null) {
			if (pre.next.val == val) {
				pre.next = pre.next.next;
			} else {
				pre = pre.next;
			}

		}
		return dummy.next;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
