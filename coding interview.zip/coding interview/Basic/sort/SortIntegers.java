/**
 *
 */
package sort;

/**
 * Given an integer array, sort it in ascending order. Use selection sort,
 * bubble sort, insertion sort or any O(n2) algorithm.
 * Given an integer array, sort it in ascending order. Use selection sort,
 * bubble sort, insertion sort or any O(n2) algorithm.
 *
 * @author K25553
 *
 */
public class SortIntegers {
	/**
	 * @param A
	 *            an integer array
	 * @return void
	 */
	public void sortIntegers(int[] a) {
		//
		int len = a.length;
		for (int i = 0; i < len; i++) {
			for (int j = i; j < len; j++) {
				if (a[i] > a[j]) {
					int temp = a[j];
					a[j] = a[i];
					a[i] = temp;
				}
			}
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
