/**
 *
 */
package emun;

/**
 * Find the Nth number in Fibonacci sequence.
 *
 * A Fibonacci sequence is defined as follow:
 *
 * The first two numbers are 0 and 1.
 * The i th number is the sum of i-1 th number and i-2 th number.
 * The first ten numbers in Fibonacci sequence is:
 *
 * 0, 1, 1, 2, 3, 5, 8, 13, 21, 34 ...
 * Example
 * Given 1, return 0
 *
 * Given 2, return 1
 *
 * Given 10, return 34
 *
 * @author K25553
 *
 */
public class Fibonacci {
	/**
	 * @param n
	 *            : an integer
	 * @return an integer f(n)
	 */
	public int fibonacci(int n) {
		if (n == 0 || n == 1) {
			return 0;
		} else if (n == 2) {
			return 1;
		}
		int[] res = new int[n];
		res[0] = 0;
		res[1] = 1;

		for (int i = 2; i < n; i++) {
			res[i] = res[i - 1] + res[i - 2];
		}
		return res[n - 1];
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
