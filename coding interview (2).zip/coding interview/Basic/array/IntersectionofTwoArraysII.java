package array;

/**Given two arrays, write a function to compute their intersection.

 Notice

 Each element in the result must be unique.
 The result can be in any order.
 Have you met this question in a real interview? Yes
 Example
 Given nums1 = [1, 2, 2, 1], nums2 = [2, 2], return [2].
 * Created by K25553 on 8/30/2016.
 */
public class IntersectionofTwoArraysII {
}
