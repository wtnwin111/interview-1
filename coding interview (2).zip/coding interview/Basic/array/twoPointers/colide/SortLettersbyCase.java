/**
 * 
 */
package array.twoPointers.colide;

/**
 * Given a string which contains only letters. Sort it by lower case first and upper case second.

Example
For "abAcD", a reasonable answer is "acbAD"
 * @author Tiannan
 *
 */
public class SortLettersbyCase {
	/** 
     *@param chars: The letter array you should sort by Case
     *@return: void
     */

	public void sortLetters(char[] chars) {
		//write your code here
		if (chars.length<=1||chars==null)
			return;
		int l=0, r=chars.length-1;
		while(l<r){
			//imp:l<r&& is prerequisit
			while(l<r&&Character.isLowerCase(chars[l])){
				l++;
			}
			while(l<r&&Character.isUpperCase(chars[r])){
				r--;
			}
			if(r<=l){
				return;
			}
			else{
				char temp = chars[l];
				chars[l]=chars[r];
				chars[r]=temp;
				r--;
				l++;
			}
		}
	}

}
