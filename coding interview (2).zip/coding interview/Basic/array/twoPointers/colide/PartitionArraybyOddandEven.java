package array.twoPointers.colide;

/**Partition an integers array into odd number first and even number second.
 * Example
 Given [1, 2, 3, 4], return [1, 3, 2, 4]

 Challenge
 Do it in-place.
 * Created by wtnwi on 2016/9/4.
 */
public class PartitionArraybyOddandEven {
    /**
     * @param nums: an array of integers
     * @return: nothing
     */
    public void partitionArray(int[] nums)  {
        if(nums.length==0||nums==null){
            return;
        }
        int l=0,r=nums.length-1;
        while(l<r){
            while(l<r&&nums[l]%2==1){
                l++;
            }
            while(l<r&&nums[r]%2==0){
                r--;
            }
            if(l>r){
                return;
            }
            else
            {
                int temp=nums[r];
                nums[r]=nums[l];
                nums[l]=temp;
                r--;
                l++;
            }
        }
    }
}
