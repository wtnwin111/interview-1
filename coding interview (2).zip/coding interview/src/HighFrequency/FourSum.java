
package HighFrequency;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * @author Tiannan
 *analysis: 
 *sort array 
 *for i-len-3
 *for i+1-len-2
 *	while binary search from i+3 to len-1
 *		if sum< target
 *			left++
 *		else sum>target 
 *			right ++
 *		else 
 *			add 1234 to temp to res
 *			l++ R--
 *		 	check next l and r is duplicated 
 */
public class FourSum {
	public ArrayList<ArrayList<Integer>> fourSum(int[] n, int t) {
		ArrayList<ArrayList<Integer>> res = new ArrayList<>();
		if(n==null || n.length<4){
			return res;
		}
        int len= n.length;
		Arrays.sort(n);
		for(int i=0;i<n.length-3;i++){
            while()
            for(int j=i+1;j<len-2;j++){

            }
        }
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
