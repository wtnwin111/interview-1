/**
 * 
 */
package tri;

import java.util.HashMap;

/**
 * @author K25553
 *
 */
public class ImplementTrie {
	class TrieNode {
	    // Initialize your data structure here.
	    public HashMap<Character, TrieNode> children;
			public boolean hasWord;
			// Initialize your data structure here.
			public TrieNode() {
				children= new HashMap<Character, TrieNode>();
				hasWord=false;
			}
	}

	public class Solution {
	    private TrieNode root;

	    public Solution() {
	        root = new TrieNode();
	    }

	    // Inserts a word into the trie.
			public void insert(String word) {
				TrieNode now = root;
				for(int i=0; i< word.length(); i++){
					if(!now.children.containsKey(word.charAt(i))){
						now.children.put(word.charAt(i), new TrieNode());

					}
					now = now.children.get(word.charAt(i));
				}
				now.hasWord=true;
			}

			// Returns if the word is in the trie.
			public boolean search(String word) {
				TrieNode now= root;
				if(word.length()==0||word==null){
					return false;
				}
				for(int i=0; i< word.length(); i++){
					if(!now.children.containsKey(word.charAt(i))){
						return false;

					}
					now = now.children.get(word.charAt(i));
				}
				
				return now.hasWord;
			}

			// Returns if there is any word in the trie
			// that starts with the given prefix.
			public boolean startsWith(String word) {
				TrieNode now= root;
			
				if(word.length()==0||word==null){
					return false;
				}
				for(int i=0; i< word.length(); i++){
					if(!now.children.containsKey(word.charAt(i))){
						return false;

					}
					now = now.children.get(word.charAt(i));
				}
				
				return true;
			}
	}
}
