/**
 * 
 */
package array;

import java.util.Arrays;

/**
 * @author Tiannan
 *
 */
public class SortDupicate {
	public static int[] sortDuplicates(int a[]){           
		int i, k,temp;

		//Arrays.sort(a);
		quickSort(0, a.length-1, a);
		System.out.println(Arrays.toString(a));
		k = 0;i = 1;
		while (k<a.length){
			if(i==a.length-1){
				if (a[k] != a[i]) 
				{	k++;
				swap(k, i, a);
					
				}
				quickSort(i, k, a);
				System.out.println(Arrays.toString(a));
				if(k==a.length-1){
					break;
				}else{
					i=k+1;
				}
				
			}
			if (a[k] != a[i]) 
			{	k++;
			swap(k, i, a);
				i++;
			}
			else{
				i++;
			} 
			
		}

		return a;  
	}
	

	public static int partition(int left, int right, int array[]){
/*		int i = left-1;
		int pivot = array[right];
		
		
		for(int j = left;j<right;j++){
			if(array[j] < pivot){
				i++;
				swap(i, j, array);
			}
		}
		
		i++;
		swap(i, right, array);
		return i;
		*/
		int pivot = array[(right+left)/2];
		while(left<=right){
			while(array[left]<pivot) left++;
			while(array[right]>pivot)right--;
			if(left<=right){
				swap(left, right, array);
			left++;
			right--;
			}
			
		}
		return left;
	}

	public static void quickSort(int left, int right, int array[]){
	/*	if(left >= right){
			return;
		}
		if(left == right -1){
			if(array[left] > array[right]){
				swap(left, right, array);
			}
			return;
		}*/
		
		int pivot = partition(left, right, array);
		if(left< pivot-1){
			quickSort(left, pivot-1, array);
		}
		if(right> pivot)
		quickSort(pivot, right, array);
	}

	public static void swap(int i, int j, int array[]){
		int temp = array[i];
		array[i] = array[j];
		array[j] = temp;
	}
	/**
	 * @param args
	 */
	 public static void main(String[] args) {
		int arr[]={ 2,9,1,5,1,4,9,7,2,1,4 } ;
		int arr1[]={ 1,1,1,2,2,3 } ;
		System.out.println(Arrays.toString(sortDuplicates(arr1)));

	 }

}
