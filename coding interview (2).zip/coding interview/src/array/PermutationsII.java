/**
 *
 */
package array;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

/**
 * Given a list of numbers with duplicate number in it. Find all unique
 * permutations.
 *
 * Example
 * For numbers [1,2,2] the unique permutations are:
 *
 * [
 *
 * [1,2,2],
 *
 * [2,1,2],
 *
 * [2,2,1]
 *
 * ]
 *
 * @author Tiannan
 *         O(n!)
 */
public class PermutationsII {
	/**
	 * dfs: int[i] is unique id for each num,
	 * iterate throught i to end
	 * backtrack if when generate a list size == nums size, add list to res
	 * for each layer, interate throught 0 to the end, use visted[num.size] to
	 * determine if the id visited not to be added
	 * then update visited[] for current id, dfs, backtrack remove id from
	 * visited[] and remove id from list[]
	 *
	 * @param nums
	 *            : A list of integers.
	 * @return: A list of unique permutations.
	 */
	public ArrayList<ArrayList<Integer>> permuteUnique(ArrayList<Integer> nums) {
		ArrayList<ArrayList<Integer>> resArrayList = new ArrayList<ArrayList<Integer>>();
		if (nums == null || nums.size() == 0) {
			return resArrayList;
		}
		Collections.sort(nums);
		int[] visited = new int[nums.size()];
		dfs(nums, resArrayList, new ArrayList<Integer>(), visited);
		return resArrayList;

	}

	private void dfs(ArrayList<Integer> nums,
			ArrayList<ArrayList<Integer>> res, ArrayList<Integer> temp,
			int[] visited) {
		if (temp.size() == nums.size()) {
			res.add(new ArrayList<Integer>(temp));
			return;
		}

		for (int i = 0; i < nums.size(); i++) {
			if (visited[i] == 1
					|| (i > 0 && visited[i - 1] != 1 && nums.get(i) == nums
							.get(i - 1))) {
				continue;
			}
			temp.add(nums.get(i));
			visited[i] = 1;
			dfs(nums, res, temp, visited);
			visited[i] = 0;
			temp.remove(temp.size() - 1);
		}

	}

	/**
	 * @param args
	 */

	public ArrayList<ArrayList<Integer>> permuteUnique(int[] num) {
		ArrayList<ArrayList<Integer>> result = new ArrayList<ArrayList<Integer>>();
		if (num == null || num.length == 0) {
			return result;
		}
		ArrayList<Integer> list = new ArrayList<Integer>();
		int[] visited = new int[num.length];

		Arrays.sort(num);
		helper(result, list, visited, num);
		return result;
	}

	public void helper(ArrayList<ArrayList<Integer>> result,
			ArrayList<Integer> list, int[] visited, int[] num) {
		if (list.size() == num.length) {
			result.add(new ArrayList<Integer>(list));
			return;
		}

		for (int i = 0; i < num.length; i++) {
			if (visited[i] == 1
					|| (i != 0 && num[i] == num[i - 1] && visited[i - 1] == 0)) {
				continue;
			}
			visited[i] = 1;
			list.add(num[i]);
			helper(result, list, visited, num);
			list.remove(list.size() - 1);
			visited[i] = 0;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
