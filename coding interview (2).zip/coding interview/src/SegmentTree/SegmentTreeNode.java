package SegmentTree;

public class SegmentTreeNode {
	public int start, end, max, min, sum;
	public SegmentTreeNode left, right;
	public int count;
	public SegmentTreeNode(int start, int end) {
		this.start = start; this.end = end;
		this.left = this.right = null;
	}
}